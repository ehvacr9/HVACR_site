# Welcome to CoolProp

CoolProp is a thermophysical property database and wrappers for a selection of programming environments.
It offers similar functionality to REFPROP, but CoolProp is open-source and free.
It was originally developed by Ian Bell, at the time a post-doc at the University of Liege, in Liege, Belgium.

* CoolProp has flexible licensing terms: Commercial - ok! Academic? - ok! [![license](https://img.shields.io/github/license/CoolProp/CoolProp.svg)](https://github.com/CoolProp/CoolProp/blob/master/LICENSE)

* For Python, get the latest release via `pip install coolprop` [![PyPI downloads](https://img.shields.io/pypi/dm/CoolProp.svg?label=PyPI-downloads)](http://pypi.python.org/pypi/CoolProp/) [![PyPI version](https://img.shields.io/pypi/v/coolprop.svg?label=PyPI-binaries)](http://pypi.python.org/pypi/CoolProp/)

* ... other binaries are available from [SourceForge](http://sourceforge.net/projects/coolprop/files) [![sourceforge downloads](https://img.shields.io/sourceforge/dm/CoolProp.svg?label=SF-downloads)](http://sourceforge.net/projects/coolprop/files) ![CoolProp version tag](https://img.shields.io/github/release/CoolProp/CoolProp.svg?label=SF-binaries)

* There is also a bleeding edge nightly build of the [development version](http://sourceforge.net/projects/coolprop/files/CoolProp/nightly).

* The documentation is available for the [latest release](http://www.coolprop.org) and the [development version](https://coolprop.github.io/devdocs/)

* For any kind of question regarding CoolProp and its usage, you can ask the [CoolProp Discussions](https://github.com/CoolProp/CoolProp/discussions)

* ... you might also find answers in our [FAQ](https://github.com/CoolProp/CoolProp/blob/master/FAQ.md)

* If you found a bug or have an issue that requires the developers to become active, please file an issue in our [issue tracker](https://github.com/CoolProp/CoolProp/issues)

* [Contributions](https://github.com/CoolProp/CoolProp/blob/master/.github/CONTRIBUTING.md) to this project are welcomed and encouraged! If you wish to [contribute](https://github.com/CoolProp/CoolProp/blob/master/.github/CONTRIBUTING.md) bug fixes, patches, or new features, wrappers, or material properties, please submit a Pull Request with your code.

* If you are new to Git and Github, please see the [CoolProp Wiki](https://github.com/CoolProp/CoolProp/wiki) for guidance on becoming a contributor to the project.

## Sponsors

Free code signing on Windows provided by [SignPath.io](https://about.signpath.io/), certificate by [SignPath Foundation](https://signpath.org/).
