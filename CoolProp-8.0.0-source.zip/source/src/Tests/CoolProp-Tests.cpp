

#include "CoolProp/AbstractState.h"
#include "CoolProp/DataStructures.h"
#include "../Backends/Helmholtz/HelmholtzEOSMixtureBackend.h"
#include "../Backends/Helmholtz/HelmholtzEOSBackend.h"
#include "../Backends/REFPROP/REFPROPMixtureBackend.h"
#include "../Backends/Cubics/CubicBackend.h"
#include "CoolProp/superancillary/superancillary.h"
#include "CoolProp/detail/json.h"
#include <atomic>
#include <map>
#include <set>
#include <thread>

// ############################################
//                      TESTS
// ############################################

#if defined(ENABLE_CATCH)

#    include <memory>
#    include <catch2/catch_all.hpp>
#    include "CoolProp/detail/tools.h"
#    include "CoolProp/CoolProp.h"
#    include "CoolProp/HumidAirProp.h"

using namespace CoolProp;

namespace TransportValidation {

// A structure to hold the values for one validation call
struct vel
{
   public:
    std::string in1, in2, out, fluid;
    double v1, v2, tol, expected;
    vel(std::string fluid, std::string in1, double v1, std::string in2, double v2, const std::string& out, double expected, double tol)
      : in1(in1), in2(in2), fluid(fluid), v1(v1), v2(v2), expected(expected), tol(tol) {

        };
};

vel viscosity_validation_data[] = {
  // From Vogel, JPCRD, 1998
  vel("Propane", "T", 90, "Dmolar", 16.52e3, "V", 7388e-6, 1e-3),
  vel("Propane", "T", 150, "Dmolar", 15.14e3, "V", 656.9e-6, 5e-3),
  vel("Propane", "T", 600, "Dmolar", 10.03e3, "V", 73.92e-6, 5e-3),
  vel("Propane", "T", 280, "Dmolar", 11.78e3, "V", 117.4e-6, 1e-3),

  // Huber, FPE, 2004
  vel("n-Octane", "T", 300, "Dmolar", 6177.2, "V", 553.60e-6, 1e-3),
  vel("n-Nonane", "T", 300, "Dmolar", 5619.1, "V", 709.53e-6, 1e-3),
  vel("n-Decane", "T", 300, "Dmolar", 5150.4, "V", 926.44e-6, 1e-3),

  // Huber, Energy & Fuels, 2004
  vel("n-Dodecane", "T", 300, "Dmolar", 4411.5, "V", 1484.8e-6, 1e-3),
  vel("n-Dodecane", "T", 500, "Dmolar", 3444.7, "V", 183.76e-6, 1e-3),

  // Huber, I&ECR, 2006
  vel("R125", "T", 300, "Dmolar", 10596.9998, "V", 177.37e-6, 1e-3),
  vel("R125", "T", 400, "Dmolar", 30.631, "V", 17.070e-6, 1e-3),

  // From REFPROP 9.1 since Huber I&ECR 2003 does not provide validation data
  vel("R134a", "T", 185, "Q", 0, "V", 0.0012698376398294414, 1e-3),
  vel("R134a", "T", 185, "Q", 1, "V", 7.4290821400170869e-006, 1e-3),
  vel("R134a", "T", 360, "Q", 0, "V", 7.8146319978982133e-005, 1e-3),
  vel("R134a", "T", 360, "Q", 1, "V", 1.7140264998576107e-005, 1e-3),

  // From REFPROP 9.1 since Kiselev, IECR, 2005 does not provide validation data
  vel("Ethanol", "T", 300, "Q", 0, "V", 0.0010439017679191723, 1e-3),
  vel("Ethanol", "T", 300, "Q", 1, "V", 8.8293820936046416e-006, 1e-3),
  vel("Ethanol", "T", 500, "Q", 0, "V", 6.0979347125450671e-005, 1e-3),
  vel("Ethanol", "T", 500, "Q", 1, "V", 1.7229157141572511e-005, 1e-3),

  // From CoolProp v5 implementation of correlation - more or less agrees with REFPROP
  // Errata in BibTeX File
  vel("Hydrogen", "T", 35, "Dmass", 100, "V", 5.47889e-005, 1e-3),

  // From Meng 2012 experimental data (note erratum in BibTeX file)
  vel("DimethylEther", "T", 253.146, "Dmass", 734.28, "V", 0.20444e-3, 3e-3),
  vel("DimethylEther", "T", 373.132, "Dmass", 613.78, "V", 0.09991e-3, 3e-3),

  // From Fenghour, JPCRD, 1995
  vel("Ammonia", "T", 200, "Dmolar", 3.9, "V", 6.95e-6, 1e-3),
  vel("Ammonia", "T", 200, "Dmolar", 42754.4, "V", 507.28e-6, 1e-3),
  vel("Ammonia", "T", 398, "Dmolar", 7044.7, "V", 17.67e-6, 1e-3),
  vel("Ammonia", "T", 398, "Dmolar", 21066.7, "V", 43.95e-6, 1e-3),

  // From Lemmon and Jacobsen, JPCRD, 2004
  vel("Nitrogen", "T", 100, "Dmolar", 1e-14, "V", 6.90349e-6, 1e-3),
  vel("Nitrogen", "T", 300, "Dmolar", 1e-14, "V", 17.8771e-6, 1e-3),
  vel("Nitrogen", "T", 100, "Dmolar", 25000, "V", 79.7418e-6, 1e-3),
  vel("Nitrogen", "T", 200, "Dmolar", 10000, "V", 21.0810e-6, 1e-3),
  vel("Nitrogen", "T", 300, "Dmolar", 5000, "V", 20.7430e-6, 1e-3),
  vel("Nitrogen", "T", 126.195, "Dmolar", 11180, "V", 18.2978e-6, 1e-3),
  vel("Argon", "T", 100, "Dmolar", 1e-14, "V", 8.18940e-6, 1e-3),
  vel("Argon", "T", 300, "Dmolar", 1e-14, "V", 22.7241e-6, 1e-3),
  vel("Argon", "T", 100, "Dmolar", 33000, "V", 184.232e-6, 1e-3),
  vel("Argon", "T", 200, "Dmolar", 10000, "V", 25.5662e-6, 1e-3),
  vel("Argon", "T", 300, "Dmolar", 5000, "V", 26.3706e-6, 1e-3),
  vel("Argon", "T", 150.69, "Dmolar", 13400, "V", 27.6101e-6, 1e-3),
  vel("Oxygen", "T", 100, "Dmolar", 1e-14, "V", 7.70243e-6, 1e-3),
  vel("Oxygen", "T", 300, "Dmolar", 1e-14, "V", 20.6307e-6, 1e-3),
  vel("Oxygen", "T", 100, "Dmolar", 35000, "V", 172.136e-6, 1e-3),
  vel("Oxygen", "T", 200, "Dmolar", 10000, "V", 22.4445e-6, 1e-3),
  vel("Oxygen", "T", 300, "Dmolar", 5000, "V", 23.7577e-6, 1e-3),
  vel("Oxygen", "T", 154.6, "Dmolar", 13600, "V", 24.7898e-6, 1e-3),
  vel("Air", "T", 100, "Dmolar", 1e-14, "V", 7.09559e-6, 1e-3),
  vel("Air", "T", 300, "Dmolar", 1e-14, "V", 18.5230e-6, 1e-3),
  vel("Air", "T", 100, "Dmolar", 28000, "V", 107.923e-6, 1e-3),
  vel("Air", "T", 200, "Dmolar", 10000, "V", 21.1392e-6, 1e-3),
  vel("Air", "T", 300, "Dmolar", 5000, "V", 21.3241e-6, 1e-3),
  vel("Air", "T", 132.64, "Dmolar", 10400, "V", 17.7623e-6, 1e-3),

  // From Michailidou, JPCRD, 2013
  vel("Hexane", "T", 250, "Dmass", 1e-14, "V", 5.2584e-6, 1e-3),
  vel("Hexane", "T", 400, "Dmass", 1e-14, "V", 8.4149e-6, 1e-3),
  vel("Hexane", "T", 550, "Dmass", 1e-14, "V", 11.442e-6, 1e-3),
  vel("Hexane", "T", 250, "Dmass", 700, "V", 528.2e-6, 1e-3),
  vel("Hexane", "T", 400, "Dmass", 600, "V", 177.62e-6, 1e-3),
  vel("Hexane", "T", 550, "Dmass", 500, "V", 95.002e-6, 1e-3),

  // From Assael, JPCRD, 2014
  vel("Heptane", "T", 250, "Dmass", 1e-14, "V", 4.9717e-6, 1e-3),
  vel("Heptane", "T", 400, "Dmass", 1e-14, "V", 7.8361e-6, 1e-3),
  vel("Heptane", "T", 550, "Dmass", 1e-14, "V", 10.7394e-6, 1e-3),
  vel("Heptane", "T", 250, "Dmass", 720, "V", 725.69e-6, 1e-3),
  vel("Heptane", "T", 400, "Dmass", 600, "V", 175.94e-6, 1e-3),
  vel("Heptane", "T", 550, "Dmass", 500, "V", 95.105e-6, 1e-3),

  // From Laesecke, JPCRD, 1998: https://pmc.ncbi.nlm.nih.gov/articles/PMC5514612/pdf/nihms869002.pdf
  vel("CO2", "T", 100, "Dmass", 1e-5, "V", 0.0053757e-3, 1e-4),
  vel("CO2", "T", 2000, "Dmass", 1e-5, "V", 0.066079e-3, 1e-4),
  vel("CO2", "T", 10000, "Dmass", 1e-5, "V", 0.17620e-3, 1e-4),
  vel("CO2", "T", 220, "Dmass", 3, "V", 0.011104e-3, 1e-4),
  vel("CO2", "T", 225, "Dmass", 1150, "V", 0.22218e-3, 1e-4),
  vel("CO2", "T", 300, "Dmass", 65, "V", 0.015563e-3, 1e-4),
  vel("CO2", "T", 300, "Dmass", 1400, "V", 0.50594e-3, 1e-4),
  vel("CO2", "T", 700, "Dmass", 100, "V", 0.033112e-3, 1e-4),
  vel("CO2", "T", 700, "Dmass", 1200, "V", 0.22980e-3, 1e-4),

  // Tanaka, IJT, 1996
  vel("R123", "T", 265, "Dmass", 1545.8, "V", 627.1e-6, 1e-3),
  vel("R123", "T", 265, "Dmass", 1.614, "V", 9.534e-6, 1e-3),
  vel("R123", "T", 415, "Dmass", 1079.4, "V", 121.3e-6, 1e-3),
  vel("R123", "T", 415, "Dmass", 118.9, "V", 15.82e-6, 1e-3),

  // Huber, JPCRD, 2008 and IAPWS
  vel("Water", "T", 298.15, "Dmass", 998, "V", 889.735100e-6, 1e-7),
  vel("Water", "T", 298.15, "Dmass", 1200, "V", 1437.649467e-6, 1e-7),
  vel("Water", "T", 373.15, "Dmass", 1000, "V", 307.883622e-6, 1e-7),
  vel("Water", "T", 433.15, "Dmass", 1, "V", 14.538324e-6, 1e-7),
  vel("Water", "T", 433.15, "Dmass", 1000, "V", 217.685358e-6, 1e-7),
  vel("Water", "T", 873.15, "Dmass", 1, "V", 32.619287e-6, 1e-7),
  vel("Water", "T", 873.15, "Dmass", 100, "V", 35.802262e-6, 1e-7),
  vel("Water", "T", 873.15, "Dmass", 600, "V", 77.430195e-6, 1e-7),
  vel("Water", "T", 1173.15, "Dmass", 1, "V", 44.217245e-6, 1e-7),
  vel("Water", "T", 1173.15, "Dmass", 100, "V", 47.640433e-6, 1e-7),
  vel("Water", "T", 1173.15, "Dmass", 400, "V", 64.154608e-6, 1e-7),
  vel("Water", "T", 647.35, "Dmass", 122, "V", 25.520677e-6, 1e-7),
  vel("Water", "T", 647.35, "Dmass", 222, "V", 31.337589e-6, 1e-7),
  vel("Water", "T", 647.35, "Dmass", 272, "V", 36.228143e-6, 1e-7),
  vel("Water", "T", 647.35, "Dmass", 322, "V", 42.961579e-6, 1e-7),
  vel("Water", "T", 647.35, "Dmass", 372, "V", 45.688204e-6, 1e-7),
  vel("Water", "T", 647.35, "Dmass", 422, "V", 49.436256e-6, 1e-7),

  // Quinones-Cisneros, JPCRD, 2012
  vel("SF6", "T", 300, "Dmass", 1e-14, "V", 15.2887e-6, 1e-4),
  vel("SF6", "T", 300, "Dmass", 5.92, "V", 15.3043e-6, 1e-4),
  vel("SF6", "T", 300, "Dmass", 1345.1, "V", 117.417e-6, 1e-4),
  vel("SF6", "T", 400, "Dmass", 1e-14, "V", 19.6796e-6, 1e-4),
  vel("SF6", "T", 400, "Dmass", 278.47, "V", 24.4272e-6, 1e-4),
  vel("SF6", "T", 400, "Dmass", 1123.8, "V", 84.7835e-6, 1e-4),

  // Quinones-Cisneros, JCED, 2012, data from validation
  vel("H2S", "T", 200, "P", 1000e5, "V", 0.000460287, 1e-3),
  vel("H2S", "T", 200, "P", 0.251702e5, "V", 8.02322E-06, 1e-3),
  vel("H2S", "T", 596.961, "P", 1000e5, "V", 6.94741E-05, 1e-3),
  vel("H2S", "T", 596.961, "P", 1e5, "V", 2.38654E-05, 1e-3),

  // Geller, Purdue Conference, 2000
  //vel("R410A", "T", 243.15, "Q", 0, "V", 238.61e-6, 5e-2),
  //vel("R410A", "T", 243.15, "Q", 1, "V", 10.37e-6, 5e-2),
  //vel("R410A", "T", 333.15, "Q", 0, "V", 70.71e-6, 5e-2),
  //vel("R410A", "T", 333.15, "Q", 1, "V", 19.19e-6, 5e-2),
  //vel("R407C", "T", 243.15, "Q", 0, "V", 304.18e-6, 1e-2),
  //vel("R407C", "T", 243.15, "Q", 1, "V", 9.83e-6, 1e-2),
  //vel("R407C", "T", 333.15, "Q", 0, "V", 95.96e-6, 1e-2),
  //vel("R407C", "T", 333.15, "Q", 1, "V", 16.38e-6, 1e-2),
  //vel("R404A", "T", 243.15, "Q", 0, "V", 264.67e-6, 1e-2),
  //vel("R404A", "T", 243.15, "Q", 1, "V", 10.13e-6, 1e-2),
  //vel("R404A", "T", 333.15, "Q", 0, "V", 73.92e-6, 1e-2),
  //vel("R404A", "T", 333.15, "Q", 1, "V", 18.56e-6, 1e-2),
  //vel("R507A", "T", 243.15, "Q", 0, "V", 284.59e-6, 3e-2),
  //vel("R507A", "T", 243.15, "Q", 1, "V", 9.83e-6, 1e-2),
  //vel("R507A", "T", 333.15, "Q", 0, "V", 74.37e-6, 1e-2),
  //vel("R507A", "T", 333.15, "Q", 1, "V", 19.35e-6, 1e-2),

  // From Arp, NIST, 1998
  vel("Helium", "T", 3.6, "P", 0.180e6, "V", 3.745e-6, 1e-2),
  vel("Helium", "T", 50, "P", 0.180e6, "V", 6.376e-6, 1e-2),
  vel("Helium", "T", 400, "P", 0.180e6, "V", 24.29e-6, 1e-2),

  // From Shan, ASHRAE, 2000
  vel("R23", "T", 180, "Dmolar", 21097, "V", 353.88e-6, 1e-4),
  vel("R23", "T", 420, "Dmolar", 7564, "V", 39.459e-6, 1e-4),
  vel("R23", "T", 370, "Dmolar", 32.62, "V", 18.213e-6, 1e-4),

  // From Friend, JPCRD, 1991
  vel("Ethane", "T", 100, "Dmolar", 21330, "V", 878.6e-6, 1e-2),
  vel("Ethane", "T", 430, "Dmolar", 12780, "V", 58.70e-6, 1e-2),
  vel("Ethane", "T", 500, "Dmolar", 11210, "V", 48.34e-6, 1e-2),

  // From Xiang, JPCRD, 2006
  vel("Methanol", "T", 300, "Dmass", 0.12955, "V", 0.009696e-3, 1e-3),
  vel("Methanol", "T", 300, "Dmass", 788.41, "V", 0.5422e-3, 1e-3),
  vel("Methanol", "T", 630, "Dmass", 0.061183, "V", 0.02081e-3, 1e-3),
  vel("Methanol", "T", 630, "Dmass", 888.50, "V", 0.2405e-3, 1e-1),  // They use a different EOS in the high pressure region

  // From REFPROP 9.1 since no data provided
  vel("n-Butane", "T", 150, "Q", 0, "V", 0.0013697657668, 1e-4),
  vel("n-Butane", "T", 400, "Q", 1, "V", 1.2027464524762453e-005, 1e-4),
  vel("IsoButane", "T", 120, "Q", 0, "V", 0.0060558450757844271, 1e-4),
  vel("IsoButane", "T", 400, "Q", 1, "V", 1.4761041187617117e-005, 2e-4),
  vel("R134a", "T", 175, "Q", 0, "V", 0.0017558494524138289, 1e-4),
  vel("R134a", "T", 360, "Q", 1, "V", 1.7140264998576107e-005, 1e-4),

  // From Tariq, JPCRD, 2014
  vel("Cyclohexane", "T", 300, "Dmolar", 1e-10, "V", 7.058e-6, 1e-4),
  vel("Cyclohexane", "T", 300, "Dmolar", 0.0430e3, "V", 6.977e-6, 1e-4),
  vel("Cyclohexane", "T", 300, "Dmolar", 9.1756e3, "V", 863.66e-6, 1e-4),
  vel("Cyclohexane", "T", 300, "Dmolar", 9.9508e3, "V", 2850.18e-6, 1e-4),
  vel("Cyclohexane", "T", 500, "Dmolar", 1e-10, "V", 11.189e-6, 1e-4),
  vel("Cyclohexane", "T", 500, "Dmolar", 6.0213e3, "V", 94.842e-6, 1e-4),
  vel("Cyclohexane", "T", 500, "Dmolar", 8.5915e3, "V", 380.04e-6, 1e-4),
  vel("Cyclohexane", "T", 700, "Dmolar", 1e-10, "V", 15.093e-6, 1e-4),
  vel("Cyclohexane", "T", 700, "Dmolar", 7.4765e3, "V", 176.749e-6, 1e-4),

  // From Avgeri, JPCRD, 2014
  vel("Benzene", "T", 300, "Dmass", 1e-10, "V", 7.625e-6, 1e-4),
  vel("Benzene", "T", 400, "Dmass", 1e-10, "V", 10.102e-6, 1e-4),
  vel("Benzene", "T", 550, "Dmass", 1e-10, "V", 13.790e-6, 1e-4),
  vel("Benzene", "T", 300, "Dmass", 875, "V", 608.52e-6, 1e-4),
  vel("Benzene", "T", 400, "Dmass", 760, "V", 211.74e-6, 1e-4),
  vel("Benzene", "T", 550, "Dmass", 500, "V", 60.511e-6, 1e-4),

  // From Cao, JPCRD, 2016
  vel("m-Xylene", "T", 300, "Dmolar", 1e-10, "V", 6.637e-6, 1e-4),
  vel("m-Xylene", "T", 300, "Dmolar", 0.04 * 1e3, "V", 6.564e-6, 1e-4),
  vel("m-Xylene", "T", 300, "Dmolar", 8.0849 * 1e3, "V", 569.680e-6, 1e-4),
  vel("m-Xylene", "T", 300, "Dmolar", 8.9421 * 1e3, "V", 1898.841e-6, 1e-4),
  vel("m-Xylene", "T", 400, "Dmolar", 1e-10, "V", 8.616e-6, 1e-4),
  vel("m-Xylene", "T", 400, "Dmolar", 0.04 * 1e3, "V", 8.585e-6, 1e-4),
  vel("m-Xylene", "T", 400, "Dmolar", 7.2282 * 1e3, "V", 238.785e-6, 1e-4),
  vel("m-Xylene", "T", 400, "Dmolar", 8.4734 * 1e3, "V", 718.950e-6, 1e-4),
  vel("m-Xylene", "T", 600, "Dmolar", 1e-10, "V", 12.841e-6, 1e-4),
  vel("m-Xylene", "T", 600, "Dmolar", 0.04 * 1e3, "V", 12.936e-6, 1e-4),
  vel("m-Xylene", "T", 600, "Dmolar", 7.6591 * 1e3, "V", 299.164e-6, 1e-4),

  // From Cao, JPCRD, 2016
  vel("o-Xylene", "T", 300, "Dmolar", 1e-10, "V", 6.670e-6, 1e-4),
  vel("o-Xylene", "T", 300, "Dmolar", 0.04 * 1e3, "V", 6.598e-6, 1e-4),
  vel("o-Xylene", "T", 300, "Dmolar", 8.2369 * 1e3, "V", 738.286e-6, 1e-4),
  vel("o-Xylene", "T", 300, "Dmolar", 8.7845 * 1e3, "V", 1645.436e-6, 1e-4),
  vel("o-Xylene", "T", 400, "Dmolar", 1e-10, "V", 8.658e-6, 1e-4),
  vel("o-Xylene", "T", 400, "Dmolar", 0.04 * 1e3, "V", 8.634e-6, 1e-4),
  vel("o-Xylene", "T", 400, "Dmolar", 7.4060 * 1e3, "V", 279.954e-6, 1e-4),
  vel("o-Xylene", "T", 400, "Dmolar", 8.2291 * 1e3, "V", 595.652e-6, 1e-4),
  vel("o-Xylene", "T", 600, "Dmolar", 1e-10, "V", 12.904e-6, 1e-4),
  vel("o-Xylene", "T", 600, "Dmolar", 0.04 * 1e3, "V", 13.018e-6, 1e-4),
  vel("o-Xylene", "T", 600, "Dmolar", 7.2408 * 1e3, "V", 253.530e-6, 1e-4),

  // From Balogun, JPCRD, 2016
  vel("p-Xylene", "T", 300, "Dmolar", 1e-10, "V", 6.604e-6, 1e-4),
  vel("p-Xylene", "T", 300, "Dmolar", 0.049 * 1e3, "V", 6.405e-6, 1e-4),
  vel("p-Xylene", "T", 300, "Dmolar", 8.0548 * 1e3, "V", 593.272e-6, 1e-4),
  vel("p-Xylene", "T", 300, "Dmolar", 8.6309 * 1e3, "V", 1266.337e-6, 1e-4),
  vel("p-Xylene", "T", 400, "Dmolar", 1e-10, "V", 8.573e-6, 1e-4),
  vel("p-Xylene", "T", 400, "Dmolar", 7.1995 * 1e3, "V", 239.202e-6, 1e-4),
  vel("p-Xylene", "T", 400, "Dmolar", 8.0735 * 1e3, "V", 484.512e-6, 1e-4),
  vel("p-Xylene", "T", 600, "Dmolar", 1e-10, "V", 12.777e-6, 1e-4),
  vel("p-Xylene", "T", 600, "Dmolar", 7.0985 * 1e3, "V", 209.151e-6, 1e-4),

  // From Mylona, JPCRD, 2014
  vel("EthylBenzene", "T", 617, "Dmass", 316, "V", 33.22e-6, 1e-2),

  // Heavy Water, IAPWS formulation
  vel("HeavyWater", "T", 0.5000 * 643.847, "Dmass", 3.07 * 358, "V", 12.0604912273 * 55.2651e-6, 1e-5),
  vel("HeavyWater", "T", 0.9000 * 643.847, "Dmass", 2.16 * 358, "V", 1.6561616211 * 55.2651e-6, 1e-5),
  vel("HeavyWater", "T", 1.2000 * 643.847, "Dmass", 0.8 * 358, "V", 0.7651099154 * 55.2651e-6, 1e-5),

  // Toluene, Avgeri, JPCRD, 2015
  vel("Toluene", "T", 300, "Dmass", 1e-10, "V", 7.023e-6, 1e-4),
  vel("Toluene", "T", 400, "Dmass", 1e-10, "V", 9.243e-6, 1e-4),
  vel("Toluene", "T", 550, "Dmass", 1e-10, "V", 12.607e-6, 1e-4),
  vel("Toluene", "T", 300, "Dmass", 865, "V", 566.78e-6, 1e-4),
  vel("Toluene", "T", 400, "Dmass", 770, "V", 232.75e-6, 1e-4),
  vel("Toluene", "T", 550, "Dmass", 550, "V", 80.267e-6, 1e-4),

};

class TransportValidationFixture
{
   protected:
    CoolPropDbl actual, x1, x2;
    shared_ptr<CoolProp::AbstractState> pState;
    CoolProp::input_pairs pair;

   public:
    TransportValidationFixture() = default;
    ~TransportValidationFixture() = default;
    void set_backend(const std::string& backend, const std::string& fluid_name) {
        pState.reset(CoolProp::AbstractState::factory(backend, fluid_name));
    }
    void set_pair(std::string& in1, double v1, std::string& in2, double v2) {
        double o1, o2;
        parameters iin1 = CoolProp::get_parameter_index(in1);
        parameters iin2 = CoolProp::get_parameter_index(in2);
        CoolProp::input_pairs pair = CoolProp::generate_update_pair(iin1, v1, iin2, v2, o1, o2);
        pState->update(pair, o1, o2);
    }
    void get_value(parameters key) {
        actual = pState->keyed_output(key);
    }
};

TEST_CASE_METHOD(TransportValidationFixture, "Compare viscosities against published data", "[viscosity],[transport]") {
    int inputsN = sizeof(viscosity_validation_data) / sizeof(viscosity_validation_data[0]);
    for (int i = 0; i < inputsN; ++i) {
        vel el = viscosity_validation_data[i];
        CHECK_NOTHROW(set_backend("HEOS", el.fluid));

        CAPTURE(el.fluid);
        CAPTURE(el.in1);
        CAPTURE(el.v1);
        CAPTURE(el.in2);
        CAPTURE(el.v2);
        CHECK_NOTHROW(set_pair(el.in1, el.v1, el.in2, el.v2));
        CHECK_NOTHROW(get_value(CoolProp::iviscosity));
        CAPTURE(el.expected);
        CAPTURE(actual);
        CHECK(std::abs(actual / el.expected - 1) < el.tol);
    }
}

vel conductivity_validation_data[] = {
  ///\todo Re-enable the conductivity tests that fail due to not having viscosity correlation

  // From Assael, JPCRD, 2013
  vel("Hexane", "T", 250, "Dmass", 700, "L", 137.62e-3, 1e-4),
  vel("Hexane", "T", 400, "Dmass", 2, "L", 23.558e-3, 1e-4),
  vel("Hexane", "T", 400, "Dmass", 650, "L", 129.28e-3, 3e-4),
  vel("Hexane", "T", 510, "Dmass", 2, "L", 36.772e-3, 1e-4),

  // From Assael, JPCRD, 2013
  vel("Heptane", "T", 250, "Dmass", 720, "L", 137.09e-3, 1e-4),
  vel("Heptane", "T", 400, "Dmass", 2, "L", 21.794e-3, 1e-4),
  vel("Heptane", "T", 400, "Dmass", 650, "L", 120.75e-3, 1e-4),
  vel("Heptane", "T", 535, "Dmass", 100, "L", 51.655e-3, 3e-3),  // Relaxed tolerance because conductivity was fit using older viscosity correlation

  // From Assael, JPCRD, 2013
  vel("Ethanol", "T", 300, "Dmass", 850, "L", 209.68e-3, 1e-4),
  vel("Ethanol", "T", 400, "Dmass", 2, "L", 26.108e-3, 1e-4),
  vel("Ethanol", "T", 400, "Dmass", 690, "L", 149.21e-3, 1e-4),
  vel("Ethanol", "T", 500, "Dmass", 10, "L", 39.594e-3, 1e-4),

  //// From Assael, JPCRD, 2012
  //vel("Toluene", "T", 298.15, "Dmass", 1e-15, "L", 10.749e-3, 1e-4),
  //vel("Toluene", "T", 298.15, "Dmass", 862.948, "L", 130.66e-3, 1e-4),
  //vel("Toluene", "T", 298.15, "Dmass", 876.804, "L", 136.70e-3, 1e-4),
  //vel("Toluene", "T", 595, "Dmass", 1e-15, "L", 40.538e-3, 1e-4),
  //vel("Toluene", "T", 595, "Dmass", 46.512, "L", 41.549e-3, 1e-4),
  //vel("Toluene", "T", 185, "Dmass", 1e-15, "L", 4.3758e-3, 1e-4),
  //vel("Toluene", "T", 185, "Dmass", 968.821, "L", 158.24e-3, 1e-4),

  // From Assael, JPCRD, 2012
  vel("SF6", "T", 298.15, "Dmass", 1e-13, "L", 12.952e-3, 1e-4),
  vel("SF6", "T", 298.15, "Dmass", 100, "L", 14.126e-3, 1e-4),
  vel("SF6", "T", 298.15, "Dmass", 1600, "L", 69.729e-3, 1e-4),
  vel("SF6", "T", 310, "Dmass", 1e-13, "L", 13.834e-3, 1e-4),
  vel("SF6", "T", 310, "Dmass", 1200, "L", 48.705e-3, 1e-4),
  vel("SF6", "T", 480, "Dmass", 100, "L", 28.847e-3, 1e-4),

  //// From Assael, JPCRD, 2012
  //vel("Benzene", "T", 290, "Dmass", 890, "L", 147.66e-3, 1e-4),
  //vel("Benzene", "T", 500, "Dmass", 2, "L", 30.174e-3, 1e-4),
  //vel("Benzene", "T", 500, "Dmass", 32, "L", 32.175e-3, 1e-4),
  //vel("Benzene", "T", 500, "Dmass", 800, "L", 141.24e-3, 1e-4),
  //vel("Benzene", "T", 575, "Dmass", 1.7, "L", 37.763e-3, 1e-4),

  // From Assael, JPCRD, 2011
  vel("Hydrogen", "T", 298.15, "Dmass", 1e-13, "L", 185.67e-3, 1e-4),
  vel("Hydrogen", "T", 298.15, "Dmass", 0.80844, "L", 186.97e-3, 1e-4),
  vel("Hydrogen", "T", 298.15, "Dmass", 14.4813, "L", 201.35e-3, 1e-4),
  vel("Hydrogen", "T", 35, "Dmass", 1e-13, "L", 26.988e-3, 1e-4),
  vel("Hydrogen", "T", 35, "Dmass", 30, "L", 0.0770177, 1e-4),  // Updated since Assael uses a different viscosity correlation
  vel("Hydrogen", "T", 18, "Dmass", 1e-13, "L", 13.875e-3, 1e-4),
  vel("Hydrogen", "T", 18, "Dmass", 75, "L", 104.48e-3, 1e-4),
  /*vel("ParaHydrogen", "T", 298.15, "Dmass", 1e-13, "L", 192.38e-3, 1e-4),
vel("ParaHydrogen", "T", 298.15, "Dmass", 0.80844, "L", 192.81e-3, 1e-4),
vel("ParaHydrogen", "T", 298.15, "Dmass", 14.4813, "L", 207.85e-3, 1e-4),
vel("ParaHydrogen", "T", 35, "Dmass", 1e-13, "L", 27.222e-3, 1e-4),
vel("ParaHydrogen", "T", 35, "Dmass", 30, "L", 70.335e-3, 1e-4),
vel("ParaHydrogen", "T", 18, "Dmass", 1e-13, "L", 13.643e-3, 1e-4),
vel("ParaHydrogen", "T", 18, "Dmass", 75, "L", 100.52e-3, 1e-4),*/

  // Some of these don't work
  vel("R125", "T", 341, "Dmass", 600, "L", 0.0565642978494, 2e-4),
  vel("R125", "T", 200, "Dmass", 1e-13, "L", 0.007036843623086, 2e-4),
  vel("IsoButane", "T", 390, "Dmass", 387.09520158645068, "L", 0.063039, 2e-4),
  vel("IsoButane", "T", 390, "Dmass", 85.76703973869482, "L", 0.036603, 2e-4),
  vel("n-Butane", "T", 415, "Dmass", 360.01895129934866, "L", 0.067045, 2e-4),
  vel("n-Butane", "T", 415, "Dmass", 110.3113177144, "L", 0.044449, 1e-4),

  // From Huber, FPE, 2005
  vel("n-Octane", "T", 300, "Dmolar", 6177.2, "L", 0.12836, 1e-4),
  vel("n-Nonane", "T", 300, "Dmolar", 5619.4, "L", 0.13031, 1e-4),
  //vel("n-Decane", "T", 300, "Dmass", 5150.4, "L", 0.13280, 1e-4), // no viscosity

  // From Huber, EF, 2004
  vel("n-Dodecane", "T", 300, "Dmolar", 4411.5, "L", 0.13829, 1e-4),
  vel("n-Dodecane", "T", 500, "Dmolar", 3444.7, "L", 0.09384, 1e-4),
  vel("n-Dodecane", "T", 660, "Dmolar", 1500.98, "L", 0.090346, 1e-4),

  // From REFPROP 9.1 since no data provided in Marsh, 2002
  vel("n-Propane", "T", 368, "Q", 0, "L", 0.07282154952457, 1e-3),
  vel("n-Propane", "T", 368, "Dmolar", 1e-10, "L", 0.0266135388745317, 1e-4),

  // From Perkins, JCED, 2011
  //vel("R1234yf", "T", 250, "Dmass", 2.80006, "L", 0.0098481, 1e-4),
  //vel("R1234yf", "T", 300, "Dmass", 4.671556, "L", 0.013996, 1e-4),
  //vel("R1234yf", "T", 250, "Dmass", 1299.50, "L", 0.088574, 1e-4),
  //vel("R1234yf", "T", 300, "Dmass", 1182.05, "L", 0.075245, 1e-4),
  //vel("R1234ze(E)", "T", 250, "Dmass", 2.80451, "L", 0.0098503, 1e-4),
  //vel("R1234ze(E)", "T", 300, "Dmass", 4.67948, "L", 0.013933, 1e-4),
  //vel("R1234ze(E)", "T", 250, "Dmass", 1349.37, "L", 0.10066, 1e-4),
  //vel("R1234ze(E)", "T", 300, "Dmass", 1233.82, "L", 0.085389, 1e-4),

  // From Laesecke, IJR 1995
  vel("R123", "T", 180, "Dmass", 1739, "L", 110.9e-3, 2e-4),
  vel("R123", "T", 180, "Dmass", 0.2873e-2, "L", 2.473e-3, 1e-3),
  vel("R123", "T", 430, "Dmass", 996.35, "L", 45.62e-3, 1e-3),
  vel("R123", "T", 430, "Dmass", 166.9, "L", 21.03e-3, 1e-3),

  // From Huber, JPCRD, 2016
  vel("CO2", "T", 250.0, "Dmass", 1e-6, "L", 12.99e-3, 1e-3),
  vel("CO2", "T", 250.0, "Dmass", 2.0, "L", 13.05e-3, 1e-3),
  vel("CO2", "T", 250.0, "Dmass", 1058.0, "L", 140.00e-3, 1e-4),
  vel("CO2", "T", 310.0, "Dmass", 400.0, "L", 73.04e-3, 1e-4),

  // From Friend, JPCRD, 1991
  vel("Ethane", "T", 100, "Dmass", 1e-13, "L", 3.46e-3, 1e-2),
  vel("Ethane", "T", 230, "Dmolar", 16020, "L", 126.2e-3, 1e-2),
  vel("Ethane", "T", 440, "Dmolar", 1520, "L", 45.9e-3, 1e-2),
  vel("Ethane", "T", 310, "Dmolar", 4130, "L", 45.4e-3, 1e-2),

  // From Lemmon and Jacobsen, JPCRD, 2004
  vel("Nitrogen", "T", 100, "Dmolar", 1e-14, "L", 9.27749e-3, 1e-4),
  vel("Nitrogen", "T", 300, "Dmolar", 1e-14, "L", 25.9361e-3, 1e-4),
  vel("Nitrogen", "T", 100, "Dmolar", 25000, "L", 103.834e-3, 1e-4),
  vel("Nitrogen", "T", 200, "Dmolar", 10000, "L", 36.0099e-3, 1e-4),
  vel("Nitrogen", "T", 300, "Dmolar", 5000, "L", 32.7694e-3, 1e-4),
  vel("Nitrogen", "T", 126.195, "Dmolar", 11180, "L", 675.800e-3, 1e-4),
  vel("Argon", "T", 100, "Dmolar", 1e-14, "L", 6.36587e-3, 1e-4),
  vel("Argon", "T", 300, "Dmolar", 1e-14, "L", 17.8042e-3, 1e-4),
  vel("Argon", "T", 100, "Dmolar", 33000, "L", 111.266e-3, 1e-4),
  vel("Argon", "T", 200, "Dmolar", 10000, "L", 26.1377e-3, 1e-4),
  vel("Argon", "T", 300, "Dmolar", 5000, "L", 23.2302e-3, 1e-4),
  vel("Argon", "T", 150.69, "Dmolar", 13400, "L", 856.793e-3, 1e-4),
  vel("Oxygen", "T", 100, "Dmolar", 1e-14, "L", 8.94334e-3, 1e-4),
  vel("Oxygen", "T", 300, "Dmolar", 1e-14, "L", 26.4403e-3, 1e-4),
  vel("Oxygen", "T", 100, "Dmolar", 35000, "L", 146.044e-3, 1e-4),
  vel("Oxygen", "T", 200, "Dmolar", 10000, "L", 34.6124e-3, 1e-4),
  vel("Oxygen", "T", 300, "Dmolar", 5000, "L", 32.5491e-3, 1e-4),
  vel("Oxygen", "T", 154.6, "Dmolar", 13600, "L", 377.476e-3, 1e-4),
  vel("Air", "T", 100, "Dmolar", 1e-14, "L", 9.35902e-3, 1e-4),
  vel("Air", "T", 300, "Dmolar", 1e-14, "L", 26.3529e-3, 1e-4),
  vel("Air", "T", 100, "Dmolar", 28000, "L", 119.221e-3, 1e-4),
  vel("Air", "T", 200, "Dmolar", 10000, "L", 35.3185e-3, 1e-4),
  vel("Air", "T", 300, "Dmolar", 5000, "L", 32.6062e-3, 1e-4),
  vel("Air", "T", 132.64, "Dmolar", 10400, "L", 75.6231e-3, 1e-4),

  // Huber, JPCRD, 2012
  vel("Water", "T", 298.15, "Dmass", 1e-14, "L", 18.4341883e-3, 1e-6),
  vel("Water", "T", 298.15, "Dmass", 998, "L", 607.712868e-3, 1e-6),
  vel("Water", "T", 298.15, "Dmass", 1200, "L", 799.038144e-3, 1e-6),
  vel("Water", "T", 873.15, "Dmass", 1e-14, "L", 79.1034659e-3, 1e-6),
  vel("Water", "T", 647.35, "Dmass", 1, "L", 51.9298924e-3, 1e-6),
  vel("Water", "T", 647.35, "Dmass", 122, "L", 130.922885e-3, 2e-4),
  vel("Water", "T", 647.35, "Dmass", 222, "L", 367.787459e-3, 2e-4),
  vel("Water", "T", 647.35, "Dmass", 272, "L", 757.959776e-3, 2e-4),
  vel("Water", "T", 647.35, "Dmass", 322, "L", 1443.75556e-3, 2e-4),
  vel("Water", "T", 647.35, "Dmass", 372, "L", 650.319402e-3, 2e-4),
  vel("Water", "T", 647.35, "Dmass", 422, "L", 448.883487e-3, 2e-4),
  vel("Water", "T", 647.35, "Dmass", 750, "L", 600.961346e-3, 2e-4),

  // From Shan, ASHRAE, 2000
  vel("R23", "T", 180, "Dmolar", 21097, "L", 143.19e-3, 1e-4),
  vel("R23", "T", 420, "Dmolar", 7564, "L", 50.19e-3, 2e-4),
  vel("R23", "T", 370, "Dmolar", 32.62, "L", 17.455e-3, 1e-4),

  // From REFPROP 9.1 since no sample data provided in Tufeu
  vel("Ammonia", "T", 310, "Dmolar", 34320, "L", 0.45223303481784971, 1e-4),
  vel("Ammonia", "T", 395, "Q", 0, "L", 0.2264480769301, 2e-3),

  // From Hands, Cryogenics, 1981
  vel("Helium", "T", 800, "P", 1e5, "L", 0.3085, 1e-2),
  vel("Helium", "T", 300, "P", 1e5, "L", 0.1560, 1e-2),
  vel("Helium", "T", 20, "P", 1e5, "L", 0.0262, 1e-2),
  vel("Helium", "T", 8, "P", 1e5, "L", 0.0145, 1e-2),
  vel("Helium", "T", 4, "P", 20e5, "L", 0.0255, 1e-2),
  vel("Helium", "T", 8, "P", 20e5, "L", 0.0308, 1e-2),
  vel("Helium", "T", 20, "P", 20e5, "L", 0.0328, 1e-2),
  vel("Helium", "T", 4, "P", 100e5, "L", 0.0385, 3e-2),
  vel("Helium", "T", 8, "P", 100e5, "L", 0.0566, 3e-2),
  vel("Helium", "T", 20, "P", 100e5, "L", 0.0594, 1e-2),
  vel("Helium", "T", 4, "P", 1e5, "L", 0.0186, 1e-2),
  vel("Helium", "T", 4, "P", 2e5, "L", 0.0194, 1e-2),
  vel("Helium", "T", 5.180, "P", 2.3e5, "L", 0.0195, 1e-1),
  vel("Helium", "T", 5.2, "P", 2.3e5, "L", 0.0202, 1e-1),
  vel("Helium", "T", 5.230, "P", 2.3e5, "L", 0.0181, 1e-1),
  vel("Helium", "T", 5.260, "P", 2.3e5, "L", 0.0159, 1e-1),
  vel("Helium", "T", 5.3, "P", 2.3e5, "L", 0.0149, 1e-1),

  // Geller, IJT, 2001 - based on experimental data, no validation data provided
  //vel("R404A", "T", 253.03, "P", 0.101e6, "L", 0.00991, 0.03),
  //vel("R404A", "T", 334.38, "P", 2.176e6, "L", 19.93e-3, 0.03),
  //vel("R407C", "T", 253.45, "P", 0.101e6, "L", 0.00970, 0.03),
  //vel("R407C", "T", 314.39, "P", 0.458e6, "L", 14.87e-3, 0.03),
  //vel("R410A", "T", 260.32, "P", 0.101e6, "L", 0.01043, 0.03),
  //vel("R410A", "T", 332.09, "P", 3.690e6, "L", 22.76e-3, 0.03),
  //vel("R507A", "T", 254.85, "P", 0.101e6, "L", 0.01007, 0.03),
  //vel("R507A", "T", 333.18, "P", 2.644e6, "L", 21.31e-3, 0.03),

  // From REFPROP 9.1 since no data provided
  vel("R134a", "T", 240, "D", 1e-10, "L", 0.008698768, 1e-4),
  vel("R134a", "T", 330, "D", 1e-10, "L", 0.015907606, 1e-4),
  vel("R134a", "T", 330, "Q", 0, "L", 0.06746432253, 1e-4),
  vel("R134a", "T", 240, "Q", 1, "L", 0.00873242359, 1e-4),

  // Mylona, JPCRD, 2014 - dense check values taken from the implementation in REFPROP 10.0
  vel("o-Xylene", "T", 635, "D", 270, "L", 0.10387803232507065, 5e-3),
  vel("m-Xylene", "T", 616, "D", 220, "L", 0.10330950977360005, 5e-3),
  vel("p-Xylene", "T", 620, "D", 287, "L", 0.09804128875928533, 5e-3),
  vel("EthylBenzene", "T", 617, "D", 316, "L", 0.1479194493736235, 5e-2),
  // dilute values
  vel("o-Xylene", "T", 300, "D", 1e-12, "L", 13.68e-3, 1e-3),
  vel("o-Xylene", "T", 600, "D", 1e-12, "L", 41.6e-3, 1e-3),
  vel("m-Xylene", "T", 300, "D", 1e-12, "L", 9.45e-3, 1e-3),
  vel("m-Xylene", "T", 600, "D", 1e-12, "L", 40.6e-3, 1e-3),
  vel("p-Xylene", "T", 300, "D", 1e-12, "L", 10.57e-3, 1e-3),
  vel("p-Xylene", "T", 600, "D", 1e-12, "L", 41.73e-3, 1e-3),
  vel("EthylBenzene", "T", 300, "D", 1e-12, "L", 9.71e-3, 1e-3),
  vel("EthylBenzene", "T", 600, "D", 1e-12, "L", 41.14e-3, 1e-3),

  // Friend, JPCRD, 1989
  vel("Methane", "T", 100, "D", 1e-12, "L", 9.83e-3, 1e-3),
  vel("Methane", "T", 400, "D", 1e-12, "L", 49.96e-3, 1e-3),
  vel("Methane", "T", 182, "Q", 0, "L", 82.5e-3, 5e-3),
  vel("Methane", "T", 100, "Dmolar", 28.8e3, "L", 234e-3, 1e-2),

  // Sykioti, JPCRD, 2013
  vel("Methanol", "T", 300, "Dmass", 850, "L", 241.48e-3, 1e-2),
  vel("Methanol", "T", 400, "Dmass", 2, "L", 25.803e-3, 1e-2),
  vel("Methanol", "T", 400, "Dmass", 690, "L", 183.59e-3, 1e-2),
  vel("Methanol", "T", 500, "Dmass", 10, "L", 40.495e-3, 1e-2),

  // Heavy Water, IAPWS formulation
  vel("HeavyWater", "T", 0.5000 * 643.847, "Dmass", 3.07 * 358, "V", 835.786416818 * 0.742128e-3, 1e-5),
  vel("HeavyWater", "T", 0.9000 * 643.847, "Dmass", 2.16 * 358, "V", 627.777590127 * 0.742128e-3, 1e-5),
  vel("HeavyWater", "T", 1.2000 * 643.847, "Dmass", 0.8 * 358, "V", 259.605241187 * 0.742128e-3, 1e-5),

  // Vassiliou, JPCRD, 2015
  vel("Cyclopentane", "T", 512, "Dmass", 1e-12, "L", 37.042e-3, 1e-5),
  vel("Cyclopentane", "T", 512, "Dmass", 400, "L", 69.698e-3, 1e-1),
  vel("Isopentane", "T", 460, "Dmass", 1e-12, "L", 35.883e-3, 1e-4),
  vel("Isopentane", "T", 460, "Dmass", 329.914, "L", 59.649e-3, 1e-1),
  vel("n-Pentane", "T", 460, "Dmass", 1e-12, "L", 34.048e-3, 1e-5),
  vel("n-Pentane", "T", 460, "Dmass", 377.687, "L", 71.300e-3, 1e-1),
};

TEST_CASE_METHOD(TransportValidationFixture, "Compare thermal conductivities against published data", "[conductivity],[transport]") {
    int inputsN = sizeof(conductivity_validation_data) / sizeof(conductivity_validation_data[0]);
    for (int i = 0; i < inputsN; ++i) {
        vel el = conductivity_validation_data[i];
        CHECK_NOTHROW(set_backend("HEOS", el.fluid));
        CAPTURE(el.fluid);
        CAPTURE(el.in1);
        CAPTURE(el.v1);
        CAPTURE(el.in2);
        CAPTURE(el.v2);
        CHECK_NOTHROW(set_pair(el.in1, el.v1, el.in2, el.v2));
        get_value(CoolProp::iconductivity);
        CAPTURE(el.expected);
        CAPTURE(actual);
        CHECK(std::abs(actual / el.expected - 1) < el.tol);
    }
}

}; /* namespace TransportValidation */

static CoolProp::input_pairs inputs[] = {
  CoolProp::DmolarT_INPUTS,
  //CoolProp::SmolarT_INPUTS,
  //CoolProp::HmolarT_INPUTS,
  //CoolProp::TUmolar_INPUTS,

  //    CoolProp::DmolarP_INPUTS,
  //    CoolProp::DmolarHmolar_INPUTS,
  //    CoolProp::DmolarSmolar_INPUTS,
  //    CoolProp::DmolarUmolar_INPUTS,
  //
  //    CoolProp::HmolarP_INPUTS,
  //    CoolProp::PSmolar_INPUTS,
  //    CoolProp::PUmolar_INPUTS,
  //
  /*
    CoolProp::HmolarSmolar_INPUTS,
    CoolProp::HmolarUmolar_INPUTS,
    CoolProp::SmolarUmolar_INPUTS
    */
};

class ConsistencyFixture
{
   protected:
    CoolPropDbl hmolar, pmolar, smolar, umolar, rhomolar, T, p, x1, x2;
    shared_ptr<CoolProp::AbstractState> pState;
    CoolProp::input_pairs pair;

   public:
    ConsistencyFixture() = default;
    ~ConsistencyFixture() = default;
    void set_backend(const std::string& backend, const std::string& fluid_name) {
        pState.reset(CoolProp::AbstractState::factory(backend, fluid_name));
    }
    void set_pair(CoolProp::input_pairs pair) {
        this->pair = pair;
    }
    void set_TP(CoolPropDbl T, CoolPropDbl p) {
        this->T = T;
        this->p = p;
        CoolProp::AbstractState& State = *pState;

        // Start with T,P as inputs, cycle through all the other pairs that are supported
        State.update(CoolProp::PT_INPUTS, p, T);

        // Set the other state variables
        rhomolar = State.rhomolar();
        hmolar = State.hmolar();
        smolar = State.smolar();
        umolar = State.umolar();
    }
    void get_variables() {

        switch (pair) {
            /// In this group, T is one of the known inputs, iterate for the other one (easy)
            case CoolProp::HmolarT_INPUTS:
                x1 = hmolar;
                x2 = T;
                break;
            case CoolProp::SmolarT_INPUTS:
                x1 = smolar;
                x2 = T;
                break;
            case CoolProp::TUmolar_INPUTS:
                x1 = T;
                x2 = umolar;
                break;
            case CoolProp::DmolarT_INPUTS:
                x1 = rhomolar;
                x2 = T;
                break;

            /// In this group, D is one of the known inputs, iterate for the other one (a little bit harder)
            case CoolProp::DmolarHmolar_INPUTS:
                x1 = rhomolar;
                x2 = hmolar;
                break;
            case CoolProp::DmolarSmolar_INPUTS:
                x1 = rhomolar;
                x2 = smolar;
                break;
            case CoolProp::DmolarUmolar_INPUTS:
                x1 = rhomolar;
                x2 = umolar;
                break;
            case CoolProp::DmolarP_INPUTS:
                x1 = rhomolar;
                x2 = p;
                break;

            /// In this group, p is one of the known inputs (a little less easy)
            case CoolProp::HmolarP_INPUTS:
                x1 = hmolar;
                x2 = p;
                break;
            case CoolProp::PSmolar_INPUTS:
                x1 = p;
                x2 = smolar;
                break;
            case CoolProp::PUmolar_INPUTS:
                x1 = p;
                x2 = umolar;
                break;

            case CoolProp::HmolarSmolar_INPUTS:
                x1 = hmolar;
                x2 = smolar;
                break;
            case CoolProp::SmolarUmolar_INPUTS:
                x1 = smolar;
                x2 = umolar;
                break;

            default:
                throw CoolProp::ValueError();
        }
    }
    void single_phase_consistency_check() {
        CoolProp::AbstractState& State = *pState;
        State.update(pair, x1, x2);

        // Make sure we end up back at the same temperature and pressure we started out with
        if (State.Q() < 1 && State.Q() > 0) throw CoolProp::ValueError(format("Q [%g] is between 0 and 1; two-phase solution", State.Q()));
        if (std::abs(T - State.T()) > 1e-2) throw CoolProp::ValueError(format("Error on T [%Lg K] is greater than 1e-2", std::abs(State.T() - T)));
        if (std::abs(p - State.p()) / p * 100 > 1e-2)
            throw CoolProp::ValueError(format("Error on p [%Lg %%] is greater than 1e-2 %%", std::abs(p - State.p()) / p * 100));
    }
    void subcritical_pressure_liquid() {
        // Subcritical pressure liquid
        int inputsN = sizeof(inputs) / sizeof(inputs[0]);
        // Geometric scaling (p *= 3) — no FP-counter-accumulation issue; ~3-5 iters.
        for (double p = pState->p_triple() * 1.1; p < pState->p_critical(); p *= 3) {  // NOLINT(cert-flp30-c)
            double Ts = PropsSI("T", "P", p, "Q", 0, "Water");
            double Tmelt = pState->melting_line(CoolProp::iT, CoolProp::iP, p);
            // Test scaffold: T += 0.1 over a ~100 K range gives ~1e-14
            // cumulative error which is far below the property tolerance
            // any of the inner CHECKs use.
            for (double T = Tmelt; T < Ts - 0.1; T += 0.1) {  // NOLINT(cert-flp30-c)
                CHECK_NOTHROW(set_TP(T, p));

                for (int i = 0; i < inputsN; ++i) {
                    CoolProp::input_pairs pair = inputs[i];
                    std::string pair_desc = CoolProp::get_input_pair_short_desc(pair);
                    set_pair(pair);
                    CAPTURE(pair_desc);
                    CAPTURE(T);
                    CAPTURE(p);
                    get_variables();
                    CAPTURE(x1);
                    CAPTURE(x2);
                    CAPTURE(Ts);
                    CHECK_NOTHROW(single_phase_consistency_check());
                    double rhomolar_RP = PropsSI("Dmolar", "P", p, "T", T, "REFPROP::Water");
                    if (ValidNumber(rhomolar_RP)) {
                        CAPTURE(rhomolar_RP);
                        CAPTURE(rhomolar);
                        CHECK(std::abs((rhomolar_RP - rhomolar) / rhomolar) < 1e-3);
                    }
                }
            }
        }
    }
};

TEST_CASE_METHOD(ConsistencyFixture, "Test all input pairs for Water using all valid backends", "[consistency]") {
    CHECK_NOTHROW(set_backend("HEOS", "Water"));
    subcritical_pressure_liquid();

    //    int inputsN = sizeof(inputs)/sizeof(inputs[0]);
    //    for (double p = 600000; p < pState->pmax(); p *= 3)
    //    {
    //        for (double T = 220; T < pState->Tmax(); T += 1)
    //        {
    //            CHECK_NOTHROW(set_TP(T, p));
    //
    //            for (int i = 0; i < inputsN; ++i)
    //            {
    //                CoolProp::input_pairs pair = inputs[i];
    //                std::string pair_desc = CoolProp::get_input_pair_short_desc(pair);
    //                set_pair(pair);
    //                CAPTURE(pair_desc);
    //                CAPTURE(T);
    //                CAPTURE(p);
    //                get_variables();
    //                CAPTURE(x1);
    //                CAPTURE(x2);
    //                CHECK_NOTHROW(single_phase_consistency_check());
    //            }
    //        }
    //    }
}

TEST_CASE("Test saturation properties for a few fluids", "[saturation],[slow]") {
    SECTION("sat_p") {
        std::vector<double> pv = linspace(Props1SI("CO2", "ptriple"), Props1SI("CO2", "pcrit") - 1e-6, 5);

        SECTION("All pressures are ok")
        for (double i : pv) {
            CAPTURE(i);
            double T = CoolProp::PropsSI("T", "P", i, "Q", 0, "CO2");
        }
    }
}

class HumidAirDewpointFixture
{
   public:
    shared_ptr<CoolProp::AbstractState> AS;
    std::vector<std::string> fluids;
    std::vector<double> z;
    void setup(double zH2O) {
        double z_Air[4] = {0.7810, 0.2095, 0.0092, 0.0003};  // N2, O2, Ar, CO2
        z.resize(5);
        z[0] = zH2O;
        for (int i = 0; i < 4; ++i) {
            z[i + 1] = (1 - zH2O) * z_Air[i];
        }
    }
    void run_p(double p) {
        CAPTURE(p);
        // Integer-indexed sweep (cert-flp30-c): zH2O = 0.999, 0.998, ...,
        // 0.001 (999 samples), exactly preserving the original loop's
        // exit condition without 1e-3 step accumulation.
        constexpr std::size_t N_z = 999;
        for (std::size_t i = 0; i < N_z; ++i) {
            const double zH2O = 0.999 - 0.001 * i;
            setup(zH2O);
            AS->set_mole_fractions(z);
            CAPTURE(zH2O);
            CHECK_NOTHROW(AS->update(PQ_INPUTS, p, 1));
            if (AS->T() < 273.15) {
                break;
            }
        }
    }
    void run_checks() {
        fluids = strsplit("Water&Nitrogen&Oxygen&Argon&CO2", '&');
        AS.reset(AbstractState::factory("HEOS", fluids));
        run_p(1e5);
        run_p(1e6);
        run_p(1e7);
    }
};
//TEST_CASE_METHOD(HumidAirDewpointFixture, "Humid air dewpoint calculations", "[humid_air_dewpoint]") {
//    run_checks();
//}

TEST_CASE("HAPropsSI two-water-content inputs that uniquely determine dry-bulb temperature (issue #2670)", "[humid_air][2670]") {
    // When one water-content input fixes psi_w independently of T and the other is
    // relative humidity (which depends on T), the system has a unique solution for T.
    // Note: HAPropsSI catches all exceptions internally and returns _HUGE on error,
    // so we test ValidNumber() rather than CHECK_THROWS / CHECK_NOTHROW.
    double p = 101325.0;
    double T_dp = 283.15;  // 10 °C dew-point
    double R = 0.8;        // 80 % relative humidity

    SECTION("T_dp + R gives dry-bulb temperature") {
        // This combination was broken in v6.3.0.
        double T_drybulb = HumidAir::HAPropsSI("T", "D", T_dp, "R", R, "P", p);
        CHECK(ValidNumber(T_drybulb));
        CHECK(T_drybulb >= T_dp - 1e-6);

        // Cross-check: round-trip T_dp == DewPoint(T_drybulb, R, P)
        double T_dp_check = HumidAir::HAPropsSI("D", "T", T_drybulb, "R", R, "P", p);
        CHECK(ValidNumber(T_dp_check));
        CHECK(std::abs(T_dp_check - T_dp) < 1e-4);
    }

    SECTION("W + R gives dry-bulb temperature") {
        // Derive W from the known T_dp + R state so we can verify consistency.
        double W = HumidAir::HAPropsSI("W", "D", T_dp, "R", R, "P", p);
        REQUIRE(ValidNumber(W));

        double T_drybulb = HumidAir::HAPropsSI("T", "W", W, "R", R, "P", p);
        CHECK(ValidNumber(T_drybulb));
        CHECK(T_drybulb >= T_dp - 1e-6);

        // Cross-check R round-trip
        double R_check = HumidAir::HAPropsSI("R", "T", T_drybulb, "W", W, "P", p);
        CHECK(ValidNumber(R_check));
        CHECK(std::abs(R_check - R) < 1e-6);
    }

    SECTION("W + T_dp returns invalid (both fix psi_w, T is unconstrained)") {
        double W = HumidAir::HAPropsSI("W", "D", T_dp, "R", R, "P", p);
        REQUIRE(ValidNumber(W));
        double result = HumidAir::HAPropsSI("T", "W", W, "D", T_dp, "P", p);
        CHECK(!ValidNumber(result));
    }
}

// ============================================================
// Virial cache correctness: calc_all_virials (static helper in HumidAirProp.cpp,
// invoked via fill_virial_cache) must produce HAPropsSI outputs consistent with
// the reference EOS virial keyed_output values.
//
// The function is not accessible here directly (it is static in HumidAirProp.cpp),
// so we test it end-to-end: compute HAPropsSI at conditions where the virial
// correction is significant, and compare to values derived from individual
// keyed_output calls assembled with the same mixing rule as the humid-air code.
// ============================================================

TEST_CASE("Humid-air virial-dependent properties are consistent with EOS virials", "[humid_air][virial_cache]") {
    // Verify that the HAPropsSI fugacity coefficient ('f') and compressibility ('Z')
    // are consistent with the individual B/C virial values from the EOS backends.
    // These quantities go through fill_virial_cache → calc_all_virials.

    const double P = 101325.0;
    const double W = 0.01;  // 10 g/kg — well within ideal-gas range for virials

    SECTION("compressibility Z is close to 1 at atmospheric conditions") {
        for (double T : {250.0, 273.15, 293.15, 333.15, 373.15}) {
            CAPTURE(T);
            double Z = HumidAir::HAPropsSI("Z", "T", T, "W", W, "P", P);
            // At atmospheric pressure humid air deviates less than 0.2% from ideal
            CHECK(Z == Catch::Approx(1.0).margin(2e-3));
        }
    }

    SECTION("HAPropsSI virial-path results reproduce across cache invalidation") {
        // Call at T1, T2, T1 again — the third must be bit-identical to the first.
        double Z_T1_a = HumidAir::HAPropsSI("Z", "T", 293.15, "W", W, "P", P);
        double Z_T2 = HumidAir::HAPropsSI("Z", "T", 333.15, "W", W, "P", P);
        double Z_T1_b = HumidAir::HAPropsSI("Z", "T", 293.15, "W", W, "P", P);
        (void)Z_T2;
        CHECK(Z_T1_a == Z_T1_b);
    }

    SECTION("HAPropsSI enthalpy cache-invalidation reproduces") {
        double H_T1_a = HumidAir::HAPropsSI("H", "T", 293.15, "W", W, "P", P);
        double H_T2 = HumidAir::HAPropsSI("H", "T", 333.15, "W", W, "P", P);
        double H_T1_b = HumidAir::HAPropsSI("H", "T", 293.15, "W", W, "P", P);
        (void)H_T2;
        CHECK(H_T1_a == H_T1_b);
        CHECK(H_T1_a > 0.0);
        CHECK(H_T2 > H_T1_a);
    }
}

// ============================================================
// Alpha0 cache correctness: calc_ideal_gas_alpha0 (via fill_alpha0_cache) must
// produce enthalpy/entropy consistent with the direct update() path.
//
// calc_ideal_gas_alpha0 is a static helper in HumidAirProp.cpp, not accessible
// here directly.  We verify it end-to-end by comparing HAPropsSI('H'/'S') against
// reference values computed via update() on the individual Air/Water backends, then
// manually assembling the same h/s formula the humid-air code uses.  Any mismatch
// in alpha0 or da0_dtau propagates into h and s.
// ============================================================

TEST_CASE("Humid-air h and s are consistent with individual EOS alpha0", "[humid_air][alpha0_cache]") {
    // Spot-check specific-enthalpy and specific-entropy of dry air (W=0) and
    // pure water vapour (W→1, W=0.99) via HAPropsSI against direct backend calls.
    // These quantities depend directly on the alpha0 cache (fill_alpha0_cache →
    // calc_ideal_gas_alpha0), so any bug there surfaces here.

    const double P = 101325.0;
    const double Tvals[] = {213.15, 253.15, 293.15, 333.15, 373.15, 400.0};
    const int NT = static_cast<int>(sizeof(Tvals) / sizeof(Tvals[0]));

    SECTION("dry air enthalpy monotonically increases with T") {
        // Simple sanity: h_dry_air(T2) > h_dry_air(T1) for T2 > T1.
        double h_prev = HumidAir::HAPropsSI("H", "T", Tvals[0], "W", 0.0, "P", P);
        for (int i = 1; i < NT; ++i) {
            double h = HumidAir::HAPropsSI("H", "T", Tvals[i], "W", 0.0, "P", P);
            CAPTURE(Tvals[i]);
            CHECK(h > h_prev);
            h_prev = h;
        }
    }

    SECTION("dry air entropy monotonically increases with T") {
        double s_prev = HumidAir::HAPropsSI("S", "T", Tvals[0], "W", 0.0, "P", P);
        for (int i = 1; i < NT; ++i) {
            double s = HumidAir::HAPropsSI("S", "T", Tvals[i], "W", 0.0, "P", P);
            CAPTURE(Tvals[i]);
            CHECK(s > s_prev);
            s_prev = s;
        }
    }

    SECTION("h round-trip: T recovered from H at W=0") {
        // Given (T, W=0, P), compute H, then invert back to T via (H, W=0).
        // Tests that the alpha0-derived enthalpy is internally consistent.
        // Note: H+S alone cannot determine T (humidity ratio is unknown), so
        // we keep W=0 fixed and invert H(T, W=0, P) → T.
        for (double T : Tvals) {
            CAPTURE(T);
            double H = HumidAir::HAPropsSI("H", "T", T, "W", 0.0, "P", P);
            REQUIRE(ValidNumber(H));
            double T_back = HumidAir::HAPropsSI("T", "H", H, "W", 0.0, "P", P);
            CHECK(T_back == Catch::Approx(T).epsilon(1e-6));
        }
    }
}

// ============================================================
// Comprehensive Humid Air Validation Tests
// Based on ASHRAE RP-1485 scenarios from HAValidation.py.
//
// Organised by tag so each group can be run independently:
//   [humid_air_validation]   parent tag – runs everything below
//   [ashrae_a61]             A.6.1: saturated air, T=-60..0 °C, P=101.325 kPa
//   [ashrae_a62]             A.6.2: saturated air, T=0..90 °C, P=101.325 kPa
//   [ashrae_a8]              A.8:   T=200 °C, W=0..1, P=101–10 000 kPa
//   [ashrae_a9]              A.9:   T=320 °C, W=0..1, P=101–10 000 kPa
//   [humid_air_physics]      Physical constraints over a (T,R,P) grid
//   [humid_air_roundtrip]    Round-trip consistency
//   [humid_air_aux]          Auxiliary functions: f_factor, p_ws, beta_H, kT, vbar_ws
// ============================================================

// -------------------------------------------------------
// Helpers shared across groups
// -------------------------------------------------------
namespace HumidAirTests {
// HAPropsSI wrapper that returns NaN rather than throwing
static double hap(const char* out, const char* k1, double v1, const char* k2, double v2, double p) {
    return HumidAir::HAPropsSI(out, k1, v1, k2, v2, "P", p);
}
}  // namespace HumidAirTests

// -------------------------------------------------------
// A.6.1  Saturated air at 101.325 kPa, T = -60 .. 0 °C
// -------------------------------------------------------
TEST_CASE("ASHRAE RP-1485 A.6.1: Saturated air properties, T=-60..0 C, P=101.325 kPa", "[humid_air_validation][ashrae_a61]") {
    // At R=1 every output must be a valid number; specific constraints below.
    // Known issue on unpatched master: T_wb returns inf at some temperatures –
    // recorded here as CHECK (not REQUIRE) so the suite continues to run.
    using namespace HumidAirTests;
    const double P = 101325.0;

    // 13 evenly-spaced points from -60 to 0 °C (step = 5 °C)
    for (int i = 0; i <= 12; ++i) {
        const double T = (273.15 - 60.0) + i * 5.0;
        SECTION(std::string("T = ") + std::to_string(static_cast<int>(T - 273.15)) + " C") {
            const double W = hap("W", "T", T, "R", 1.0, P);
            const double h = hap("H", "T", T, "R", 1.0, P);
            const double v = hap("V", "T", T, "R", 1.0, P);
            const double s = hap("S", "T", T, "R", 1.0, P);
            const double Twb = hap("Twb", "T", T, "R", 1.0, P);
            const double Tdp = hap("D", "T", T, "R", 1.0, P);

            // All outputs must be finite
            REQUIRE(ValidNumber(W));
            REQUIRE(ValidNumber(h));
            REQUIRE(ValidNumber(v));
            REQUIRE(ValidNumber(s));

            // Physical bounds
            CHECK(W >= 0.0);  // non-negative humidity ratio
            CHECK(v > 0.0);   // positive specific volume

            // At R=1: dew point and wet-bulb both equal dry-bulb temperature
            CHECK(ValidNumber(Tdp));
            CHECK(std::abs(Tdp - T) < 1e-3);  // T_dp == T_db at saturation
            CHECK(ValidNumber(Twb));
            CHECK(std::abs(Twb - T) < 1e-3);  // T_wb == T_db at saturation
        }
    }
}

// -------------------------------------------------------
// A.6.2  Saturated air at 101.325 kPa, T = 0 .. 90 °C
// -------------------------------------------------------
TEST_CASE("ASHRAE RP-1485 A.6.2: Saturated air properties, T=0..90 C, P=101.325 kPa", "[humid_air_validation][ashrae_a62]") {
    using namespace HumidAirTests;
    const double P = 101325.0;

    // 19 evenly-spaced points from 0 to 90 °C (step = 5 °C)
    for (int i = 0; i <= 18; ++i) {
        const double T = 273.15 + i * 5.0;
        SECTION(std::string("T = ") + std::to_string(static_cast<int>(T - 273.15)) + " C") {
            const double W = hap("W", "T", T, "R", 1.0, P);
            const double h = hap("H", "T", T, "R", 1.0, P);
            const double v = hap("V", "T", T, "R", 1.0, P);
            const double s = hap("S", "T", T, "R", 1.0, P);
            const double Twb = hap("Twb", "T", T, "R", 1.0, P);
            const double Tdp = hap("D", "T", T, "R", 1.0, P);

            REQUIRE(ValidNumber(W));
            REQUIRE(ValidNumber(h));
            REQUIRE(ValidNumber(v));
            REQUIRE(ValidNumber(s));

            CHECK(W > 0.0);  // above 0 °C there is always some saturation humidity
            CHECK(v > 0.0);
            // Note: W can exceed 1 kg/kg at high T (e.g. ~1.42 at 90 °C, R=1) — no upper cap here

            CHECK(ValidNumber(Tdp));
            CHECK(std::abs(Tdp - T) < 1e-3);
            CHECK(ValidNumber(Twb));
            CHECK(std::abs(Twb - T) < 1e-3);  // T_wb == T_db at R=1
        }
    }
}

// -------------------------------------------------------
// A.8   T = 200 °C (473.15 K), W = 0..1, multiple P
// -------------------------------------------------------
TEST_CASE("ASHRAE RP-1485 A.8: T=200 C, W=0..1 kg/kg, P=101 kPa..10 MPa", "[humid_air_validation][ashrae_a8]") {
    using namespace HumidAirTests;
    const double T = 200.0 + 273.15;  // 473.15 K

    // Pressure table and corresponding W ranges (limited at high P where T < T_sat)
    struct PressureCase
    {
        double p;
        std::vector<double> Wvals;
    };
    const PressureCase cases[] = {
      {101325.0, {0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {1000e3, {0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {2000e3, {0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {5000e3, {0.0, 0.05, 0.1, 0.15, 0.20, 0.25, 0.30}},  // T < T_sat(5 MPa), W limited
      {10000e3, {0.0, 0.05, 0.1}},                         // T < T_sat(10 MPa), W limited
    };

    for (const auto& pc : cases) {
        for (double W : pc.Wvals) {
            SECTION("P=" + std::to_string(static_cast<int>(pc.p / 1000)) + " kPa W=" + std::to_string(W)) {
                const double h = hap("H", "T", T, "W", W, pc.p);
                const double v = hap("V", "T", T, "W", W, pc.p);
                const double s = hap("S", "T", T, "W", W, pc.p);
                const double R = hap("R", "T", T, "W", W, pc.p);
                const double Twb = hap("Twb", "T", T, "W", W, pc.p);

                // All must be finite
                REQUIRE(ValidNumber(h));
                REQUIRE(ValidNumber(v));
                REQUIRE(ValidNumber(s));
                REQUIRE(ValidNumber(R));

                // Physical bounds
                CHECK(v > 0.0);
                CHECK(R >= 0.0);
                CHECK(R <= 1.0 + 1e-9);  // R ≤ 1 (allow tiny FP overshoot)

                // Wet-bulb must be ≤ dry-bulb
                CHECK(ValidNumber(Twb));
                if (ValidNumber(Twb)) {
                    CHECK(Twb <= T + 1e-6);

                    // Round-trip: from (T, W) → R, then from (T, R) → W_check
                    if (ValidNumber(R) && R > 1e-10) {
                        double W_check = hap("W", "T", T, "R", R, pc.p);
                        CHECK(ValidNumber(W_check));
                        if (ValidNumber(W_check)) {
                            CHECK(std::abs(W_check - W) < W * 1e-6 + 1e-10);
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------
// A.9   T = 320 °C (593.15 K), W = 0..1, multiple P
// -------------------------------------------------------
TEST_CASE("ASHRAE RP-1485 A.9: T=320 C, W=0..1 kg/kg, P=101 kPa..10 MPa", "[humid_air_validation][ashrae_a9]") {
    using namespace HumidAirTests;
    const double T = 320.0 + 273.15;  // 593.15 K

    struct PressureCase
    {
        double p;
        std::vector<double> Wvals;
    };
    const PressureCase cases[] = {
      {101325.0, {0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {1000e3, {0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {2000e3, {0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {5000e3, {0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
      {10000e3, {0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}},
    };

    for (const auto& pc : cases) {
        for (double W : pc.Wvals) {
            SECTION("P=" + std::to_string(static_cast<int>(pc.p / 1000)) + " kPa W=" + std::to_string(W)) {
                const double h = hap("H", "T", T, "W", W, pc.p);
                const double v = hap("V", "T", T, "W", W, pc.p);
                const double s = hap("S", "T", T, "W", W, pc.p);
                const double R = hap("R", "T", T, "W", W, pc.p);
                const double Twb = hap("Twb", "T", T, "W", W, pc.p);

                REQUIRE(ValidNumber(h));
                REQUIRE(ValidNumber(v));
                REQUIRE(ValidNumber(s));
                REQUIRE(ValidNumber(R));

                CHECK(v > 0.0);
                CHECK(R >= 0.0);
                CHECK(R <= 1.0 + 1e-9);

                CHECK(ValidNumber(Twb));
                if (ValidNumber(Twb)) {
                    CHECK(Twb <= T + 1e-6);

                    if (ValidNumber(R) && R > 1e-10) {
                        double W_check = hap("W", "T", T, "R", R, pc.p);
                        CHECK(ValidNumber(W_check));
                        if (ValidNumber(W_check)) {
                            CHECK(std::abs(W_check - W) < W * 1e-6 + 1e-10);
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------
// Physical constraints over a (T, R, P) grid
// -------------------------------------------------------
TEST_CASE("Humid air physical constraints: T_dp <= T_wb <= T_db, W >= 0, 0 <= R <= 1", "[humid_air_validation][humid_air_physics]") {
    using namespace HumidAirTests;

    // A representative grid spanning sub-freezing, normal, and near-boiling conditions
    const double Tvals[] = {243.15, 263.15, 283.15, 293.15, 313.15, 333.15, 353.15};
    const double Rvals[] = {0.1, 0.3, 0.5, 0.7, 0.9};
    const double Pvals[] = {50000.0, 101325.0, 300000.0};

    for (double T : Tvals) {
        for (double R : Rvals) {
            for (double p : Pvals) {
                SECTION("T=" + std::to_string(static_cast<int>(T - 273.15)) + " R=" + std::to_string(static_cast<int>(R * 100))
                        + "% P=" + std::to_string(static_cast<int>(p))) {
                    const double W = hap("W", "T", T, "R", R, p);
                    const double Tdp = hap("D", "T", T, "R", R, p);
                    const double Twb = hap("Twb", "T", T, "R", R, p);
                    const double R2 = hap("R", "T", T, "W", W, p);

                    // Basic validity
                    REQUIRE(ValidNumber(W));
                    CHECK(W >= 0.0);

                    // R round-trip
                    if (ValidNumber(R2)) {
                        CHECK(std::abs(R2 - R) < 1e-6);
                    }

                    // Temperature ordering: T_dp <= T_wb <= T_db
                    if (ValidNumber(Tdp)) {
                        CHECK(Tdp <= T + 1e-6);
                    }
                    if (ValidNumber(Twb)) {
                        CHECK(Twb <= T + 1e-6);
                        CHECK(Twb >= 100.0);  // wet-bulb never below ~100 K
                        if (ValidNumber(Tdp)) {
                            CHECK(Tdp <= Twb + 1e-4);  // dew point <= wet-bulb
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------
// Round-trip consistency: T+R → various outputs → back
// -------------------------------------------------------
TEST_CASE("Humid air round-trip consistency: outputs used as inputs recover the original state", "[humid_air_validation][humid_air_roundtrip]") {
    using namespace HumidAirTests;

    // Representative conditions: (T [K], R [0-1], P [Pa])
    struct Cond
    {
        double T, R, p;
    };
    const Cond conds[] = {
      {253.15, 0.5, 101325.0},  // -20 °C, 50% RH
      {273.15, 0.8, 101325.0},  //   0 °C, 80% RH (ice/liquid boundary)
      {293.15, 0.3, 101325.0},  //  20 °C, 30% RH (typical indoor)
      {293.15, 0.9, 101325.0},  //  20 °C, 90% RH
      {313.15, 0.6, 101325.0},  //  40 °C, 60% RH
      {293.15, 0.5, 200000.0},  //  20 °C, 50% RH at 2 bar
      {293.15, 0.5, 50000.0},   //  20 °C, 50% RH at 0.5 bar
    };

    for (const auto& c : conds) {
        SECTION("T=" + std::to_string(static_cast<int>(c.T - 273.15)) + " R=" + std::to_string(static_cast<int>(c.R * 100))
                + "% P=" + std::to_string(static_cast<int>(c.p))) {
            // Derive W from (T, R)
            const double W = hap("W", "T", c.T, "R", c.R, c.p);
            REQUIRE(ValidNumber(W));

            // W → R round-trip
            {
                double R_check = hap("R", "T", c.T, "W", W, c.p);
                REQUIRE(ValidNumber(R_check));
                CHECK(std::abs(R_check - c.R) < 1e-6);
            }

            // H round-trip: (T,R) → H → (H,R) → T
            {
                double H = hap("H", "T", c.T, "R", c.R, c.p);
                REQUIRE(ValidNumber(H));
                double T_check = hap("T", "H", H, "R", c.R, c.p);
                REQUIRE(ValidNumber(T_check));
                CHECK(std::abs(T_check - c.T) < 1e-3);
            }

            // Dew-point round-trip: (T,R) → Tdp → (T,Tdp) → W_check ≈ W
            {
                double Tdp = hap("D", "T", c.T, "R", c.R, c.p);
                REQUIRE(ValidNumber(Tdp));
                double W_check = hap("W", "T", c.T, "D", Tdp, c.p);
                REQUIRE(ValidNumber(W_check));
                CHECK(std::abs(W_check - W) < W * 1e-4 + 1e-12);
            }

            // Wet-bulb round-trip: (T,R) → Twb → (Twb,R) → T is NOT a valid round-trip
            // because (Twb, R) is overdetermined unless R=1.
            // Instead verify: compute T_wb and then verify T_wb(T_db, R) == T_wb.
            {
                double Twb = hap("Twb", "T", c.T, "R", c.R, c.p);
                CHECK(ValidNumber(Twb));
                if (ValidNumber(Twb)) {
                    double Twb_check = hap("Twb", "T", c.T, "W", W, c.p);
                    CHECK(ValidNumber(Twb_check));
                    if (ValidNumber(Twb_check)) {
                        CHECK(std::abs(Twb_check - Twb) < 1e-4);
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------
// Auxiliary functions: f_factor, p_ws, beta_H, kT, vbar_ws
// -------------------------------------------------------
TEST_CASE("Humid air auxiliary functions: physical validity and monotonicity", "[humid_air_validation][humid_air_aux]") {
    // HAProps_Aux(name, T[K], p[Pa], W[kg/kg], units_buf)
    char units[64];

    SECTION("Enhancement factor f >= 1.0 for all T and P") {
        // f = (actual vapour pressure) / (saturation vapour pressure).
        // The enhancement factor is always >= 1 due to dissolved air effects.
        const double Tvals[] = {213.15, 253.15, 273.15, 293.15, 313.15, 353.15, 423.15, 623.15};
        const double Pvals[] = {101325.0, 200000.0, 500000.0, 1000000.0, 10000000.0};
        for (double T : Tvals) {
            for (double p : Pvals) {
                double f = HumidAir::HAProps_Aux("f", T, p, 0.0, units);
                CAPTURE(T);
                CAPTURE(p);
                CHECK(ValidNumber(f));
                CHECK(f >= 1.0 - 1e-9);  // should be ≥ 1.0
            }
        }
    }

    SECTION("Enhancement factor increases with pressure at fixed T") {
        // At fixed T, f increases monotonically with p.
        const double T = 293.15;
        const double Pvals[] = {101325.0, 200000.0, 500000.0, 1000000.0, 5000000.0};
        double f_prev = 0.0;
        for (double p : Pvals) {
            double f = HumidAir::HAProps_Aux("f", T, p, 0.0, units);
            CAPTURE(p);
            CAPTURE(f);
            CHECK(f >= f_prev - 1e-9);
            f_prev = f;
        }
    }

    SECTION("Saturation pressure p_ws is positive and increases with T") {
        const double Tvals[] = {213.15, 233.15, 253.15, 273.15, 293.15, 313.15, 333.15, 353.15};
        double p_ws_prev = 0.0;
        for (double T : Tvals) {
            double p_ws = HumidAir::HAProps_Aux("p_ws", T, 101325.0, 0.0, units);
            CAPTURE(T);
            CAPTURE(p_ws);
            CHECK(ValidNumber(p_ws));
            CHECK(p_ws > 0.0);
            CHECK(p_ws > p_ws_prev);  // monotonically increasing with T
            p_ws_prev = p_ws;
        }
    }

    SECTION("Henry constant is positive for liquid water; not finite below ice point") {
        // beta_H represents the dissolution of air in liquid water.
        // Only defined for liquid water (T >= 273.16 K); returns inf below ice point.
        const double T_ice = 263.15;
        const double T_liq1 = 283.15;
        const double T_liq2 = 313.15;
        double bH_ice = HumidAir::HAProps_Aux("beta_H", T_ice, 101325.0, 0.0, units);
        double bH_liq1 = HumidAir::HAProps_Aux("beta_H", T_liq1, 101325.0, 0.0, units);
        double bH_liq2 = HumidAir::HAProps_Aux("beta_H", T_liq2, 101325.0, 0.0, units);
        CHECK(!ValidNumber(bH_ice));  // undefined below ice point — returns inf
        CHECK(bH_liq1 > 0.0);
        CHECK(bH_liq2 > 0.0);
    }

    SECTION("Isothermal compressibility kT is positive for liquid water") {
        const double Tvals[] = {283.15, 303.15, 323.15, 353.15};
        const double Pvals[] = {101325.0, 500000.0, 1000000.0};
        for (double T : Tvals) {
            for (double p : Pvals) {
                double kT = HumidAir::HAProps_Aux("kT", T, p, 0.0, units);
                CAPTURE(T);
                CAPTURE(p);
                CHECK(ValidNumber(kT));
                CHECK(kT > 0.0);  // compressibility is positive for stable liquid
            }
        }
    }

    SECTION("Saturated molar volume vbar_ws is physically sane") {
        // Molar volume of condensed water (liquid or ice) is ~1.8e-5 to ~2.0e-5
        // m^3/mol. Both branches must land in this range; in particular the ice
        // branch must not be off by the 1e6 factor of GH #2657. See also the
        // f_factor() computation in HumidAirProp.cpp which uses the correct
        // expression. Bound generously to allow for compression/expansion.
        const double Tvals[] = {213.15, 253.15, 273.15, 293.15, 333.15, 373.15};
        const double Pvals[] = {101325.0, 500000.0, 1000000.0};
        for (double T : Tvals) {
            for (double p : Pvals) {
                double v = HumidAir::HAProps_Aux("vbar_ws", T, p, 0.0, units);
                CAPTURE(T);
                CAPTURE(p);
                CHECK(ValidNumber(v));
                CHECK(v > 1.5e-5);
                CHECK(v < 2.5e-5);
            }
        }
    }

    SECTION("vbar_ws is continuous across the ice/liquid boundary (GH #2657)") {
        // Just below (ice) and just above (liquid) the triple-point temperature
        // 273.16 K the molar volume must be nearly equal — ice is only ~9%
        // larger than liquid water, not 1e6x smaller as in GH #2657.
        const double p = 101325.0;
        double v_ice = HumidAir::HAProps_Aux("vbar_ws", 273.15, p, 0.0, units);
        double v_liq = HumidAir::HAProps_Aux("vbar_ws", 273.17, p, 0.0, units);
        CAPTURE(v_ice);
        CAPTURE(v_liq);
        CHECK(ValidNumber(v_ice));
        CHECK(ValidNumber(v_liq));
        CHECK(v_ice > 0.9 * v_liq);
        CHECK(v_ice < 1.2 * v_liq);
    }

    SECTION("Virial coefficients Baa and Bww have expected signs") {
        // Second virial coefficient B: negative at moderate T (attractive interactions dominate)
        const double T = 293.15;
        double Baa = HumidAir::HAProps_Aux("Baa", T, 101325.0, 0.0, units);
        double Bww = HumidAir::HAProps_Aux("Bww", T, 101325.0, 0.0, units);
        CHECK(ValidNumber(Baa));
        CHECK(ValidNumber(Bww));
        CHECK(Baa < 0.0);  // Baa < 0 for air at ambient conditions
        CHECK(Bww < 0.0);  // Bww < 0 for water vapour at ambient conditions
    }

    SECTION("Cross virial coefficient Baw") {
        const double T = 293.15;
        double Baw = HumidAir::HAProps_Aux("Baw", T, 101325.0, 0.0, units);
        CHECK(ValidNumber(Baw));
        CHECK(Baw < 0.0);  // Baw is negative at typical atmospheric temperatures
    }
}

TEST_CASE("Test consistency between Gernert models in CoolProp and Gernert models in REFPROP", "[Gernert]") {
    // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available

    std::string mixes[] = {"CO2[0.7]&Argon[0.3]", "CO2[0.7]&Water[0.3]", "CO2[0.7]&Nitrogen[0.3]"};
    for (const auto& mix : mixes) {
        const char* ykey = mix.c_str();
        std::ostringstream ss1;
        ss1 << mix;
        SECTION(ss1.str(), "") {
            double Tnbp_CP, Tnbp_RP, R_RP, R_CP, pchk_CP, pchk_RP;
            CHECK_NOTHROW(R_CP = PropsSI("gas_constant", "P", 101325, "Q", 1, "HEOS::" + mix));
            CAPTURE(R_CP);
            CHECK_NOTHROW(R_RP = PropsSI("gas_constant", "P", 101325, "Q", 1, "REFPROP::" + mix));
            CAPTURE(R_RP);
            CHECK_NOTHROW(Tnbp_CP = PropsSI("T", "P", 101325, "Q", 1, "HEOS::" + mix));
            CAPTURE(Tnbp_CP);
            CHECK_NOTHROW(pchk_CP = PropsSI("P", "T", Tnbp_CP, "Q", 1, "HEOS::" + mix));
            CAPTURE(pchk_CP);
            CHECK_NOTHROW(Tnbp_RP = PropsSI("T", "P", 101325, "Q", 1, "REFPROP::" + mix));
            CAPTURE(Tnbp_RP);
            CHECK_NOTHROW(pchk_RP = PropsSI("P", "T", Tnbp_RP, "Q", 1, "REFPROP::" + mix));
            CAPTURE(pchk_RP);
            double diff = std::abs(Tnbp_CP / Tnbp_RP - 1);
            CHECK(diff < 1e-2);
        }
    }
}

TEST_CASE("Tests for solvers in P,T flash using Water", "[flash],[PT]") {
    SECTION("Check that T,P for saturated state yields error") {
        double Ts, ps, rho;
        CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
        CHECK(ValidNumber(Ts));
        CHECK_NOTHROW(ps = PropsSI("P", "T", Ts, "Q", 0, "Water"));
        CHECK(ValidNumber(ps));
        CAPTURE(Ts);
        CAPTURE(ps);
        CHECK_NOTHROW(rho = PropsSI("D", "T", Ts, "P", ps, "Water"));
        CAPTURE(rho);
        CHECK(!ValidNumber(rho));
    }
    SECTION("Subcritical p slightly subcooled should be ok") {
        double Ts, rho, dT = 1e-4;
        CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
        CAPTURE(Ts);
        CHECK(ValidNumber(Ts));
        CAPTURE(dT);
        CHECK_NOTHROW(rho = PropsSI("D", "T", Ts - dT, "P", 101325, "Water"));
        CAPTURE(rho);
        CHECK(ValidNumber(rho));
    }
    SECTION("Subcritical p slightly superheated should be ok") {
        double Ts, rho, dT = 1e-4;
        CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
        CAPTURE(Ts);
        CHECK(ValidNumber(Ts));
        CAPTURE(dT);
        CHECK_NOTHROW(rho = PropsSI("D", "T", Ts + dT, "P", 101325, "Water"));
        CAPTURE(rho);
        CHECK(ValidNumber(rho));
    }
}

TEST_CASE("P,T flash at the critical point returns rhomolar_critical", "[flash],[PT],[critical_point],[2738]") {
    // At the critical point, dP/drho -> 0 so the generic density solver is ill-conditioned.
    // PT_flash should detect exact-critical inputs and return the tabulated critical density.
    for (const std::string fluid : {"CarbonDioxide", "Water", "R134a"}) {
        CAPTURE(fluid);
        std::shared_ptr<AbstractState> AS(AbstractState::factory("HEOS", fluid));
        double Tc = AS->T_critical();
        double pc = AS->p_critical();
        double rho_c = AS->rhomolar_critical();
        AS->update(PT_INPUTS, pc, Tc);
        CHECK(std::abs(AS->rhomolar() - rho_c) / rho_c < 1e-10);
        CHECK(AS->phase() == iphase_critical_point);
    }
    SECTION("Issue #2738 reproducer (high-level API for CO2)") {
        double Tc = Props1SI("CO2", "Tcrit");
        double pc = Props1SI("CO2", "Pcrit");
        double rho_crit = Props1SI("CO2", "rhomass_critical");
        double rho_pt = PropsSI("Dmass", "T", Tc, "P", pc, "CO2");
        CAPTURE(Tc);
        CAPTURE(pc);
        CAPTURE(rho_crit);
        CAPTURE(rho_pt);
        CHECK(ValidNumber(rho_pt));
        CHECK(std::abs(rho_pt - rho_crit) / rho_crit < 1e-10);
    }
}

TEST_CASE("Tests for solvers in P,Y flash using Water", "[flash],[PH],[PS],[PU]") {
    double Ts, y, T2;
    // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
    const std::vector<std::string> Ykeys = {"H", "S", "U", "Hmass", "Smass", "Umass", "Hmolar", "Smolar", "Umolar"};
    for (const auto& Ykey : Ykeys) {
        const char* ykey = Ykey.c_str();
        std::ostringstream ss1;
        ss1 << "Subcritical superheated P," << ykey;
        SECTION(ss1.str(), "") {
            double dT = 10;
            CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
            CHECK(ValidNumber(Ts));
            CAPTURE(Ts);
            CHECK_NOTHROW(y = PropsSI(ykey, "T", Ts + dT, "P", 101325, "Water"));
            CAPTURE(dT);
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", 101325, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
        std::ostringstream ss2;
        ss2 << "Subcritical barely superheated P," << ykey;
        SECTION(ss2.str(), "") {
            double dT = 1e-3;
            CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
            CHECK(ValidNumber(Ts));
            CAPTURE(Ts);
            CHECK_NOTHROW(y = PropsSI(ykey, "T", Ts + dT, "P", 101325, "Water"));
            CAPTURE(dT);
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", 101325, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
        std::ostringstream ss3;
        ss3 << "Subcritical subcooled P," << ykey;
        SECTION(ss3.str(), "") {
            double dT = -10;
            CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
            CHECK(ValidNumber(Ts));
            CAPTURE(Ts);
            CHECK_NOTHROW(y = PropsSI(ykey, "T", Ts + dT, "P", 101325, "Water"));
            CAPTURE(dT);
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", 101325, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
        std::ostringstream ss4;
        ss4 << "Subcritical barely subcooled P," << ykey;
        SECTION(ss4.str(), "") {
            double dT = -1e-3;
            CHECK_NOTHROW(Ts = PropsSI("T", "P", 101325, "Q", 0, "Water"));
            CHECK(ValidNumber(Ts));
            CAPTURE(Ts);
            CHECK_NOTHROW(y = PropsSI(ykey, "T", Ts + dT, "P", 101325, "Water"));
            CAPTURE(dT);
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", 101325, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
        std::ostringstream ss5;
        ss5 << "Supercritical P," << ykey;
        SECTION(ss5.str(), "") {
            double Tc = Props1SI("Water", "Tcrit");
            double pc = Props1SI("Water", "pcrit");
            double p = pc * 1.3;
            double T = Tc * 1.3;
            CAPTURE(T);
            CAPTURE(p);
            CHECK(ValidNumber(T));
            CHECK(ValidNumber(p));
            CHECK_NOTHROW(y = PropsSI(ykey, "P", p, "T", T, "Water"));
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", p, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
        std::ostringstream ss6;
        ss6 << "Supercritical \"gas\" P," << ykey;
        SECTION(ss6.str(), "") {
            double Tc = Props1SI("Water", "Tcrit");
            double pc = Props1SI("Water", "pcrit");
            double p = pc * 0.7;
            double T = Tc * 1.3;
            CAPTURE(T);
            CAPTURE(p);
            CHECK(ValidNumber(T));
            CHECK(ValidNumber(p));
            CHECK_NOTHROW(y = PropsSI(ykey, "P", p, "T", T, "Water"));
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", p, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
        std::ostringstream ss7;
        ss7 << "Supercritical \"liquid\" P," << ykey;
        SECTION(ss7.str(), "") {
            double Tc = Props1SI("Water", "Tcrit");
            double pc = Props1SI("Water", "pcrit");
            double p = pc * 2;
            double T = Tc * 0.5;
            CAPTURE(T);
            CAPTURE(p);
            CHECK(ValidNumber(T));
            CHECK(ValidNumber(p));
            CHECK_NOTHROW(y = PropsSI(ykey, "P", p, "T", T, "Water"));
            CAPTURE(y);
            CHECK(ValidNumber(y));
            CHECK_NOTHROW(T2 = PropsSI("T", ykey, y, "P", p, "Water"));
            CAPTURE(CoolProp::get_global_param_string("errstring"));
            CAPTURE(T2);
            CHECK(ValidNumber(T2));
        }
    }
}

TEST_CASE("R134A saturation bug in dev", "[2545]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R134A"));
    AS->update(QT_INPUTS, 1, 273);
    double p = AS->p();
    CHECK(p == Catch::Approx(291215));
}

TEST_CASE("Tests for solvers in P,H flash using Propane", "[flashdups],[flash],[PH],[consistency]") {
    double hmolar, hmass;
    SECTION("5 times PH with HEOS AbstractState yields same results every time", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "n-Propane"));

        CHECK_NOTHROW(AS->update(CoolProp::PT_INPUTS, 101325, 300));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
    }
}

TEST_CASE("Multiple calls to state class are consistent", "[flashdups],[flash],[PH],[consistency]") {
    double hmolar, hmass;
    SECTION("3 times PH with HEOS AbstractState yields same results every time", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "n-Propane"));

        CHECK_NOTHROW(AS->update(CoolProp::PT_INPUTS, 101325, 300));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
        hmolar = AS->hmolar();
        hmass = AS->hmass();
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 101325));
        CHECK_NOTHROW(AS->update(CoolProp::HmolarP_INPUTS, hmolar, 101325));
    }
}

TEST_CASE("Test first partial derivatives using PropsSI", "[derivatives]") {
    double T = 300;
    SECTION("Check drhodp|T 3 ways", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "n-Propane"));
        AS->update(CoolProp::PT_INPUTS, 101325, T);

        double drhomolardp__T_AbstractState = AS->first_partial_deriv(CoolProp::iDmolar, CoolProp::iP, CoolProp::iT);
        double drhomolardp__T_PropsSI_num =
          (PropsSI("Dmolar", "T", T, "P", 101325 + 1e-3, "n-Propane") - PropsSI("Dmolar", "T", T, "P", 101325 - 1e-3, "n-Propane")) / (2 * 1e-3);
        double drhomolardp__T_PropsSI = PropsSI("d(Dmolar)/d(P)|T", "T", T, "P", 101325, "n-Propane");

        CAPTURE(drhomolardp__T_AbstractState);
        CAPTURE(drhomolardp__T_PropsSI_num);
        CAPTURE(drhomolardp__T_PropsSI);
        double rel_err_exact = std::abs((drhomolardp__T_AbstractState - drhomolardp__T_PropsSI) / drhomolardp__T_PropsSI);
        double rel_err_approx = std::abs((drhomolardp__T_PropsSI_num - drhomolardp__T_PropsSI) / drhomolardp__T_PropsSI);
        CHECK(rel_err_exact < 1e-7);
        CHECK(rel_err_approx < 1e-7);
    }
    SECTION("Check drhodp|T 3 ways for water", "") {
        T = 80 + 273.15;
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::PT_INPUTS, 101325, T);

        double drhomolardp__T_AbstractState = AS->first_partial_deriv(CoolProp::iDmolar, CoolProp::iP, CoolProp::iT);
        double drhomolardp__T_PropsSI_num =
          (PropsSI("Dmolar", "T", T, "P", 101325 + 1, "Water") - PropsSI("Dmolar", "T", T, "P", 101325 - 1, "Water")) / (2 * 1);
        double drhomolardp__T_PropsSI = PropsSI("d(Dmolar)/d(P)|T", "T", T, "P", 101325, "Water");

        CAPTURE(drhomolardp__T_AbstractState);
        CAPTURE(drhomolardp__T_PropsSI_num);
        CAPTURE(drhomolardp__T_PropsSI);
        double rel_err_exact = std::abs((drhomolardp__T_AbstractState - drhomolardp__T_PropsSI) / drhomolardp__T_PropsSI);
        double rel_err_approx = std::abs((drhomolardp__T_PropsSI_num - drhomolardp__T_PropsSI) / drhomolardp__T_PropsSI);
        CHECK(rel_err_exact < 1e-4);
        CHECK(rel_err_approx < 1e-4);
    }
    SECTION("Check dpdrho|T 3 ways for water", "") {
        T = 80 + 273.15;
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::PT_INPUTS, 101325, T);
        CoolPropDbl rhomolar = AS->rhomolar();
        double dpdrhomolar__T_AbstractState = AS->first_partial_deriv(CoolProp::iP, CoolProp::iDmolar, CoolProp::iT);
        double dpdrhomolar__T_PropsSI_num =
          (PropsSI("P", "T", T, "Dmolar", rhomolar + 1e-3, "Water") - PropsSI("P", "T", T, "Dmolar", rhomolar - 1e-3, "Water")) / (2 * 1e-3);
        double dpdrhomolar__T_PropsSI = PropsSI("d(P)/d(Dmolar)|T", "T", T, "P", 101325, "Water");
        CAPTURE(rhomolar);
        CAPTURE(dpdrhomolar__T_AbstractState);
        CAPTURE(dpdrhomolar__T_PropsSI_num);
        CAPTURE(dpdrhomolar__T_PropsSI);
        double rel_err_exact = std::abs((dpdrhomolar__T_AbstractState - dpdrhomolar__T_PropsSI) / dpdrhomolar__T_PropsSI);
        double rel_err_approx = std::abs((dpdrhomolar__T_PropsSI_num - dpdrhomolar__T_PropsSI) / dpdrhomolar__T_PropsSI);
        CHECK(rel_err_exact < 1e-6);
        CHECK(rel_err_approx < 1e-6);
    }
    SECTION("Check dpdrho|T 3 ways for water using mass based", "") {
        T = 80 + 273.15;
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::PT_INPUTS, 101325, T);
        CoolPropDbl rhomass = AS->rhomass();
        double dpdrhomass__T_AbstractState = AS->first_partial_deriv(CoolProp::iP, CoolProp::iDmass, CoolProp::iT);
        double dpdrhomass__T_PropsSI_num =
          (PropsSI("P", "T", T, "Dmass", rhomass + 1e-3, "Water") - PropsSI("P", "T", T, "Dmass", rhomass - 1e-3, "Water")) / (2 * 1e-3);
        double dpdrhomass__T_PropsSI = PropsSI("d(P)/d(Dmass)|T", "T", T, "P", 101325, "Water");
        CAPTURE(rhomass);
        CAPTURE(dpdrhomass__T_AbstractState);
        CAPTURE(dpdrhomass__T_PropsSI_num);
        CAPTURE(dpdrhomass__T_PropsSI);
        double rel_err_exact = std::abs((dpdrhomass__T_AbstractState - dpdrhomass__T_PropsSI) / dpdrhomass__T_PropsSI);
        double rel_err_approx = std::abs((dpdrhomass__T_PropsSI_num - dpdrhomass__T_PropsSI) / dpdrhomass__T_PropsSI);
        CHECK(rel_err_exact < 1e-7);
        CHECK(rel_err_approx < 1e-7);
    }
    SECTION("Invalid first partial derivatives", "") {
        CHECK(!ValidNumber(PropsSI("d()/d(P)|T", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(Dmolar)/d()|T", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(Dmolar)/d(P)|", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(XXXX)/d(P)|T", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(Dmolar)d(P)|T", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(Dmolar)/d(P)T", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(Bvirial)/d(P)T", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("d(Tcrit)/d(P)T", "T", 300, "P", 101325, "n-Propane")));
    }
}

TEST_CASE("Test second partial derivatives", "[derivatives]") {
    double T = 300;
    SECTION("Check d2pdrho2|T 3 ways", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        double rhomolar = 60000;
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar, T);
        double p = AS->p();

        double d2pdrhomolar2__T_AbstractState =
          AS->second_partial_deriv(CoolProp::iP, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT);
        // Centered second derivative
        double del = 1e0;
        double d2pdrhomolar2__T_PropsSI_num =
          (PropsSI("P", "T", T, "Dmolar", rhomolar + del, "Water") - 2 * PropsSI("P", "T", T, "Dmolar", rhomolar, "Water")
           + PropsSI("P", "T", T, "Dmolar", rhomolar - del, "Water"))
          / pow(del, 2);
        double d2pdrhomolar2__T_PropsSI = PropsSI("d(d(P)/d(Dmolar)|T)/d(Dmolar)|T", "T", T, "Dmolar", rhomolar, "Water");

        CAPTURE(d2pdrhomolar2__T_AbstractState);
        CAPTURE(d2pdrhomolar2__T_PropsSI_num);
        double rel_err_exact = std::abs((d2pdrhomolar2__T_AbstractState - d2pdrhomolar2__T_PropsSI) / d2pdrhomolar2__T_PropsSI);
        double rel_err_approx = std::abs((d2pdrhomolar2__T_PropsSI_num - d2pdrhomolar2__T_AbstractState) / d2pdrhomolar2__T_AbstractState);
        CHECK(rel_err_exact < 1e-5);
        CHECK(rel_err_approx < 1e-5);
    }
    SECTION("Valid second partial derivatives", "") {
        CHECK(ValidNumber(PropsSI("d(d(Hmolar)/d(P)|T)/d(T)|Dmolar", "T", 300, "P", 101325, "n-Propane")));
    }
    SECTION("Invalid second partial derivatives", "") {
        CHECK(!ValidNumber(PropsSI("d(d()/d(P)|T)/d()|", "T", 300, "P", 101325, "n-Propane")));
        CHECK(!ValidNumber(PropsSI("dd(Dmolar)/d()|T)|T", "T", 300, "P", 101325, "n-Propane")));
    }
    SECTION("Check derivatives with respect to T", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Propane"));
        double rhomolar = 100, dT = 1e-1;
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar, T);

        // base state
        CoolPropDbl T0 = AS->T(), rhomolar0 = AS->rhomolar(), hmolar0 = AS->hmolar(), smolar0 = AS->smolar(), umolar0 = AS->umolar(), p0 = AS->p();
        CoolPropDbl dhdT_rho_ana = AS->first_partial_deriv(CoolProp::iHmolar, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl d2hdT2_rho_ana = AS->second_partial_deriv(CoolProp::iHmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl dsdT_rho_ana = AS->first_partial_deriv(CoolProp::iSmolar, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl d2sdT2_rho_ana = AS->second_partial_deriv(CoolProp::iSmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl dudT_rho_ana = AS->first_partial_deriv(CoolProp::iUmolar, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl d2udT2_rho_ana = AS->second_partial_deriv(CoolProp::iUmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl dpdT_rho_ana = AS->first_partial_deriv(CoolProp::iP, CoolProp::iT, CoolProp::iDmolar);
        CoolPropDbl d2pdT2_rho_ana = AS->second_partial_deriv(CoolProp::iP, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar);

        // increment T
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar, T + dT);
        CoolPropDbl Tpt = AS->T(), rhomolarpt = AS->rhomolar(), hmolarpt = AS->hmolar(), smolarpt = AS->smolar(), umolarpt = AS->umolar(),
                    ppt = AS->p();
        // decrement T
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar, T - dT);
        CoolPropDbl Tmt = AS->T(), rhomolarmt = AS->rhomolar(), hmolarmt = AS->hmolar(), smolarmt = AS->smolar(), umolarmt = AS->umolar(),
                    pmt = AS->p();

        CoolPropDbl dhdT_rho_num = (hmolarpt - hmolarmt) / (2 * dT);
        CoolPropDbl d2hdT2_rho_num = (hmolarpt - 2 * hmolar0 + hmolarmt) / pow(dT, 2);
        CoolPropDbl dsdT_rho_num = (smolarpt - smolarmt) / (2 * dT);
        CoolPropDbl d2sdT2_rho_num = (smolarpt - 2 * smolar0 + smolarmt) / pow(dT, 2);
        CoolPropDbl dudT_rho_num = (umolarpt - umolarmt) / (2 * dT);
        CoolPropDbl d2udT2_rho_num = (umolarpt - 2 * umolar0 + umolarmt) / pow(dT, 2);
        CoolPropDbl dpdT_rho_num = (ppt - pmt) / (2 * dT);
        CoolPropDbl d2pdT2_rho_num = (ppt - 2 * p0 + pmt) / pow(dT, 2);

        CAPTURE(format("%0.15Lg", d2pdT2_rho_ana).c_str());

        double tol = 1e-4;
        CHECK(std::abs((dhdT_rho_num - dhdT_rho_ana) / dhdT_rho_ana) < tol);
        CHECK(std::abs((d2hdT2_rho_num - d2hdT2_rho_ana) / d2hdT2_rho_ana) < tol);
        CHECK(std::abs((dpdT_rho_num - dpdT_rho_ana) / dpdT_rho_ana) < tol);
        CHECK(std::abs((d2pdT2_rho_num - d2pdT2_rho_ana) / d2pdT2_rho_ana) < tol);
        CHECK(std::abs((dsdT_rho_num - dsdT_rho_ana) / dsdT_rho_ana) < tol);
        CHECK(std::abs((d2sdT2_rho_num - d2sdT2_rho_ana) / d2sdT2_rho_ana) < tol);
        CHECK(std::abs((dudT_rho_num - dudT_rho_ana) / dudT_rho_ana) < tol);
        CHECK(std::abs((d2udT2_rho_num - d2udT2_rho_ana) / d2udT2_rho_ana) < tol);
    }

    SECTION("Check derivatives with respect to rho", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Propane"));
        double rhomolar = 100, drho = 1e-1;
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar, T);

        // base state
        CoolPropDbl T0 = AS->T(), rhomolar0 = AS->rhomolar(), hmolar0 = AS->hmolar(), smolar0 = AS->smolar(), umolar0 = AS->umolar(), p0 = AS->p();
        CoolPropDbl dhdrho_T_ana = AS->first_partial_deriv(CoolProp::iHmolar, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl d2hdrho2_T_ana = AS->second_partial_deriv(CoolProp::iHmolar, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl dsdrho_T_ana = AS->first_partial_deriv(CoolProp::iSmolar, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl d2sdrho2_T_ana = AS->second_partial_deriv(CoolProp::iSmolar, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl dudrho_T_ana = AS->first_partial_deriv(CoolProp::iUmolar, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl d2udrho2_T_ana = AS->second_partial_deriv(CoolProp::iUmolar, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl dpdrho_T_ana = AS->first_partial_deriv(CoolProp::iP, CoolProp::iDmolar, CoolProp::iT);
        CoolPropDbl d2pdrho2_T_ana = AS->second_partial_deriv(CoolProp::iP, CoolProp::iDmolar, CoolProp::iT, CoolProp::iDmolar, CoolProp::iT);

        // increment rho
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar + drho, T);
        CoolPropDbl Tpr = AS->T(), rhomolarpr = AS->rhomolar(), hmolarpr = AS->hmolar(), smolarpr = AS->smolar(), umolarpr = AS->umolar(),
                    ppr = AS->p();
        // decrement rho
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar - drho, T);
        CoolPropDbl Tmr = AS->T(), rhomolarmr = AS->rhomolar(), hmolarmr = AS->hmolar(), smolarmr = AS->smolar(), umolarmr = AS->umolar(),
                    pmr = AS->p();

        CoolPropDbl dhdrho_T_num = (hmolarpr - hmolarmr) / (2 * drho);
        CoolPropDbl d2hdrho2_T_num = (hmolarpr - 2 * hmolar0 + hmolarmr) / pow(drho, 2);
        CoolPropDbl dsdrho_T_num = (smolarpr - smolarmr) / (2 * drho);
        CoolPropDbl d2sdrho2_T_num = (smolarpr - 2 * smolar0 + smolarmr) / pow(drho, 2);
        CoolPropDbl dudrho_T_num = (umolarpr - umolarmr) / (2 * drho);
        CoolPropDbl d2udrho2_T_num = (umolarpr - 2 * umolar0 + umolarmr) / pow(drho, 2);
        CoolPropDbl dpdrho_T_num = (ppr - pmr) / (2 * drho);
        CoolPropDbl d2pdrho2_T_num = (ppr - 2 * p0 + pmr) / pow(drho, 2);

        CAPTURE(format("%0.15Lg", d2pdrho2_T_ana).c_str());

        double tol = 1e-4;
        CHECK(std::abs((dhdrho_T_num - dhdrho_T_ana) / dhdrho_T_ana) < tol);
        CHECK(std::abs((d2hdrho2_T_num - d2hdrho2_T_ana) / d2hdrho2_T_ana) < tol);
        CHECK(std::abs((dpdrho_T_num - dpdrho_T_ana) / dpdrho_T_ana) < tol);
        CHECK(std::abs((d2pdrho2_T_num - d2pdrho2_T_ana) / d2pdrho2_T_ana) < tol);
        CHECK(std::abs((dsdrho_T_num - dsdrho_T_ana) / dsdrho_T_ana) < tol);
        CHECK(std::abs((d2sdrho2_T_num - d2sdrho2_T_ana) / d2sdrho2_T_ana) < tol);
        CHECK(std::abs((dudrho_T_num - dudrho_T_ana) / dudrho_T_ana) < tol);
        CHECK(std::abs((d2udrho2_T_num - d2udrho2_T_ana) / d2udrho2_T_ana) < tol);
    }
    SECTION("Check second mixed partial(h,p) with respect to rho", "") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Propane"));
        double dhmass = 1.0, T = 300;
        AS->update(CoolProp::QT_INPUTS, 0.0, T);
        double deriv1 = AS->first_partial_deriv(iDmass, iP, iHmass);
        double deriv_analyt = AS->second_partial_deriv(iDmass, iP, iHmass, iHmass, iP);
        double deriv_analyt2 = AS->second_partial_deriv(iDmass, iHmass, iP, iP, iHmass);
        AS->update(CoolProp::HmassP_INPUTS, AS->hmass() - 1, AS->p());
        double deriv2 = AS->first_partial_deriv(iDmass, iP, iHmass);
        double deriv_num = (deriv1 - deriv2) / dhmass;
        CAPTURE(deriv_num);
        CAPTURE(deriv_analyt);

        double tol = 1e-4;
        CHECK(std::abs((deriv_num - deriv_analyt) / deriv_analyt) < tol);
    }
}

TEST_CASE("REFPROP names for coolprop fluids", "[REFPROPName]") {
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available

    std::vector<std::string> fluids = strsplit(CoolProp::get_global_param_string("fluids_list"), ',');
    for (const auto& fluid : fluids) {
        std::ostringstream ss1;
        ss1 << "Check that REFPROP fluid name for fluid " << fluid << " is valid";
        SECTION(ss1.str(), "") {
            std::string RPName = get_fluid_param_string(fluid, "REFPROPName");
            CHECK(!RPName.empty());
            CAPTURE(RPName);
            if (!RPName.compare("N/A")) {
                break;
            }
            CHECK(ValidNumber(Props1SI("REFPROP::" + RPName, "molemass")));
            CHECK(ValidNumber(Props1SI(RPName, "molemass")));
        }
    }
}
TEST_CASE("Backwards compatibility for REFPROP v4 fluid name convention", "[REFPROP_backwards_compatibility]") {
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available

    SECTION("REFPROP-", "") {
        double val = Props1SI("REFPROP-Water", "Tcrit");
        std::string err = get_global_param_string("errstring");
        CAPTURE(val);
        CAPTURE(err);
        CHECK(ValidNumber(val));
    }
    SECTION("REFPROP-MIX:", "") {
        double val = PropsSI("T", "P", 101325, "Q", 0, "REFPROP-MIX:Methane[0.5]&Ethane[0.5]");
        std::string err = get_global_param_string("errstring");
        CAPTURE(val);
        CAPTURE(err);
        CHECK(ValidNumber(val));
    }
}

class AncillaryFixture
{
   public:
    std::string name;
    void run_checks() {
        std::vector<std::string> fluids = strsplit(CoolProp::get_global_param_string("fluids_list"), ',');
        for (const auto& fluid : fluids) {
            shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", fluid));
            auto* rHEOS = dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());
            if (!rHEOS->is_pure()) {
                continue;
            }
            do_sat(AS);
        }
    }
    void do_sat(shared_ptr<CoolProp::AbstractState>& AS) {
        // Integer-indexed (cert-flp30-c): f = 0.1, 0.5, 0.9 — exactly
        // what the original `for (double f = 0.1; f < 1; f += 0.4)`
        // produced.
        for (std::size_t k = 0; k < 3; ++k) {
            const double f = 0.1 + 0.4 * static_cast<double>(k);
            double Tc = AS->T_critical();
            double Tt = AS->Ttriple();
            double T = f * Tc + (1 - f) * Tt;
            name = strjoin(AS->fluid_names(), "&");

            AS->update(CoolProp::QT_INPUTS, 0, T);
            check_rhoL(AS);
            check_pL(AS);

            AS->update(CoolProp::QT_INPUTS, 1, T);
            check_rhoV(AS);
            check_pV(AS);
        }
    }
    void check_pL(const shared_ptr<CoolProp::AbstractState>& AS) {
        double p_EOS = AS->saturated_liquid_keyed_output(iP);
        double p_anc = AS->saturation_ancillary(CoolProp::iP, 0, CoolProp::iT, AS->T());
        double err = std::abs(p_EOS - p_anc) / p_anc;
        CAPTURE(name);
        CAPTURE("pL");
        CAPTURE(p_EOS);
        CAPTURE(p_anc);
        CAPTURE(AS->T());
        CHECK(err < 0.02);
    }
    void check_pV(const shared_ptr<CoolProp::AbstractState>& AS) {
        double p_EOS = AS->saturated_liquid_keyed_output(iP);
        double p_anc = AS->saturation_ancillary(CoolProp::iP, 1, CoolProp::iT, AS->T());
        double err = std::abs(p_EOS - p_anc) / p_anc;
        CAPTURE(name);
        CAPTURE("pV");
        CAPTURE(p_EOS);
        CAPTURE(p_anc);
        CAPTURE(AS->T());
        CHECK(err < 0.02);
    }
    void check_rhoL(const shared_ptr<CoolProp::AbstractState>& AS) {
        double rho_EOS = AS->saturated_liquid_keyed_output(iDmolar);
        double rho_anc = AS->saturation_ancillary(CoolProp::iDmolar, 0, CoolProp::iT, AS->T());
        double err = std::abs(rho_EOS - rho_anc) / rho_anc;
        CAPTURE("rhoL");
        CAPTURE(name);
        CAPTURE(rho_EOS);
        CAPTURE(rho_anc);
        CAPTURE(AS->T());
        CHECK(err < 0.03);
    }
    void check_rhoV(const shared_ptr<CoolProp::AbstractState>& AS) {
        double rho_EOS = AS->saturated_vapor_keyed_output(iDmolar);
        double rho_anc = AS->saturation_ancillary(CoolProp::iDmolar, 1, CoolProp::iT, AS->T());
        double err = std::abs(rho_EOS - rho_anc) / rho_anc;
        CAPTURE("rhoV");
        CAPTURE(name);
        CAPTURE(rho_EOS);
        CAPTURE(rho_anc);
        CAPTURE(AS->T());
        CHECK(err < 0.03);
    }
};
// Disabled because either they have a superancillary, and the ancillaries should not be used,
// or they are a pure fluid and superancillaries are not developed
//TEST_CASE_METHOD(AncillaryFixture, "Ancillary functions", "[ancillary]") {
//    run_checks();
//};

TEST_CASE("Triple point checks", "[triple_point]") {
    std::vector<std::string> fluids = strsplit(CoolProp::get_global_param_string("fluids_list"), ',');
    for (const auto& fluid : fluids) {
        std::vector<std::string> names(1, fluid);
        shared_ptr<CoolProp::HelmholtzEOSMixtureBackend> HEOS = std::make_shared<CoolProp::HelmholtzEOSMixtureBackend>(names);
        // Skip pseudo-pure
        if (!HEOS->is_pure()) {
            continue;
        }

        std::ostringstream ss1;
        ss1 << "Minimum saturation temperature state matches for liquid " << fluid;
        SECTION(ss1.str(), "") {
            REQUIRE_NOTHROW(HEOS->update(CoolProp::QT_INPUTS, 0, HEOS->Ttriple()));
            double p_EOS = HEOS->p();
            double p_sat_min_liquid = HEOS->get_components()[0].EOS().sat_min_liquid.p;
            double err_sat_min_liquid = std::abs(p_EOS - p_sat_min_liquid) / p_sat_min_liquid;
            CAPTURE(p_EOS);
            CAPTURE(p_sat_min_liquid);
            CAPTURE(err_sat_min_liquid);
            if (p_EOS < 1e-3) {
                continue;
            }  // Skip very low pressure below 1 mPa
            CHECK(err_sat_min_liquid < 1e-3);
        }
        std::ostringstream ss2;
        ss2 << "Minimum saturation temperature state matches for vapor " << fluid;
        SECTION(ss2.str(), "") {
            REQUIRE_NOTHROW(HEOS->update(CoolProp::QT_INPUTS, 1, HEOS->Ttriple()));

            double p_EOS = HEOS->p();
            double p_sat_min_vapor = HEOS->get_components()[0].EOS().sat_min_vapor.p;
            double err_sat_min_vapor = std::abs(p_EOS - p_sat_min_vapor) / p_sat_min_vapor;
            CAPTURE(p_EOS);
            CAPTURE(p_sat_min_vapor);
            CAPTURE(err_sat_min_vapor);
            if (p_EOS < 1e-3) {
                continue;
            }  // Skip very low pressure below 1 mPa
            CHECK(err_sat_min_vapor < 1e-3);
        }
        std::ostringstream ss3;
        ss3 << "Minimum saturation temperature state matches for vapor " << fluid;
        SECTION(ss3.str(), "") {
            if (HEOS->p_triple() < 10) {
                continue;
            }
            REQUIRE_NOTHROW(HEOS->update(CoolProp::PQ_INPUTS, HEOS->p_triple(), 1));

            double T_EOS = HEOS->T();
            double T_sat_min_vapor = HEOS->get_components()[0].EOS().sat_min_vapor.T;
            double err_sat_min_vapor = std::abs(T_EOS - T_sat_min_vapor);
            CAPTURE(T_EOS);
            CAPTURE(T_sat_min_vapor);
            CAPTURE(err_sat_min_vapor);
            CHECK(err_sat_min_vapor < 1e-3);
        }
        std::ostringstream ss4;
        ss4 << "Minimum saturation temperature state matches for liquid " << fluid;
        SECTION(ss4.str(), "") {
            if (HEOS->p_triple() < 10) {
                continue;
            }
            REQUIRE_NOTHROW(HEOS->update(CoolProp::PQ_INPUTS, HEOS->p_triple(), 0));
            double T_EOS = HEOS->T();
            double T_sat_min_vapor = HEOS->get_components()[0].EOS().sat_min_vapor.T;
            double err_sat_min_vapor = std::abs(T_EOS - T_sat_min_vapor);
            CAPTURE(T_EOS);
            CAPTURE(T_sat_min_vapor);
            CAPTURE(err_sat_min_vapor);
            CHECK(err_sat_min_vapor < 1e-3);
        }
        //        std::ostringstream ss2;
        //        ss2 << "Liquid density error < 3% for fluid " << fluids[i] << " at " << T << " K";
        //        SECTION(ss2.str(), "")
        //        {
        //            double rho_EOS = AS->rhomolar();
        //            double rho_anc = AS->saturation_ancillary(CoolProp::iDmolar, 0, CoolProp::iT, T);
        //            double err = std::abs(rho_EOS-rho_anc)/rho_anc;
        //            CAPTURE(rho_EOS);
        //            CAPTURE(rho_anc);
        //            CAPTURE(T);
        //            CHECK(err < 0.03);
        //        }
        //        std::ostringstream ss3;
        //        ss3 << "Vapor density error < 3% for fluid " << fluids[i] << " at " << T << " K";
        //        SECTION(ss3.str(), "")
        //        {
        //            double rho_EOS = AS->rhomolar();
        //            double rho_anc = AS->saturation_ancillary(CoolProp::iDmolar, 1, CoolProp::iT, T);
        //            double err = std::abs(rho_EOS-rho_anc)/rho_anc;
        //            CAPTURE(rho_EOS);
        //            CAPTURE(rho_anc);
        //            CAPTURE(T);
        //            CHECK(err < 0.03);
        //        }
    }
}

class SatTFixture
{
   public:
    std::string name;
    double Tc;
    void run_checks() {
        std::vector<std::string> fluids = strsplit(CoolProp::get_global_param_string("fluids_list"), ',');
        for (const auto& fluid : fluids) {
            shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", fluid));
            auto* rHEOS = dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());
            if (!rHEOS->is_pure()) {
                continue;
            }
            do_sat(AS);
        }
    }
    void do_sat(shared_ptr<CoolProp::AbstractState>& AS) {
        Tc = AS->T_critical();
        name = strjoin(AS->fluid_names(), "&");
        check_at_Tc(AS);
        double Tt = AS->Ttriple();
        if (AS->fluid_param_string("pure") == "true") {
            Tc = std::min(Tc, AS->T_reducing());
        }
        // Geometric scaling (j /= 10) — not summation; 9 well-defined
        // iters from 0.1 down to 1e-10.
        for (double j = 0.1; j > 1e-10; j /= 10) {  // NOLINT(cert-flp30-c)
            check_QT(AS, Tc - j);
        }
    }
    void check_at_Tc(const shared_ptr<CoolProp::AbstractState>& AS) {
        CAPTURE("Check @ Tc");
        CAPTURE(name);
        CHECK_NOTHROW(AS->update(QT_INPUTS, 0, Tc));
    }
    void check_QT(const shared_ptr<CoolProp::AbstractState>& AS, double T) {
        std::string test_name = "Check --> Tc";
        CAPTURE(test_name);
        CAPTURE(name);
        CAPTURE(T);
        CHECK_NOTHROW(AS->update(QT_INPUTS, 0, T));
    }
};
TEST_CASE_METHOD(SatTFixture, "Test that saturation solvers solve all the way to T = Tc", "[sat_T_to_Tc]") {
    run_checks();
};

TEST_CASE("Check mixtures with fluid name aliases", "[mixture_name_aliasing]") {
    shared_ptr<CoolProp::AbstractState> AS1, AS2;
    AS1.reset(CoolProp::AbstractState::factory("HEOS", "EBENZENE&P-XYLENE"));
    AS2.reset(CoolProp::AbstractState::factory("HEOS", "EthylBenzene&P-XYLENE"));
    REQUIRE(AS1->fluid_names().size() == AS2->fluid_names().size());
    std::size_t N = AS1->fluid_names().size();
    for (std::size_t i = 0; i < N; ++i) {
        CAPTURE(i);
        CHECK(AS1->fluid_names()[i] == AS2->fluid_names()[i]);
    }
}

TEST_CASE("Predefined mixtures", "[predefined_mixtures]") {
    SECTION("PropsSI") {
        double val = PropsSI("Dmolar", "P", 101325, "T", 300, "Air.mix");
        std::string err = get_global_param_string("errstring");
        CAPTURE(val);
        CAPTURE(err);
        CHECK(ValidNumber(val));
    }
}
TEST_CASE("Test that reference states yield proper values using high-level interface", "[reference_states]") {
    struct ref_entry
    {
        std::string name;
        double hmass, smass;
        std::string in1;
        double val1;
        std::string in2;
        double val2;
    };
    std::string fluids[] = {"n-Propane", "R134a", "R124"};
    ref_entry entries[3] = {{"IIR", 200000, 1000, "T", 273.15, "Q", 0}, {"ASHRAE", 0, 0, "T", 233.15, "Q", 0}, {"NBP", 0, 0, "P", 101325, "Q", 0}};
    for (const auto& fluid : fluids) {
        for (auto& entry : entries) {
            std::ostringstream ss1;
            ss1 << "Check state for " << fluid << " for " + entry.name + " reference state ";
            SECTION(ss1.str(), "") {
                // First reset the reference state
                set_reference_stateS(fluid, "DEF");
                // Then set to desired reference state
                set_reference_stateS(fluid, entry.name);
                // Calculate the values
                double hmass = PropsSI("Hmass", entry.in1, entry.val1, entry.in2, entry.val2, fluid);
                double smass = PropsSI("Smass", entry.in1, entry.val1, entry.in2, entry.val2, fluid);
                CHECK(std::abs(hmass - entry.hmass) < 1e-8);
                CHECK(std::abs(smass - entry.smass) < 1e-8);
                // Then reset the reference state
                set_reference_stateS(fluid, "DEF");
            }
        }
    }
}
TEST_CASE("Test that reference states yield proper values using low-level interface", "[reference_states]") {
    struct ref_entry
    {
        std::string name;
        double hmass, smass;
        parameters in1;
        double val1;
        parameters in2;
        double val2;
    };
    std::string fluids[] = {"n-Propane", "R134a", "R124"};
    ref_entry entries[3] = {{"IIR", 200000, 1000, iT, 273.15, iQ, 0}, {"ASHRAE", 0, 0, iT, 233.15, iQ, 0}, {"NBP", 0, 0, iP, 101325, iQ, 0}};
    for (const auto& fluid : fluids) {
        for (auto& entry : entries) {
            std::ostringstream ss1;
            ss1 << "Check state for " << fluid << " for " + entry.name + " reference state ";
            SECTION(ss1.str(), "") {
                double val1, val2;
                input_pairs pair = generate_update_pair(entry.in1, entry.val1, entry.in2, entry.val2, val1, val2);
                // Generate a state instance
                shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", fluid));
                AS->update(pair, val1, val2);
                double hmass0 = AS->hmass();
                double smass0 = AS->smass();
                // First reset the reference state
                set_reference_stateS(fluid, "DEF");
                AS->update(pair, val1, val2);
                double hmass00 = AS->hmass();
                double smass00 = AS->smass();
                CHECK(std::abs(hmass00 - hmass0) < 1e-10);
                CHECK(std::abs(smass00 - smass0) < 1e-10);

                // Then set to desired reference state
                set_reference_stateS(fluid, entry.name);

                // Should not change existing instance
                AS->clear();
                AS->update(pair, val1, val2);
                double hmass1 = AS->hmass();
                double smass1 = AS->smass();
                CHECK(std::abs(hmass1 - hmass0) < 1e-10);
                CHECK(std::abs(smass1 - smass0) < 1e-10);

                // New instance - should get updated reference state
                shared_ptr<CoolProp::AbstractState> AS2(CoolProp::AbstractState::factory("HEOS", fluid));
                AS2->update(pair, val1, val2);
                double hmass2 = AS2->hmass();
                double smass2 = AS2->smass();
                CHECK(std::abs(hmass2 - entry.hmass) < 1e-8);
                CHECK(std::abs(smass2 - entry.smass) < 1e-8);

                // Then reset the reference state
                set_reference_stateS(fluid, "DEF");
            }
        }
    }
}

class FixedStateFixture
{
   public:
    void run_fluid(const std::string& fluid, const std::string& state, const std::string& ref_state) {

        // Skip impossible reference states
        if (Props1SI("Ttriple", fluid) > 233.15 && ref_state == "ASHRAE") {
            return;
        }
        if (Props1SI("Tcrit", fluid) < 233.15 && ref_state == "ASHRAE") {
            return;
        }
        if (Props1SI("Tcrit", fluid) < 273.15 && ref_state == "IIR") {
            return;
        }
        if (Props1SI("Ttriple", fluid) > 273.15 && ref_state == "IIR") {
            return;
        }
        if (Props1SI("ptriple", fluid) > 101325 && ref_state == "NBP") {
            return;
        }

        // First reset the reference state
        if (ref_state != "DEF") {
            set_reference_stateS(fluid, "DEF");
            try {
                // Then try to set to the specified reference state
                set_reference_stateS(fluid, ref_state);
            } catch (std::exception& e) {
                // Then set the reference state back to the default
                set_reference_stateS(fluid, "DEF");
                CAPTURE(e.what());
                REQUIRE(false);
            }
        }

        std::ostringstream name;
        name << "Check state for " << state << " for " << fluid << " for reference state " << ref_state;
        CAPTURE(name.str());

        std::vector<std::string> fl(1, fluid);
        shared_ptr<CoolProp::HelmholtzEOSMixtureBackend> HEOS = std::make_shared<CoolProp::HelmholtzEOSMixtureBackend>(fl);

        // Skip the saturation maxima states for pure fluids
        if (HEOS->is_pure() && (state == "max_sat_T" || state == "max_sat_p")) {
            return;
        }

        // Get the state
        CoolProp::SimpleState _state = HEOS->calc_state(state);
        HEOS->specify_phase(iphase_gas);  // something homogenous
        // Bump a tiny bit for EOS with non-analytic parts
        double f = 1.0;
        if ((fluid == "Water" || fluid == "CarbonDioxide") && (state == "reducing" || state == "critical")) {
            f = 1.00001;
        }
        HEOS->update(CoolProp::DmolarT_INPUTS, _state.rhomolar * f, _state.T * f);
        CAPTURE(_state.hmolar);
        CAPTURE(_state.smolar);
        CHECK(ValidNumber(_state.hmolar));
        CHECK(ValidNumber(_state.smolar));
        double EOS_hmolar = HEOS->hmolar();
        double EOS_smolar = HEOS->smolar();
        CAPTURE(EOS_hmolar);
        CAPTURE(EOS_smolar);
        CHECK(std::abs(EOS_hmolar - _state.hmolar) < 1e-2);
        CHECK(std::abs(EOS_smolar - _state.smolar) < 1e-2);
        // Then set the reference state back to the default
        set_reference_stateS(fluid, "DEF");
    };
    void run_checks() {

        std::vector<std::string> fluids = strsplit(CoolProp::get_global_param_string("fluids_list"), ',');
        for (const auto& fluid : fluids) {
            std::string ref_state[4] = {"DEF", "IIR", "ASHRAE", "NBP"};
            for (const auto& j : ref_state) {
                std::string states[] = {"hs_anchor", "reducing", "critical", "max_sat_T", "max_sat_p", "triple_liquid", "triple_vapor"};
                for (const auto& state : states) {
                    run_fluid(fluid, state, j);
                }
            }
        }
    }
};
TEST_CASE_METHOD(FixedStateFixture, "Test that enthalpies and entropies are correct for fixed states for all reference states", "[fixed_states]") {
    run_checks();
};  // !!!! check this

TEST_CASE("Check the first partial derivatives", "[first_saturation_partial_deriv]") {
    const int number_of_pairs = 10;
    struct pair
    {
        parameters p1, p2;
    };
    pair pairs[number_of_pairs] = {{iP, iT}, {iDmolar, iT}, {iHmolar, iT}, {iSmolar, iT}, {iUmolar, iT},
                                   {iT, iP}, {iDmolar, iP}, {iHmolar, iP}, {iSmolar, iP}, {iUmolar, iP}};
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "n-Propane"));
    for (auto& pair : pairs) {
        // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
        std::ostringstream ss1;
        ss1 << "Check first partial derivative for d(" << get_parameter_information(pair.p1, "short") << ")/d("
            << get_parameter_information(pair.p2, "short") << ")|sat";
        SECTION(ss1.str(), "") {
            AS->update(QT_INPUTS, 1, 300);
            CoolPropDbl p = AS->p();
            CoolPropDbl analytical = AS->first_saturation_deriv(pair.p1, pair.p2);
            CAPTURE(analytical);
            CoolPropDbl numerical;
            if (pair.p2 == iT) {
                AS->update(QT_INPUTS, 1, 300 + 1e-5);
                CoolPropDbl v1 = AS->keyed_output(pair.p1);
                AS->update(QT_INPUTS, 1, 300 - 1e-5);
                CoolPropDbl v2 = AS->keyed_output(pair.p1);
                numerical = (v1 - v2) / (2e-5);
            } else if (pair.p2 == iP) {
                AS->update(PQ_INPUTS, p + 1e-2, 1);
                CoolPropDbl v1 = AS->keyed_output(pair.p1);
                AS->update(PQ_INPUTS, p - 1e-2, 1);
                CoolPropDbl v2 = AS->keyed_output(pair.p1);
                numerical = (v1 - v2) / (2e-2);
            } else {
                throw ValueError();
            }
            CAPTURE(numerical);
            CHECK(std::abs(numerical / analytical - 1) < 1e-4);
        }
    }
}

TEST_CASE("Check the second saturation derivatives", "[second_saturation_partial_deriv]") {
    const int number_of_pairs = 5;
    struct pair
    {
        parameters p1, p2, p3;
    };
    pair pairs[number_of_pairs] = {{iT, iP, iP}, {iDmolar, iP, iP}, {iHmolar, iP, iP}, {iSmolar, iP, iP}, {iUmolar, iP, iP}};
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "n-Propane"));
    for (auto& pair : pairs) {
        // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
        std::ostringstream ss1;
        ss1 << "Check second saturation derivative for d2(" << get_parameter_information(pair.p1, "short") << ")/d("
            << get_parameter_information(pair.p2, "short") << ")2|sat";
        SECTION(ss1.str(), "") {
            AS->update(QT_INPUTS, 1, 300);
            CoolPropDbl p = AS->p();
            CoolPropDbl analytical = AS->second_saturation_deriv(pair.p1, pair.p2, pair.p3);
            CAPTURE(analytical);
            CoolPropDbl numerical;
            if (pair.p2 == iT) {
                throw NotImplementedError();
            } else if (pair.p2 == iP) {
                AS->update(PQ_INPUTS, p + 1e-2, 1);
                CoolPropDbl v1 = AS->first_saturation_deriv(pair.p1, pair.p2);
                AS->update(PQ_INPUTS, p - 1e-2, 1);
                CoolPropDbl v2 = AS->first_saturation_deriv(pair.p1, pair.p2);
                numerical = (v1 - v2) / (2e-2);
            } else {
                throw ValueError();
            }
            CAPTURE(numerical);
            CHECK(std::abs(numerical / analytical - 1) < 1e-4);
        }
    }
}

TEST_CASE("Check the first two-phase derivative", "[first_two_phase_deriv]") {
    const int number_of_pairs = 4;
    struct pair
    {
        parameters p1, p2, p3;
    };
    pair pairs[number_of_pairs] = {{iDmass, iP, iHmass}, {iDmolar, iP, iHmolar}, {iDmolar, iHmolar, iP}, {iDmass, iHmass, iP}};
    shared_ptr<CoolProp::HelmholtzEOSBackend> AS = std::make_shared<CoolProp::HelmholtzEOSBackend>("n-Propane");
    for (auto& pair : pairs) {
        // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
        std::ostringstream ss1;
        ss1 << "for (" << get_parameter_information(pair.p1, "short") << ", " << get_parameter_information(pair.p2, "short") << ", "
            << get_parameter_information(pair.p3, "short") << ")";
        SECTION(ss1.str(), "") {
            AS->update(QT_INPUTS, 0.3, 300);
            CoolPropDbl numerical;
            CoolPropDbl analytical = AS->first_two_phase_deriv(pair.p1, pair.p2, pair.p3);
            CAPTURE(analytical);

            CoolPropDbl out1, out2;
            CoolPropDbl v2base, v3base;
            v2base = AS->keyed_output(pair.p2);
            v3base = AS->keyed_output(pair.p3);
            CoolPropDbl v2plus = v2base * 1.001;
            CoolPropDbl v2minus = v2base * 0.999;
            CoolProp::input_pairs input_pair1 = generate_update_pair(pair.p2, v2plus, pair.p3, v3base, out1, out2);
            AS->update(input_pair1, out1, out2);
            CoolPropDbl v1 = AS->keyed_output(pair.p1);
            CoolProp::input_pairs input_pair2 = generate_update_pair(pair.p2, v2minus, pair.p3, v3base, out1, out2);
            AS->update(input_pair2, out1, out2);
            CoolPropDbl v2 = AS->keyed_output(pair.p1);

            numerical = (v1 - v2) / (v2plus - v2minus);
            CAPTURE(numerical);
            CHECK(std::abs(numerical / analytical - 1) < 1e-4);
        }
    }
}

TEST_CASE("Check the second two-phase derivative", "[second_two_phase_deriv]") {
    SECTION("d2rhodhdp", "") {
        shared_ptr<CoolProp::HelmholtzEOSBackend> AS = std::make_shared<CoolProp::HelmholtzEOSBackend>("n-Propane");
        AS->update(QT_INPUTS, 0.3, 300);
        CoolPropDbl analytical = AS->second_two_phase_deriv(iDmolar, iHmolar, iP, iP, iHmolar);
        CAPTURE(analytical);
        CoolPropDbl pplus = AS->p() * 1.001, pminus = AS->p() * 0.999, h = AS->hmolar();
        AS->update(HmolarP_INPUTS, h, pplus);
        CoolPropDbl v1 = AS->first_two_phase_deriv(iDmolar, iHmolar, iP);
        AS->update(HmolarP_INPUTS, h, pminus);
        CoolPropDbl v2 = AS->first_two_phase_deriv(iDmolar, iHmolar, iP);
        CoolPropDbl numerical = (v1 - v2) / (pplus - pminus);
        CAPTURE(numerical);
        CHECK(std::abs(numerical / analytical - 1) < 1e-6);
    }
    SECTION("d2rhodhdp using mass", "") {
        shared_ptr<CoolProp::HelmholtzEOSBackend> AS = std::make_shared<CoolProp::HelmholtzEOSBackend>("n-Propane");
        AS->update(QT_INPUTS, 0.3, 300);
        CoolPropDbl analytical = AS->second_two_phase_deriv(iDmass, iHmass, iP, iP, iHmass);
        CAPTURE(analytical);
        CoolPropDbl pplus = AS->p() * 1.001, pminus = AS->p() * 0.999, h = AS->hmass();
        AS->update(HmassP_INPUTS, h, pplus);
        CoolPropDbl v1 = AS->first_two_phase_deriv(iDmass, iHmass, iP);
        AS->update(HmassP_INPUTS, h, pminus);
        CoolPropDbl v2 = AS->first_two_phase_deriv(iDmass, iHmass, iP);
        CoolPropDbl numerical = (v1 - v2) / (pplus - pminus);
        CAPTURE(numerical);
        CHECK(std::abs(numerical / analytical - 1) < 1e-6);
    }
}

TEST_CASE("Check the first two-phase derivative using splines", "[first_two_phase_deriv_splined]") {
    /**
     
    A. Take the code from https://github.com/ibell/coolprop...
    B. Apply this diff
     
     diff --git a/CMakeLists.txt b/CMakeLists.txt
     index 5c639f9c..e3e25c68 100644
     --- a/CMakeLists.txt
     +++ b/CMakeLists.txt
     @@ -82,3 +82,7 @@ if (COOLPROP_STATIC_LIBRARY)
      else()
          add_library(${app_name} SHARED ${APP_SOURCES})
      endif()
     +
     +
     +add_executable(main main.cpp)
     +target_link_libraries(main CoolProp)
     diff --git a/main.cpp b/main.cpp
     index 526d0090..863956ed 100644
     --- a/main.cpp
     +++ b/main.cpp
     @@ -1,9 +1,18 @@
      #include "CoolProp/CoolProp.h"
     +#include "CPState.h"
      #include <iostream>
      #include <stdlib.h>
      
      int main()
      {
     +    CoolPropStateClassSI state("n-Propane");
     +    double rho_spline, dsplinedh, dsplinedp;
     +    state.update(iT, 300, iQ, 0.2);
     +    state.rho_smoothed(0.3, rho_spline, dsplinedh, dsplinedp);
     +    double p_ = state.p();
     +    double h_ = state.h();
     +
     +
          double T = Props("T","H",246.532409342343,"P",1896.576573868160,"R410A");
          std::cout << T << std::endl;
     -}
     \ No newline at end of file
     +}
     
    C. cmake -B bld -S .
    D. cmake --build bld
    E. stdout has the values for the derivatives in mass-based units
     */

    using paramtuple = std::tuple<parameters, parameters, parameters>;

    SECTION("Compared with reference data") {

        std::map<paramtuple, double> pairs = {{{iDmass, iP, iHmass}, 0.00056718665544440146},
                                              {{iDmass, iHmass, iP}, -0.0054665229407696173},
                                              {{iDmass, iDmass, iDmass}, 179.19799206447755}};

        std::unique_ptr<CoolProp::HelmholtzEOSBackend> AS(new CoolProp::HelmholtzEOSBackend("n-Propane"));
        for (auto& [pair, expected_value] : pairs) {
            // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
            std::ostringstream ss1;
            auto& [p1, p2, p3] = pair;
            ss1 << "for (" << get_parameter_information(p1, "short") << ", " << get_parameter_information(p2, "short") << ", "
                << get_parameter_information(p3, "short") << ")";
            double x_end = 0.3;
            SECTION(ss1.str(), "") {
                AS->update(QT_INPUTS, 0.2, 300);
                CoolPropDbl analytical = AS->first_two_phase_deriv_splined(p1, p2, p3, x_end);
                CAPTURE(analytical);
                CHECK(std::abs(expected_value / analytical - 1) < 1e-8);
            }
        }
    }
    SECTION("Finite diffs") {
        std::vector<paramtuple> pairs = {{iDmass, iHmass, iP}, {iDmolar, iHmolar, iP}};  //, {iDmass, iHmass, iP}};
        std::unique_ptr<CoolProp::HelmholtzEOSBackend> AS(new CoolProp::HelmholtzEOSBackend("n-Propane"));
        for (auto& pair : pairs) {
            // See https://groups.google.com/forum/?fromgroups#!topic/catch-forum/mRBKqtTrITU
            std::ostringstream ss1;
            auto& [p1, p2, p3] = pair;
            ss1 << "for (" << get_parameter_information(p1, "short") << ", " << get_parameter_information(p2, "short") << ", "
                << get_parameter_information(p3, "short") << ")";
            double x_end = 0.3;
            SECTION(ss1.str(), "") {
                AS->update(QT_INPUTS, 0.2, 300);
                CoolPropDbl numerical;
                CoolPropDbl analytical = AS->first_two_phase_deriv_splined(p1, p2, p3, x_end);
                CAPTURE(analytical);

                CoolPropDbl out1, out2;
                CoolPropDbl v2base, v3base;
                v2base = AS->keyed_output(p2);
                v3base = AS->keyed_output(p3);
                CoolPropDbl v2plus = v2base * 1.00001;
                CoolPropDbl v2minus = v2base * 0.99999;

                // Get the density (molar or specific) for the second variable shifted up with the third variable
                // held constant
                CoolProp::input_pairs input_pair1 = generate_update_pair(p2, v2plus, p3, v3base, out1, out2);
                AS->update(input_pair1, out1, out2);
                CoolPropDbl D1 = AS->first_two_phase_deriv_splined(p1, p1, p1, x_end);

                // Get the density (molar or specific) for the second variable shifted down with the third variable
                // held constant
                CoolProp::input_pairs input_pair2 = generate_update_pair(p2, v2minus, p3, v3base, out1, out2);
                AS->update(input_pair2, out1, out2);
                CoolPropDbl D2 = AS->first_two_phase_deriv_splined(p1, p1, p1, x_end);

                numerical = (D1 - D2) / (v2plus - v2minus);
                CAPTURE(numerical);
                CHECK(std::abs(numerical / analytical - 1) < 1e-8);
            }
        }
    }
}

TEST_CASE("Check the phase flags", "[phase]") {
    SECTION("subcooled liquid") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(PT_INPUTS, 101325, 300);
        CHECK(AS->phase() == iphase_liquid);
    }
    SECTION("superheated gas") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(PT_INPUTS, 101325, 400);
        CHECK(AS->phase() == iphase_gas);
    }
    SECTION("supercritical gas") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(PT_INPUTS, 1e5, 800);
        CHECK(AS->phase() == iphase_supercritical_gas);
    }
    SECTION("supercritical liquid") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(PT_INPUTS, 1e8, 500);
        CHECK(AS->phase() == iphase_supercritical_liquid);
    }
    SECTION("supercritical") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(PT_INPUTS, 1e8, 800);
        CHECK(AS->phase() == iphase_supercritical);
    }
}

TEST_CASE("Check the changing of reducing function constants", "[reducing]") {
    double z0 = 0.2;
    std::vector<double> z(2);
    z[0] = z0;
    z[1] = 1 - z[0];
    shared_ptr<CoolProp::AbstractState> AS1(CoolProp::AbstractState::factory("HEOS", "Methane&Ethane"));
    shared_ptr<CoolProp::AbstractState> AS2(CoolProp::AbstractState::factory("HEOS", "Methane&Ethane"));
    AS1->set_mole_fractions(z);
    AS2->set_mole_fractions(z);
    std::vector<CoolProp::CriticalState> pts1 = AS1->all_critical_points();
    double gammaT = AS2->get_binary_interaction_double(0, 1, "gammaT");
    AS2->set_binary_interaction_double(0, 1, "gammaT", gammaT * 0.7);
    std::vector<CoolProp::CriticalState> pts2 = AS2->all_critical_points();
    double Tdiff = abs(pts2[0].T - pts1[0].T);
    CHECK(Tdiff > 1e-3);  // Make sure that it actually got the change to the interaction parameters
}

TEST_CASE("Check the PC-SAFT pressure function", "[pcsaft_pressure]") {
    double p = 101325.;
    double p_calc = CoolProp::PropsSI("P", "T", 320., "Dmolar", 9033.114359706229, "PCSAFT::TOLUENE");
    CHECK(abs((p_calc / p) - 1) < 1e-5);

    p_calc = CoolProp::PropsSI("P", "T", 274., "Dmolar", 55530.40675319466, "PCSAFT::WATER");
    CHECK(abs((p_calc / p) - 1) < 1e-5);

    p_calc = CoolProp::PropsSI("P", "T", 305., "Dmolar", 16965.6697209874, "PCSAFT::ACETIC ACID");
    CHECK(abs((p_calc / p) - 1) < 1e-5);

    p_calc = CoolProp::PropsSI("P", "T", 240., "Dmolar", 15955.50941242, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((p_calc / p) - 1) < 1e-5);

    p_calc = CoolProp::PropsSI("P", "T", 298.15, "Dmolar", 9368.903838750752, "PCSAFT::METHANOL[0.055]&CYCLOHEXANE[0.945]");
    CHECK(abs((p_calc / p) - 1) < 1e-5);

    //p_calc = CoolProp::PropsSI("P", "T", 298.15, "Dmolar", 55757.07260200306, "PCSAFT::Na+[0.010579869455908]&Cl-[0.010579869455908]&WATER[0.978840261088184]");
    //CHECK(abs((p_calc/p) - 1) < 1e-5);

    p = CoolProp::PropsSI("P", "T", 100., "Q", 0, "PCSAFT::PROPANE");
    double rho = 300;
    double phase = CoolProp::PropsSI("Phase", "T", 100., "Dmolar", rho, "PCSAFT::PROPANE");
    CHECK(phase == get_phase_index("phase_twophase"));
    p_calc = CoolProp::PropsSI("P", "T", 100, "Dmolar", rho, "PCSAFT::PROPANE");
    CHECK(abs((p_calc / p) - 1) < 1e-4);
}

TEST_CASE("Tkaczuk et al. (2020) cryogenic mixtures reproduce Table 8", "[Tkaczuk]") {
    // Validation points from Tkaczuk, Lemmon, Bell, Luchier, Millet,
    // J. Phys. Chem. Ref. Data 49, 023101 (2020), Table 8: equimolar
    // (0.50/0.50) composition at T = 200 K and rho = 10 mol/dm^3.
    const double T = 200.0, rhomolar = 10000.0;  // 10 mol/dm^3 -> mol/m^3
    std::vector<double> z(2, 0.5);

    // The reference pressures were generated (see the paper's supplementary
    // CoolProp validation script) with NORMALIZE_GAS_CONSTANTS = false, i.e.
    // each mixture uses the mole-fraction-weighted average of its components'
    // own EOS gas constants rather than the harmonized CODATA value.  Forcing
    // CODATA instead shifts the argon-containing pairs by ~2.7e-6 (argon's EOS
    // R = 8.31451 vs CODATA 8.314463), so match the paper's convention here.
    // RAII so the global config is restored even if a CHECK below throws.
    struct NormalizeGuard
    {
        bool prev;
        NormalizeGuard() : prev(CoolProp::get_config_bool(NORMALIZE_GAS_CONSTANTS)) {
            CoolProp::set_config_bool(NORMALIZE_GAS_CONSTANTS, false);
        }
        ~NormalizeGuard() {
            CoolProp::set_config_bool(NORMALIZE_GAS_CONSTANTS, prev);
        }
    } normalize_guard;

    struct
    {
        const char* fluids;
        double p_ref;
    } cases[] = {
      {"Helium&Neon", 18430775.292601},
      {"Helium&Argon", 17128034.388363},
      {"Neon&Argon", 15905875.375781},
    };
    for (auto& c : cases) {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", c.fluids));
        AS->set_mole_fractions(z);
        // T = 200 K is above the critical temperature of every constituent
        // (Ar Tc = 150.7 K is the highest), so the state is single-phase.
        // Impose the phase: the HEOS density-temperature flash does not yet
        // run the phase determination for mixtures, but it evaluates the
        // pressure directly from (rho, T) when a phase is imposed.
        AS->specify_phase(CoolProp::iphase_supercritical_gas);
        AS->update(CoolProp::DmolarT_INPUTS, rhomolar, T);
        double p = AS->p();
        CAPTURE(c.fluids);
        CAPTURE(p);
        CAPTURE(c.p_ref);
        // CoolProp reproduces the published pressures essentially to machine
        // precision (observed < 1e-12); 1e-10 leaves a little platform margin.
        CHECK(std::abs(p / c.p_ref - 1) < 1e-10);
    }

    // The equimolar pressures above are algebraically invariant under
    // beta -> 1/beta (the GERG reducing weight x1*x2*(x1+x2)/(beta^2*x1+x2)
    // collapses to beta/(beta^2+1) at x1=x2), so they cannot detect a
    // Name1/Name2 (and hence beta) inversion in the binary-pair table.  Pin
    // the reducing temperature and density at a NON-equimolar composition,
    // where the asymmetric reducing parameters do matter.  Reference values
    // computed directly from the GERG reducing rules (paper Eq. 3) with the
    // Table 6 parameters in the documented (i,j) order and CoolProp's pure
    // reducing constants; an inverted betaT shifts T_r by 0.4-3%.
    struct
    {
        const char* fluids;
        double Tr_ref, rhor_ref;
    } redcases[] = {
      {"Helium&Neon", 26.3675566619, 23988.632514},
      {"Helium&Argon", 87.5390792465, 15166.941197},
      {"Neon&Argon", 111.4722707992, 15642.518187},
    };
    std::vector<double> znq{0.3, 0.7};
    for (auto& c : redcases) {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", c.fluids));
        AS->set_mole_fractions(znq);
        CAPTURE(c.fluids);
        CHECK(std::abs(AS->T_reducing() / c.Tr_ref - 1) < 1e-8);
        CHECK(std::abs(AS->rhomolar_reducing() / c.rhor_ref - 1) < 1e-6);
    }
}

TEST_CASE("Check the PC-SAFT density function", "[pcsaft_density]") {
    double den = 9033.114209728405;
    double den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 320., "P", 101325., "PCSAFT::TOLUENE");
    CHECK(abs((den_calc / den) - 1) < 1e-5);

    den = 55530.40512318346;
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 274., "P", 101325, "PCSAFT::WATER");
    CHECK(abs((den_calc / den) - 1) < 1e-5);

    den = 17240.;  // source: DIPPR correlation
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 305., "P", 101325, "PCSAFT::ACETIC ACID");
    CHECK(abs((den_calc / den) - 1) < 2e-2);

    den = 15955.509146801696;
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 240., "P", 101325, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((den_calc / den) - 1) < 1e-5);

    den = 9368.90368306872;
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 298.15, "P", 101325, "PCSAFT::METHANOL[0.055]&CYCLOHEXANE[0.945]");
    CHECK(abs((den_calc / den) - 1) < 1e-5);

    den = 55740.157290833515;
    den_calc =
      CoolProp::PropsSI("Dmolar", "T|liquid", 298.15, "P", 101325, "PCSAFT::Na+[0.010579869455908]&Cl-[0.010579869455908]&WATER[0.978840261088184]");
    CHECK(abs((den_calc / den) - 1) < 1e-5);

    den = 16621.0;
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 85.525, "P", 1.7551e-4, "PCSAFT::PROPANE");
    CHECK(abs((den_calc / den) - 1) < 1e-2);

    den = 1.9547e-7;
    den_calc = CoolProp::PropsSI("Dmolar", "T|gas", 85.525, "P", 1.39e-4, "PCSAFT::PROPANE");
    CHECK(abs((den_calc / den) - 1) < 1e-2);

    den = 11346.0;
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 293, "P", 833240, "PCSAFT::PROPANE");
    CHECK(abs((den_calc / den) - 1) < 1e-2);

    den = 623.59;
    den_calc = CoolProp::PropsSI("Dmolar", "T|liquid", 430, "P", 2000000, "PCSAFT::PROPANE");
    CHECK(abs((den_calc / den) - 1) < 1e-2);
}

TEST_CASE("Check the PC-SAFT residual enthalpy function", "[pcsaft_enthalpy]") {
    double h = -36809.962122036086;
    double h_calc = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 8983.377722763931, "PCSAFT::TOLUENE");
    CHECK(abs((h_calc / h) - 1) < 1e-5);

    h = -362.6832840695562;
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 39.44490805826904, "PCSAFT::TOLUENE");
    CHECK(abs((h_calc / h) - 1) < 1e-5);

    h = -38925.302571456035;
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 16655.853047419932, "PCSAFT::ACETIC ACID");
    CHECK(abs((h_calc / h) - 1) < 1e-5);

    h = -15393.870073928741;
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 85.70199446609787, "PCSAFT::ACETIC ACID");
    CHECK(abs((h_calc / h) - 1) < 1e-5);

    h = -18242.128097841978;
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 13141.475980937616, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((h_calc / h) - 1) < 1e-5);

    h = -93.819615173017169;
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 37.963459290365265, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((h_calc / h) - 1) < 1e-5);

    // checks based on values from the HEOS backend
    h = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 8983.377722763931, "HEOS::TOLUENE");
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 8983.377722763931, "PCSAFT::TOLUENE");
    CHECK(abs(h_calc - h) < 600.);

    h = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 39.44490805826904, "HEOS::TOLUENE");
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 39.44490805826904, "PCSAFT::TOLUENE");
    CHECK(abs(h_calc - h) < 600.);

    h = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 54794.1, "HEOS::WATER");
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|liquid", 325., "Dmolar", 54794.1, "PCSAFT::WATER");
    CHECK(abs(h_calc - h) < 600.);

    h = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 0.370207, "HEOS::WATER");
    h_calc = CoolProp::PropsSI("Hmolar_residual", "T|gas", 325., "Dmolar", 0.370207, "PCSAFT::WATER");
    CHECK(abs(h_calc - h) < 600.);
}

TEST_CASE("Check the PC-SAFT residual entropy function", "[pcsaft_entropy]") {
    // checks based on values from working PC-SAFT code
    double s = -50.81694890352192;
    double s_calc = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 8983.377722763931, "PCSAFT::TOLUENE");
    CHECK(abs((s_calc / s) - 1) < 1e-5);

    s = -0.2929618646219797;
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 39.44490805826904, "PCSAFT::TOLUENE");
    CHECK(abs((s_calc / s) - 1) < 1e-5);

    s = -47.42736805661422;
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 16655.853047419932, "PCSAFT::ACETIC ACID");
    CHECK(abs((s_calc / s) - 1) < 1e-5);

    s = -34.0021996393859;
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 85.70199446609787, "PCSAFT::ACETIC ACID");
    CHECK(abs((s_calc / s) - 1) < 1e-5);

    s = -26.42525828195748;
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 13141.475980937616, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((s_calc / s) - 1) < 1e-5);

    s = -0.08427662199177874;
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 37.963459290365265, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((s_calc / s) - 1) < 1e-5);

    // checks based on values from the HEOS backend
    s = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 8983.377722763931, "HEOS::TOLUENE");
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 8983.377722763931, "PCSAFT::TOLUENE");
    CHECK(abs(s_calc - s) < 3.);

    s = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 39.44490805826904, "HEOS::TOLUENE");
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 39.44490805826904, "PCSAFT::TOLUENE");
    CHECK(abs(s_calc - s) < 3.);

    s = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 54794.1, "HEOS::WATER");
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|liquid", 325., "Dmolar", 54794.1, "PCSAFT::WATER");
    CHECK(abs(s_calc - s) < 3.);

    s = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 0.370207, "HEOS::WATER");
    s_calc = CoolProp::PropsSI("Smolar_residual", "T|gas", 325., "Dmolar", 0.370207, "PCSAFT::WATER");
    CHECK(abs(s_calc - s) < 3.);
}

TEST_CASE("Check the PC-SAFT residual gibbs energy function", "[pcsaft_gibbs]") {
    // Expected values were updated in #1943 — the previous formula was
    // (alphar + Z - 1 - ln Z) * RT (g_res on (T,P) basis), which did not
    // satisfy the CoolProp-wide convention g_res = h_res - T*s_res.
    // The new values come from g_res = h_res - T*s_res on (T,ρ) basis,
    // matching HEOS::calc_gibbsmolar_residual.
    double g = -20294.461258;
    double g_calc = CoolProp::PropsSI("Gmolar_residual", "T|liquid", 325., "Dmolar", 8983.377872003264, "PCSAFT::TOLUENE");
    CHECK(abs((g_calc / g) - 1) < 1e-5);

    g = -267.470804;
    g_calc = CoolProp::PropsSI("Gmolar_residual", "T|gas", 325., "Dmolar", 39.44491269148218, "PCSAFT::TOLUENE");
    CHECK(abs((g_calc / g) - 1) < 1e-5);

    g = -23511.405979;
    g_calc = CoolProp::PropsSI("Gmolar_residual", "T|liquid", 325., "Dmolar", 16655.853314424, "PCSAFT::ACETIC ACID");
    CHECK(abs((g_calc / g) - 1) < 1e-5);

    g = -4343.156768;
    g_calc = CoolProp::PropsSI("Gmolar_residual", "T|gas", 325., "Dmolar", 85.70199446609787, "PCSAFT::ACETIC ACID");
    CHECK(abs((g_calc / g) - 1) < 1e-5);

    g = -9653.922736;
    g_calc = CoolProp::PropsSI("Gmolar_residual", "T|liquid", 325., "Dmolar", 13141.47619110254, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((g_calc / g) - 1) < 1e-5);

    g = -66.429712;
    g_calc = CoolProp::PropsSI("Gmolar_residual", "T|gas", 325., "Dmolar", 37.96344503293008, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((g_calc / g) - 1) < 1e-5);
}

TEST_CASE("PC-SAFT gibbsmolar_residual satisfies g_res = h_res - T*s_res (#1943)", "[pcsaft_gibbs][1943]") {
    // Issue #1943: PCSAFT's calc_gibbsmolar_residual used Gross & Sadowski
    // A.50 [(alphar + Z - 1 - ln Z) * RT, on (T,P) basis] which does not
    // equal h_res - T*s_res. CoolProp's HEOS uses (T,ρ) basis throughout,
    // so the two backends gave inconsistent answers. The fix drops the
    // -ln(Z)*RT term so all backends satisfy g_res = h_res - T*s_res.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("PCSAFT", "METHANE"));
    const double T = 100.0;
    AS->update(CoolProp::QT_INPUTS, 0.0, T);
    const double g = AS->gibbsmolar_residual();
    const double h = AS->hmolar_residual();
    const double s = AS->smolar_residual();
    CAPTURE(g);
    CAPTURE(h);
    CAPTURE(s);
    CHECK(std::abs(g - (h - T * s)) < 1e-6);
}

TEST_CASE("Check vapor pressures calculated using PC-SAFT", "[pcsaft_vapor_pressure]") {
    double vp = 3290651.18080112;
    double vp_calc = CoolProp::PropsSI("P", "T", 572.6667, "Q", 0, "PCSAFT::TOLUENE");
    CHECK(abs((vp_calc / vp) - 1) < 1e-3);

    vp = 66917.67387203;
    vp_calc = CoolProp::PropsSI("P", "T", 362, "Q", 0, "PCSAFT::WATER");
    CHECK(abs((vp_calc / vp) - 1) < 1e-3);

    vp = 190061.78088909;
    vp_calc = CoolProp::PropsSI("P", "T", 413.5385, "Q", 0, "PCSAFT::ACETIC ACID");
    CHECK(abs((vp_calc / vp) - 1) < 1e-3);

    vp = 622763.506195;
    vp_calc = CoolProp::PropsSI("P", "T", 300., "Q", 0, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((vp_calc / vp) - 1) < 1e-3);

    // This test doesn't pass yet. The flash algorithm for the PC-SAFT backend is not yet robust enough.
    // vp = 1.7551e-4;
    // vp_calc = CoolProp::PropsSI("P","T",85.525,"Q", 0, "PCSAFT::PROPANE");
    // CHECK(abs((vp_calc/vp) - 1) < 0.1);

    vp = 8.3324e5;
    vp_calc = CoolProp::PropsSI("P", "T", 293, "Q", 0, "PCSAFT::PROPANE");
    CHECK(abs((vp_calc / vp) - 1) < 0.01);

    vp = 42.477e5;
    vp_calc = CoolProp::PropsSI("P", "T", 369.82, "Q", 0, "PCSAFT::PROPANE");
    CHECK(abs((vp_calc / vp) - 1) < 0.01);
}

TEST_CASE("Check PC-SAFT interaction parameter functions", "[pcsaft_binary_interaction]") {
    std::string CAS_water = get_fluid_param_string("WATER", "CAS");
    std::string CAS_aacid = "64-19-7";
    set_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij", -0.127);
    CHECK(atof(get_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij").c_str()) == -0.127);
}

TEST_CASE("Check bubble pressures calculated using PC-SAFT", "[pcsaft_bubble_pressure]") {
    double vp =
      1816840.45112607;  // source: H.-M. Lin, H. M. Sebastian, J. J. Simnick, and K.-C. Chao, “Gas-liquid equilibrium in binary mixtures of methane with N-decane, benzene, and toluene,” J. Chem. Eng. Data, vol. 24, no. 2, pp. 146–149, Apr. 1979.
    double vp_calc = CoolProp::PropsSI("P", "T", 421.05, "Q", 0, "PCSAFT::METHANE[0.0252]&BENZENE[0.9748]");
    CHECK(abs((vp_calc / vp) - 1) < 1e-3);

    // This test doesn't pass yet. The flash algorithm for the PC-SAFT backend cannot yet get a good enough initial guess value for the k values (vapor-liquid distribution ratios)
    // vp = 6691000; // source: Hughes TJ, Kandil ME, Graham BF, Marsh KN, Huang SH, May EF. Phase equilibrium measurements of (methane+ benzene) and (methane+ methylbenzene) at temperatures from (188 to 348) K and pressures to 13 MPa. The Journal of Chemical Thermodynamics. 2015 Jun 1;85:141-7.
    // vp_calc = CoolProp::PropsSI("P", "T", 348.15, "Q", 0, "PCSAFT::METHANE[0.119]&BENZENE[0.881]");
    // CHECK(abs((vp_calc/vp) - 1) < 1e-3);

    vp = 96634.2439079;
    vp_calc = CoolProp::PropsSI("P", "T", 327.48, "Q", 0, "PCSAFT::METHANOL[0.3]&CYCLOHEXANE[0.7]");
    CHECK(abs((vp_calc / vp) - 1) < 1e-3);

    // set binary interaction parameter
    std::string CAS_water = get_fluid_param_string("WATER", "CAS");
    std::string CAS_aacid = "64-19-7";
    try {
        get_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij");
    } catch (...) {
        set_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij", -0.127);
    }

    vp = 274890.39985918;
    vp_calc = CoolProp::PropsSI("P", "T", 403.574, "Q", 0, "PCSAFT::WATER[0.9898662364]&ACETIC ACID[0.0101337636]");
    CHECK(abs((vp_calc / vp) - 1) < 1e-2);

    vp = 72915.92217342;
    vp_calc = CoolProp::PropsSI("P", "T", 372.774, "Q", 0, "PCSAFT::WATER[0.2691800943]&ACETIC ACID[0.7308199057]");
    CHECK(abs((vp_calc / vp) - 1) < 2e-2);

    vp = 2387.42669687;
    vp_calc = CoolProp::PropsSI("P", "T", 298.15, "Q", 0, "PCSAFT::Na+[0.0907304774758426]&Cl-[0.0907304774758426]&WATER[0.818539045048315]");
    CHECK(abs((vp_calc / vp) - 1) < 0.23);
}

TEST_CASE("Check bubble temperatures calculated using PC-SAFT", "[pcsaft_bubble_temperature]") {
    double t = 572.6667;
    double t_calc = CoolProp::PropsSI("T", "P", 3290651.18080112, "Q", 0, "PCSAFT::TOLUENE");
    CHECK(abs((t_calc / t) - 1) < 1e-3);

    t = 362;
    t_calc = CoolProp::PropsSI("T", "P", 66917.67387203, "Q", 0, "PCSAFT::WATER");
    CHECK(abs((t_calc / t) - 1) < 1e-3);

    t = 413.5385;
    t_calc = CoolProp::PropsSI("T", "P", 190061.78088909, "Q", 0, "PCSAFT::ACETIC ACID");
    CHECK(abs((t_calc / t) - 1) < 1e-3);

    t = 300.;
    t_calc = CoolProp::PropsSI("T", "P", 623027.07850612, "Q", 0, "PCSAFT::DIMETHYL ETHER");
    CHECK(abs((t_calc / t) - 1) < 1e-3);

    // This test doesn't pass yet. The flash algorithm for the PC-SAFT backend cannot yet get a good enough initial guess value for the k values (vapor-liquid distribution ratios)
    // t = 421.05;
    // t_calc = CoolProp::PropsSI("T", "P", 1816840.45112607, "Q", 0, "PCSAFT::METHANE[0.0252]&BENZENE[0.9748]");
    // CHECK(abs((t_calc/t) - 1) < 1e-3);

    t = 327.48;
    t_calc = CoolProp::PropsSI("T", "P", 96634.2439079, "Q", 0, "PCSAFT::METHANOL[0.3]&CYCLOHEXANE[0.7]");
    CHECK(abs((t_calc / t) - 1) < 1e-3);

    // set binary interaction parameter, if not already set
    std::string CAS_water = get_fluid_param_string("WATER", "CAS");
    std::string CAS_aacid = "64-19-7";
    try {
        get_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij");
    } catch (...) {
        set_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij", -0.127);
    }

    t = 403.574;
    t_calc = CoolProp::PropsSI("T", "P", 274890.39985918, "Q", 0, "PCSAFT::WATER[0.9898662364]&ACETIC ACID[0.0101337636]");
    CHECK(abs((t_calc / t) - 1) < 1e-3);

    t = 372.774;
    t_calc = CoolProp::PropsSI("T", "P", 72915.92217342, "Q", 0, "PCSAFT::WATER[0.2691800943]&ACETIC ACID[0.7308199057]");
    CHECK(abs((t_calc / t) - 1) < 2e-3);

    t = 298.15;
    t_calc = CoolProp::PropsSI("T", "P", 2387.42669687, "Q", 0, "PCSAFT::Na+[0.0907304774758426]&Cl-[0.0907304774758426]&WATER[0.818539045048315]");
    CHECK(abs((t_calc / t) - 1) < 1e-2);
}

TEST_CASE("Github issue #2470", "[pureflash]") {
    auto fluide = "Nitrogen";
    auto enthalpy = 67040.57857;  //J / kg
    auto pressure = 3368965.046;  //Pa
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", fluide));
    AS->update(PQ_INPUTS, pressure, 1);
    auto Ts = AS->T();
    AS->specify_phase(iphase_gas);
    CHECK_NOTHROW(AS->update(PT_INPUTS, pressure, Ts));
    AS->unspecify_phase();
    CHECK_NOTHROW(AS->update(HmassP_INPUTS, enthalpy, pressure));
    auto Tfinal = AS->T();
    CHECK(Tfinal > AS->T_critical());
}

TEST_CASE("Github issue #2467", "[pureflash]") {
    auto fluide = "Pentane";
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", fluide));
    AS->update(CoolProp::QT_INPUTS, 1, 353.15);
    double p1 = AS->p();
    AS->update(CoolProp::QT_INPUTS, 1, 433.15);
    double p2 = AS->p();
    AS->update(CoolProp::PT_INPUTS, p1, 393.15);
    double s1 = AS->smass();
    CHECK_NOTHROW(AS->update(CoolProp::PSmass_INPUTS, p2, s1));
}

TEST_CASE("Github issue #1870", "[pureflash]") {
    auto fluide = "Pentane";
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", fluide));
    CHECK_NOTHROW(AS->update(CoolProp::PSmass_INPUTS, 1000000, 1500));
}

TEST_CASE("Github issue #2447", "[2447]") {
    double pvap = PropsSI("P", "T", 360 + 273.15, "Q", 0, "INCOMP::S800");
    double err = std::abs(pvap / 961e3 - 1);
    CHECK(err < 0.05);
}

TEST_CASE("Github issue #2558", "[2558]") {
    double Tau = CoolProp::PropsSI("Tau", "Dmolar|gas", 200.0, "T", 300.0, "CarbonDioxide[0.5]&Hydrogen[0.5]");
    double Delta = CoolProp::PropsSI("Delta", "Dmolar|gas", 200.0, "T", 300.0, "CarbonDioxide[0.5]&Hydrogen[0.5]");
    CHECK(std::isfinite(Tau));
    CHECK(std::isfinite(Delta));
}

TEST_CASE("Github issue #2491", "[2491]") {
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", "Xenon"));
    CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, 59867.351071950761, 5835843.7305891514));
    CHECK(std::isfinite(AS->rhomolar()));
}

TEST_CASE("Github issue #2608", "[2608]") {
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", "CO2"));
    double pc = AS->p_critical();
    // 218.048 K was updated to 218.050 K: the new melting line check now rejects inputs
    // below Tmelt(p), and at p=73.8e5 Pa CO2's melting temperature is ~218.049 K.
    CHECK_NOTHROW(AS->update(CoolProp::PT_INPUTS, 73.8e5, 218.050));
    SECTION("Without phase") {
        AS->unspecify_phase();
        CHECK_NOTHROW(AS->update(CoolProp::PSmass_INPUTS, 73.8e5, 1840.68));
    }
    SECTION("With phase") {
        AS->specify_phase(iphase_supercritical_gas);
        CHECK_NOTHROW(AS->update(CoolProp::PSmass_INPUTS, 73.8e5, 1840.68));
        AS->unspecify_phase();
    }
}

TEST_CASE("Github issue #2622", "[2622]") {
    auto h5 = 233250;
    auto p5 = 5e6;
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", "R123"));
    double pc = AS->p_critical();
    CAPTURE(pc);
    double Tt = AS->Ttriple();
    CAPTURE(Tt);

    /// Update at just below the triple point temp
    AS->update(PT_INPUTS, p5, 165.999);

    AS->update(HmassP_INPUTS, h5, p5);
    double A = AS->T();
    CAPTURE(A);
}

template <typename T>
std::vector<T> linspace(T start, T end, int num) {
    std::vector<T> linspaced;
    if (num <= 0) {
        return linspaced;  // Return empty vector for invalid num
    }
    if (num == 1) {
        linspaced.push_back(start);
        return linspaced;
    }

    T step = (end - start) / (num - 1);
    for (int i = 0; i < num; ++i) {
        linspaced.push_back(start + step * i);
    }
    return linspaced;
}

TEST_CASE("Github issue #2582", "[2582]") {
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", "CO2"));
    double pc = AS->p_critical();
    AS->update(PQ_INPUTS, 73.33e5, 0);
    double hmass_liq = AS->saturated_liquid_keyed_output(iHmass);
    double hmass_vap = AS->saturated_vapor_keyed_output(iHmass);
    //    std::cout << pc << std::endl;
    //    std::cout << hmass_liq << std::endl;
    //    std::cout << hmass_vap << std::endl;
    for (auto hmass : linspace(100e3, 700e3, 1000)) {
        CAPTURE(hmass);
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 73.76e5));
    }
    for (auto hmass : linspace(100e3, 700e3, 1000)) {
        CAPTURE(hmass);
        CHECK_NOTHROW(AS->update(CoolProp::HmassP_INPUTS, hmass, 73.33e5));
    }
}

TEST_CASE("Github issue #2594", "[2594]") {
    std::shared_ptr<CoolProp::AbstractState> AS(AbstractState::factory("HEOS", "CO2"));
    auto p = 7377262.928140703;
    double pc = AS->p_critical();
    AS->update(PQ_INPUTS, p, 0);
    double Tsat = AS->T();
    double rholiq = AS->rhomolar();
    double umass_liq = AS->saturated_liquid_keyed_output(iUmass);
    double umass_vap = AS->saturated_vapor_keyed_output(iUmass);
    //    std::cout << std::setprecision(20) << pc << std::endl;
    //    std::cout << umass_liq << std::endl;
    //    std::cout << umass_vap << std::endl;

    auto umass = 314719.5306503257;
    //    auto& rHEOS = *dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());
    //    bool sat_called = false;
    //    auto MM = AS->molar_mass();
    //    rHEOS.p_phase_determination_pure_or_pseudopure(iUmolar, umass*MM, sat_called);
    //    CHECK(rHEOS.phase() == iphase_liquid);

    AS->update(DmolarP_INPUTS, rholiq, p);
    double rho1 = AS->rhomolar();
    double T1 = AS->T();
    double dumolardT_P = AS->first_partial_deriv(iUmolar, iT, iP);
    double dpdrho_T = AS->first_partial_deriv(iP, iDmolar, iT);
    //    double dumassdT_P = AS->first_partial_deriv(iUmass, iT, iP);

    AS->specify_phase(iphase_liquid);
    AS->update(PT_INPUTS, p, Tsat);
    double rho2 = AS->rhomolar();
    double T2 = AS->T();
    double dpdrho_T_imposed = AS->first_partial_deriv(iP, iDmolar, iT);
    double dumolardT_P_imposed = AS->first_partial_deriv(iUmolar, iT, iP);
    //    double dumassdT_P_imposed = AS->first_partial_deriv(iUmass, iT, iP);
    AS->unspecify_phase();

    CHECK_NOTHROW(AS->update(CoolProp::PUmass_INPUTS, p, umass));

    BENCHMARK("dp/drho|T") {
        return AS->first_partial_deriv(iP, iDmolar, iT);
    };
    BENCHMARK("du/dT|p") {
        return AS->first_partial_deriv(iUmolar, iT, iP);
    };
}

TEST_CASE("CoolProp.jl tests", "[2598]") {
    //    // Whoah, actually quite a few change meaningfully
    //    SECTION("Check pcrit doesn't change too much with SA on"){
    //        auto init = get_config_bool(ENABLE_SUPERANCILLARIES);
    //        for (auto fluid : strsplit(get_global_param_string("fluids_list"), ',')){
    //            CAPTURE(fluid);
    //            set_config_bool(ENABLE_SUPERANCILLARIES, true); auto pcrit_SA = Props1SI(fluid, "pcrit");
    //            set_config_bool(ENABLE_SUPERANCILLARIES, false); auto pcrit_noSA = Props1SI(fluid, "pcrit");
    //            CAPTURE(pcrit_SA - pcrit_noSA);
    //            CHECK(std::abs(pcrit_SA/pcrit_noSA-1) < 1E-2);
    //        }
    //        set_config_bool(ENABLE_SUPERANCILLARIES, init);
    //    }

    for (auto fluid : strsplit(get_global_param_string("fluids_list"), ',')) {
        auto pcrit = Props1SI(fluid, "pcrit");
        auto Tcrit = Props1SI(fluid, "Tcrit");
        CAPTURE(fluid);
        CAPTURE(PhaseSI("P", pcrit + 50000, "T", Tcrit + 3, fluid));
        CAPTURE(PhaseSI("P", pcrit + 50000, "T", Tcrit - 3, fluid));
        CAPTURE(PhaseSI("P", pcrit - 50000, "T", Tcrit + 3, fluid));

        CAPTURE(PropsSI("Q", "P", pcrit + 50000, "T", Tcrit + 3, fluid));
        CAPTURE(PropsSI("Q", "P", pcrit + 50000, "T", Tcrit - 3, fluid));
        CAPTURE(PropsSI("Q", "P", pcrit - 50000, "T", Tcrit + 3, fluid));

        CHECK(PhaseSI("P", pcrit + 50000, "T", Tcrit + 3, fluid) == "supercritical");
        CHECK(PhaseSI("P", pcrit + 50000, "T", Tcrit - 3, fluid) == "supercritical_liquid");
        CHECK(PhaseSI("P", pcrit - 50000, "T", Tcrit + 3, fluid) == "supercritical_gas");
    }
}

TEST_CASE("Check methanol EOS matches REFPROP 10", "[2538]") {
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available

    auto TNBP_RP = PropsSI("T", "P", 101325, "Q", 0, "REFPROP::METHANOL");
    auto TNBP_CP = PropsSI("T", "P", 101325, "Q", 0, "HEOS::METHANOL");
    CHECK(TNBP_RP == Catch::Approx(TNBP_CP).epsilon(1e-6));

    auto rhoL_RP = PropsSI("D", "T", 400, "Q", 0, "REFPROP::METHANOL");
    auto rhoL_CP = PropsSI("D", "T", 400, "Q", 0, "HEOS::METHANOL");
    CHECK(rhoL_RP == Catch::Approx(rhoL_CP).epsilon(1e-12));

    auto cp0_RP = PropsSI("CP0MOLAR", "T", 400, "Dmolar", 1e-5, "REFPROP::METHANOL");
    auto cp0_CP = PropsSI("CP0MOLAR", "T", 400, "Dmolar", 1e-5, "HEOS::METHANOL");
    CHECK(cp0_RP == Catch::Approx(cp0_CP).epsilon(1e-4));
}

TEST_CASE("Check phase determination for PC-SAFT backend", "[pcsaft_phase]") {
    double den = 9033.114209728405;
    double den_calc = CoolProp::PropsSI("Dmolar", "T", 320., "P", 101325., "PCSAFT::TOLUENE");
    CHECK(abs((den_calc / den) - 1) < 1e-2);
    double phase = CoolProp::PropsSI("Phase", "T", 320., "P", 101325., "PCSAFT::TOLUENE");
    CHECK(phase == get_phase_index("phase_liquid"));

    den = 0.376013;
    den_calc = CoolProp::PropsSI("Dmolar", "T", 320., "P", 1000., "PCSAFT::TOLUENE");
    CHECK(abs((den_calc / den) - 1) < 1e-2);
    phase = CoolProp::PropsSI("Phase", "T", 320., "P", 1000., "PCSAFT::TOLUENE");
    CHECK(phase == get_phase_index("phase_gas"));
}

TEST_CASE("Check that indexes for mixtures are assigned correctly, especially for the association term", "[pcsaft_indexes]") {
    // The tests are performed by adding parameters for extra compounds that actually
    // are not present in the system and ensuring that the properties of the fluid do not change.

    // Binary mixture: water-acetic acid
    // set binary interaction parameter, if not already set
    std::string CAS_water = get_fluid_param_string("WATER", "CAS");
    std::string CAS_aacid = "64-19-7";
    try {
        get_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij");
    } catch (...) {
        set_mixture_binary_pair_pcsaft(CAS_water, CAS_aacid, "kij", -0.127);
    }

    double t = 413.5385;
    double rho = 15107.481234283325;
    double p = CoolProp::PropsSI("P", "T", t, "Dmolar", rho, "PCSAFT::ACETIC ACID");  // only parameters for acetic acid
    double p_extra =
      CoolProp::PropsSI("P", "T", t, "Dmolar", rho, "PCSAFT::ACETIC ACID[1.0]&WATER[0]");  // same composition, but with mixture parameters
    CHECK(abs((p_extra - p) / p * 100) < 1e-1);

    // Binary mixture: water-furfural
    t = 400;  // K
    // p = 34914.37778265716; // Pa
    rho = 10657.129498214763;
    p = CoolProp::PropsSI("P", "T", t, "Dmolar", rho, "PCSAFT::FURFURAL");                      // only parameters for furfural
    p_extra = CoolProp::PropsSI("P", "T", t, "Dmolar", rho, "PCSAFT::WATER[0]&FURFURAL[1.0]");  // same composition, but with mixture of components
    CHECK(abs((p_extra - p) / p * 100) < 1e-1);

    // Mixture: NaCl in water with random 4th component
    t = 298.15;  // K
    // p = 3153.417688548272; // Pa
    rho = 55320.89616248148;
    p = CoolProp::PropsSI("P", "T", t, "Dmolar", rho, "PCSAFT::WATER");  // only parameters for water
    p_extra = CoolProp::PropsSI("P", "T", t, "Dmolar", rho,
                                "PCSAFT::Na+[0]&Cl-[0]&WATER[1.0]&DIMETHOXYMETHANE[0]");  // same composition, but with mixture of components
    CHECK(abs((p_extra - p) / p * 100) < 1e-1);
}

/// A fixture class to enable superancillaries just for a given test
class SuperAncillaryOnFixture
{
   private:
    const configuration_keys m_key = ENABLE_SUPERANCILLARIES;
    const bool initial_value;

   public:
    SuperAncillaryOnFixture() : initial_value(CoolProp::get_config_bool(m_key)) {
        CoolProp::set_config_bool(m_key, true);
    }
    ~SuperAncillaryOnFixture() {
        CoolProp::set_config_bool(m_key, initial_value);
    }
};

/// A fixture class to enable superancillaries just for a given test
class SuperAncillaryOffFixture
{
   private:
    const configuration_keys m_key = ENABLE_SUPERANCILLARIES;
    const bool initial_value;

   public:
    SuperAncillaryOffFixture() : initial_value(CoolProp::get_config_bool(m_key)) {
        CoolProp::set_config_bool(m_key, false);
    }
    ~SuperAncillaryOffFixture() {
        CoolProp::set_config_bool(m_key, initial_value);
    }
};

/// A fixture class that saves and restores DONT_CHECK_PROPERTY_LIMITS so a test may
/// toggle it freely without leaking the global config state to later tests
class PropertyLimitsFixture
{
   private:
    const configuration_keys m_key = DONT_CHECK_PROPERTY_LIMITS;
    const bool initial_value;

   public:
    PropertyLimitsFixture() : initial_value(CoolProp::get_config_bool(m_key)) {}
    ~PropertyLimitsFixture() {
        CoolProp::set_config_bool(m_key, initial_value);
    }
};

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check superancillary for water", "[superanc]") {

    auto json = nlohmann::json::parse(get_fluid_param_string("WATER", "JSON"))[0].at("EOS")[0].at("SUPERANCILLARY");
    superancillary::SuperAncillary<std::vector<double>> anc{json.dump()};
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    shared_ptr<CoolProp::AbstractState> IF97(CoolProp::AbstractState::factory("IF97", "Water"));
    auto& rHEOS = *dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());
    BENCHMARK("HEOS.clear()") {
        return rHEOS.clear();
    };
    BENCHMARK("HEOS rho(T)") {
        return AS->update(QT_INPUTS, 1.0, 300.0);
    };
    BENCHMARK("HEOS update_QT_pure_superanc(Q,T)") {
        return rHEOS.update_QT_pure_superanc(1.0, 300.0);
    };
    BENCHMARK("superanc rho(T)") {
        return anc.eval_sat(300.0, 'D', 1);
    };
    BENCHMARK("IF97 rho(T)") {
        return IF97->update(QT_INPUTS, 1.0, 300.0);
    };

    double Tmin = AS->get_fluid_parameter_double(0, "SUPERANC::Tmin");
    double Tc = AS->get_fluid_parameter_double(0, "SUPERANC::Tcrit_num");
    double pmin = AS->get_fluid_parameter_double(0, "SUPERANC::pmin");
    double pmax = AS->get_fluid_parameter_double(0, "SUPERANC::pmax");

    CHECK_THROWS(AS->get_fluid_parameter_double(1, "SUPERANC::pmax"));

    BENCHMARK("HEOS rho(p)") {
        return AS->update(PQ_INPUTS, 101325, 1.0);
    };
    BENCHMARK("superanc T(p)") {
        return anc.get_T_from_p(101325);
    };
    BENCHMARK("IF97 rho(p)") {
        return IF97->update(PQ_INPUTS, 101325, 1.0);
    };
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Benchmark class construction", "[superanc]") {

    BENCHMARK("Water [SA]") {
        return shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));
    };
    BENCHMARK("R410A [no SA]") {
        return shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R410A"));
    };
    BENCHMARK("propane [SA]") {
        return shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "n-Propane"));
    };
    BENCHMARK("air, pseudo-pure [SA]") {
        return shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Air"));
    };
}

TEST_CASE_METHOD(SuperAncillaryOffFixture, "Check superancillary-like calculations with superancillary disabled for water", "[superanc]") {

    auto json = nlohmann::json::parse(get_fluid_param_string("WATER", "JSON"))[0].at("EOS")[0].at("SUPERANCILLARY");
    superancillary::SuperAncillary<std::vector<double>> anc{json.dump()};
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    shared_ptr<CoolProp::AbstractState> IF97(CoolProp::AbstractState::factory("IF97", "Water"));
    auto& approxrhoL = anc.get_approx1d('D', 0);

    BENCHMARK("HEOS rho(T)") {
        return AS->update(QT_INPUTS, 1.0, 300.0);
    };
    BENCHMARK("superanc rho(T)") {
        return anc.eval_sat(300.0, 'D', 1);
    };
    BENCHMARK("superanc rho(T) with expansion directly") {
        return approxrhoL.eval(300.0);
    };
    BENCHMARK("superanc get_index rho(T)") {
        return approxrhoL.get_index(300.0);
    };
    BENCHMARK("IF97 rho(T)") {
        return IF97->update(QT_INPUTS, 1.0, 300.0);
    };

    BENCHMARK("HEOS rho(p)") {
        return AS->update(PQ_INPUTS, 101325, 1.0);
    };
    BENCHMARK("superanc T(p)") {
        return anc.get_T_from_p(101325);
    };
    BENCHMARK("IF97 rho(p)") {
        return IF97->update(PQ_INPUTS, 101325, 1.0);
    };
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check superancillary functions are available for all pure fluids", "[ancillary]") {
    for (auto& fluid : strsplit(CoolProp::get_global_param_string("fluids_list"), ',')) {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", fluid));
        auto& rHEOS = *dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());
        if (rHEOS.is_pure()) {
            CAPTURE(fluid);
            // A small number of pure fluids legitimately lack a superancillary
            // (e.g. propylene glycol, whose published EOS has a numerically
            // unstable critical region that fastchebpure cannot converge
            // against). Skip them instead of failing the suite.
            try {
                rHEOS.update_QT_pure_superanc(1, rHEOS.T_critical() * 0.9999);
            } catch (const ValueError& e) {
                if (std::string(e.what()).find("Superancillaries not available") != std::string::npos) {
                    continue;
                }
                CHECK_NOTHROW((void)("rethrow"));  // mark the section as failed
                throw;
            }
        }
    }
};

extern "C"
{
    extern unsigned char gall_fluids_CBORData[];
    extern unsigned int gall_fluids_CBORSize;
}

TEST_CASE("Superancillary source_eos_hash matches current EOS at bit level", "[ancillary]") {
    // Byte-level freshness check: the stored source_eos_hash was stamped from
    // the EOS fastchebpure saw when it fit the superancillary; if anyone has edited
    // the EOS since (gas constant, alpha0/alphar, reducing state, ...), the
    // current hash of EOS[0] (with the SUPERANCILLARY subtree removed) will
    // disagree and this test fails. Mirror of
    // dev/scripts/check_superanc_freshness.py on the Python side.
    //
    // Two subtleties motivate the implementation below:
    //
    //   1. We must bypass CoolProp's runtime JSON parse: it historically
    //      rounded some doubles 1 ULP
    //      away from the JSON text value. Decompressing the raw compiled-in
    //      blob and parsing with nlohmann::json (correctly-rounded by
    //      default) yields the same doubles Python saw at inject time.
    //
    //   2. We cannot hash via a canonical JSON dump: nlohmann's and Python's
    //      shortest-round-trip float formatters occasionally disagree (e.g.,
    //      nlohmann emits "19673.920781104862" where Python emits
    //      "19673.92078110486" for the same double). So we hash the parsed
    //      TREE (type tags + raw IEEE-754 bits for doubles, two's complement
    //      for ints, UTF-8 for strings, sorted keys for objects). Since the
    //      parsed values are bit-identical across languages, the byte stream
    //      fed to FNV-1a is too, and the hashes match exactly.
    //
    // Known-stale fluids: EOS edited in master since the last fastchebpure
    // release, with no yet-released SA to match. Adding a fluid here makes
    // the test assert on the *mismatch* (so an accidental regen also forces
    // an update here). Currently empty — fastchebpure 2026.04.23 covers
    // every master fluid that has an SA.
    static const std::set<std::string> known_stale_SA = {};

    // ---------------------------------------------------------------------
    // TreeHasher: FNV-1a 64 over a deterministic byte serialization of a
    // parsed JSON tree.
    //
    // We need a hash that (a) agrees byte-for-byte with the Python inject
    // script, (b) is cross-platform / cross-compiler deterministic, and
    // (c) is robust to insignificant representation differences (trailing
    // digits, key ordering, etc.). Hashing a JSON *string* doesn't satisfy
    // (c): Python's repr and nlohmann::dump disagree on "shortest round
    // trip" for a handful of doubles. So instead we feed FNV-1a a byte
    // stream derived from the parsed VALUES — two implementations that
    // parse the same JSON into the same doubles produce identical bytes.
    //
    // Byte-stream contract (this C++ walk must stay in lockstep with
    // `eos_fnv1a_hex` in dev/scripts/inject_superanc_check_points.py):
    //
    //   null      -> 'n'
    //   false     -> 'f'
    //   true      -> 't'
    //   integer   -> 'i' then int64 two's-complement bits as LE u64
    //   float     -> 'd' then IEEE-754 bits as LE u64
    //   string    -> 's' then LE u64 UTF-8 byte count then UTF-8 bytes
    //   array     -> 'a' then LE u64 length then each element walked
    //   object    -> 'o' then LE u64 size then, for each key in sorted
    //                order: LE u64 UTF-8 byte count, UTF-8 bytes, walked
    //                value
    //
    // Notes / invariants future readers should preserve:
    //   * Type tags let us distinguish 0, 0.0, false, and "" (they would
    //     otherwise all hash the same with integer-only or string-only
    //     encodings).
    //   * nlohmann::json is backed by std::map, so iterating `items()`
    //     already yields keys in sorted order. Do not switch to
    //     ordered_json (insertion order) or unordered_json — the Python
    //     side explicitly sorts, and we must match.
    //   * All CoolProp-supported platforms are little-endian, so we
    //     encode u64s little-endian without an explicit swap. If that
    //     ever changes, replace mix_u64 with an endianness-normalized
    //     variant in both languages simultaneously.
    //   * is_number_unsigned is lumped with is_number_integer and cast
    //     through int64_t. For any JSON integer that fits in int64 the
    //     two's-complement bit pattern matches Python's `x & 0xFF...F`
    //     encoding; fluid JSONs never exceed that range.
    //   * FNV-1a is NOT cryptographic; we only need determinism and
    //     reasonable distribution for change detection. Never rely on
    //     this for security.
    //
    // The seed 0xcbf29ce484222325 and prime 0x100000001b3 are the
    // standard FNV-1a 64-bit parameters.
    // ---------------------------------------------------------------------
    struct TreeHasher
    {
        uint64_t h = 0xcbf29ce484222325ULL;
        /// Fold one byte into the running hash (FNV-1a step).
        void mix_u8(uint8_t b) {
            h ^= b;
            h *= 0x100000001b3ULL;
        }
        /// Fold a buffer of raw bytes into the running hash, one byte at a time.
        void mix_bytes(const void* data, std::size_t n) {
            const auto* p = static_cast<const uint8_t*>(data);
            for (std::size_t i = 0; i < n; ++i)
                mix_u8(p[i]);
        }
        /// Fold a 64-bit integer in little-endian byte order. Used for lengths,
        /// IEEE-754 bit patterns of doubles, and two's-complement ints.
        void mix_u64(uint64_t v) {
            for (int i = 0; i < 8; ++i)
                mix_u8(static_cast<uint8_t>((v >> (i * 8)) & 0xff));
        }
        /// Recursively fold a JSON subtree into the running hash. See the
        /// byte-stream contract in the block comment above.
        void walk(const nlohmann::json& j) {
            if (j.is_null()) {
                mix_u8('n');
            } else if (j.is_boolean()) {
                // Distinct tags for true and false; we never fold a payload
                // byte here, so 'true' alone is what distinguishes booleans
                // from strings like "t" (which emit 's' + length + 't').
                mix_u8(j.get<bool>() ? 't' : 'f');
            } else if (j.is_number_integer() || j.is_number_unsigned()) {
                // All JSON ints — whether nlohmann classified them signed or
                // unsigned — get the same 'i' tag and int64 bit pattern. This
                // matches Python, where json.loads always yields a single int
                // type regardless of sign.
                mix_u8('i');
                mix_u64(static_cast<uint64_t>(j.get<int64_t>()));
            } else if (j.is_number_float()) {
                // Feed raw IEEE-754 bits, not the textual representation.
                // std::memcpy is the well-defined way to type-pun double -> u64;
                // both Python's struct.pack('<d', x) and this produce the same
                // 8 bytes on a little-endian host.
                mix_u8('d');
                uint64_t bits;
                double v = j.get<double>();
                std::memcpy(&bits, &v, 8);
                mix_u64(bits);
            } else if (j.is_string()) {
                // Length-prefixed UTF-8. The length prefix prevents collisions
                // between, e.g., ["ab","c"] and ["a","bc"] when array elements
                // are walked back to back.
                const auto& s = j.get_ref<const std::string&>();
                mix_u8('s');
                mix_u64(s.size());
                mix_bytes(s.data(), s.size());
            } else if (j.is_array()) {
                // Length prefix disambiguates nested arrays — without it, [[1],[]]
                // and [[1,[]]] would serialize to the same byte stream.
                mix_u8('a');
                mix_u64(j.size());
                for (const auto& el : j)
                    walk(el);
            } else if (j.is_object()) {
                // Size prefix + keys in sorted (lexicographic by UTF-8 bytes)
                // order. nlohmann's underlying std::map already iterates in
                // that order; if a future maintainer swaps in an ordered_json
                // or unordered_json type, this loop will silently change
                // behavior and stop agreeing with Python — add an explicit
                // sort there.
                mix_u8('o');
                mix_u64(j.size());
                for (auto it = j.begin(); it != j.end(); ++it) {
                    const auto& k = it.key();
                    mix_u64(k.size());
                    mix_bytes(k.data(), k.size());
                    walk(it.value());
                }
            }
        }
        /// Return the final hash as 16 lowercase hex chars (zero-padded).
        std::string hex() const {
            char buf[17];
            std::snprintf(buf, sizeof(buf), "%016llx", static_cast<unsigned long long>(h));
            return {buf};
        }
    };

    // Self-test the TreeHasher against a fixed input/hash pair so that the
    // byte-stream contract can't silently drift even if every fluid JSON
    // happens to stay internally consistent. The expected value is computed
    // by dev/scripts/inject_superanc_check_points.py::eos_fnv1a_hex on the
    // same literal fixture; a regression on either side flips one digit.
    // This fixture exercises every type in the contract (null, bool, int,
    // float, string, array, object, nested objects, empty containers).
    {
        nlohmann::json fixture = {
          {"alphar", {{{"d", {1, 2, 3}}, {"n", {-0.5, 1.25e-10, 3.14159265358979}}}}},
          {"empty_array", nlohmann::json::array()},
          {"empty_string", ""},
          {"flag_false", false},
          {"flag_true", true},
          {"gas_constant", 8.3144598},
          {"nested", {{"deep", {{"deeper", nullptr}}}}},
          {"zero_float", 0.0},
          {"zero_int", 0},
        };
        TreeHasher fixture_hasher;
        fixture_hasher.walk(fixture);
        CHECK(fixture_hasher.hex() == "8e75626511d00b5c");
    }

    // Decode the raw all_fluids CBOR bytes — the same blob FluidLibrary
    // loads, but without the subsequent runtime round-trip.
    auto all_fluids = cpjson::from_cbor(gall_fluids_CBORData, gall_fluids_CBORSize);

    int fluids_checked = 0;
    for (const auto& jfluid : all_fluids) {
        if (!jfluid.contains("EOS") || jfluid.at("EOS").empty()) {
            continue;
        }
        const auto& eos = jfluid.at("EOS")[0];
        if (!eos.contains("SUPERANCILLARY")) {
            continue;
        }
        std::string name = jfluid.value("INFO", nlohmann::json::object()).value("NAME", std::string("?"));
        CAPTURE(name);
        const auto& jsuper = eos.at("SUPERANCILLARY");
        // Every SA-bearing fluid must carry the freshness stamp. Fail loudly
        // rather than silently skip — a new fluid added without an inject
        // step should not slip past this test. The field name is the one
        // fastchebpure emits (`fitcheb inject`'s `source_eos_hash`);
        // `dev/scripts/inject_superanc_check_points.py` now writes the same
        // key so that there is a single canonical field across producers.
        REQUIRE(jsuper.contains("source_eos_hash"));
        auto stored = jsuper.at("source_eos_hash").get<std::string>();
        auto stripped = eos;
        stripped.erase("SUPERANCILLARY");
        TreeHasher th;
        th.walk(stripped);
        auto computed = th.hex();
        CAPTURE(stored);
        CAPTURE(computed);
        if (known_stale_SA.count(name)) {
            // Expected mismatch — assert it so that an accidentally-regenerated
            // SA also forces an update of this skip list.
            CHECK(computed != stored);
        } else {
            CHECK(computed == stored);
        }
        ++fluids_checked;
    }
    CHECK(fluids_checked > 0);
};

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Superancillary eval matches extended-precision check points for all fluids", "[ancillary]") {
    // Per-point tolerance comes from fastchebpure's own reported (SA)/(mp) ratio:
    // we demand that the C++ Chebyshev eval reproduce the multi-precision reference
    // to within the same accuracy fastchebpure itself achieved at that T, plus a
    // safety factor to absorb cross-platform floating-point jitter. The 1e-14 floor
    // handles points where fastchebpure's ratio rounded exactly to 1.0.
    const double safety_factor = 4.0;
    const double floor_tol = 1e-14;
    int fluids_checked = 0;
    for (auto& fluid : strsplit(CoolProp::get_global_param_string("fluids_list"), ',')) {
        auto jfluid = nlohmann::json::parse(get_fluid_param_string(fluid, "JSON"))[0];
        if (!jfluid.at("EOS")[0].contains("SUPERANCILLARY")) {
            continue;
        }
        CAPTURE(fluid);
        auto jsuper = jfluid.at("EOS")[0].at("SUPERANCILLARY");
        // Every SA-bearing fluid must carry check_points. Fail loudly rather
        // than silently skip — a new fluid added without re-running
        // inject_superanc_check_points.py should not slip past this test.
        REQUIRE(jsuper.contains("check_points"));
        superancillary::SuperAncillary<std::vector<double>> anc{jsuper.dump()};
        for (const auto& pt : anc.get_check_points()) {
            CAPTURE(pt.T);
            const double tol_p = std::max(std::abs(pt.p_SA_ratio - 1.0), floor_tol) * safety_factor;
            const double tol_rhoL = std::max(std::abs(pt.rhoL_SA_ratio - 1.0), floor_tol) * safety_factor;
            const double tol_rhoV = std::max(std::abs(pt.rhoV_SA_ratio - 1.0), floor_tol) * safety_factor;
            CHECK(std::abs(anc.eval_sat(pt.T, 'D', 0) / pt.rhoL - 1) < tol_rhoL);
            CHECK(std::abs(anc.eval_sat(pt.T, 'D', 1) / pt.rhoV - 1) < tol_rhoV);
            CHECK(std::abs(anc.eval_sat(pt.T, 'P', 1) / pt.p - 1) < tol_p);
        }
        ++fluids_checked;
    }
    // Guard against a silent schema drift that would make every fluid skip.
    CHECK(fluids_checked > 0);
};

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check out of bound for superancillary", "[superanc]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    CHECK_THROWS(AS->update(PQ_INPUTS, 100000000001325, 1.0));
    CHECK_THROWS(AS->update(QT_INPUTS, 1.0, 1000000));
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check throws for R410A", "[superanc]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R410A"));
    auto& rHEOS = *dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());
    CHECK_THROWS(rHEOS.update_QT_pure_superanc(1.0, 300.0));
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check throws for REFPROP", "[superanc]") {
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("REFPROP", "WATER"));
    CHECK_THROWS(AS->update_QT_pure_superanc(1.0, 300.0));
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check Tc & pc", "[superanccrit]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    set_config_bool(ENABLE_SUPERANCILLARIES, true);
    auto TcSA = AS->T_critical();
    auto pcSA = AS->p_critical();
    auto rhocSA = AS->rhomolar_critical();
    set_config_bool(ENABLE_SUPERANCILLARIES, false);
    auto TcnonSA = AS->T_critical();
    auto pcnonSA = AS->p_critical();
    auto rhocnonSA = AS->rhomolar_critical();
    CHECK(TcSA != TcnonSA);
    CHECK(pcSA != pcnonSA);
    CHECK(rhocSA != rhocnonSA);
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Check h_fg", "[superanc]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    CHECK_THROWS(AS->saturated_vapor_keyed_output(iHmolar) - AS->saturated_liquid_keyed_output(iHmolar));
    AS->update_QT_pure_superanc(1, 300);
    CHECK_NOTHROW(AS->saturated_vapor_keyed_output(iHmolar) - AS->saturated_liquid_keyed_output(iHmolar));
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Performance regression; on", "[2438]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "CO2"));
    BENCHMARK("HP regression") {
        AS->update(HmassP_INPUTS, 300e3, 70e5);
        return AS;
    };
    AS->update(HmassP_INPUTS, 300e3, 70e5);
    std::cout << AS->Q() << '\n';
}
TEST_CASE_METHOD(SuperAncillaryOffFixture, "Performance regression; off", "[2438]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "CO2"));
    BENCHMARK("HP regression") {
        AS->update(HmassP_INPUTS, 300e3, 70e5);
        return AS;
    };
    AS->update(HmassP_INPUTS, 300e3, 70e5);
    std::cout << AS->Q() << '\n';
}
TEST_CASE_METHOD(SuperAncillaryOnFixture, "Performance regression for TS; on", "[2438saontime]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "n-Propane"));
    double T = 298.0;
    AS->update(QT_INPUTS, 1, T);
    auto sL = AS->saturated_liquid_keyed_output(iSmolar);
    auto sV = AS->saturated_vapor_keyed_output(iSmolar);
    auto N = 1000000U;
    for (auto i = 0; i < N; ++i) {
        AS->update(SmolarT_INPUTS, (sL + sV) / 2 + i * 1e-14, T);
    }
    CHECK(AS->T() != 0);
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Performance regression for TS; on", "[2438]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "CO2"));
    double T = 298.0;
    AS->update(QT_INPUTS, 1, T);
    auto sL = AS->saturated_liquid_keyed_output(iSmolar);
    auto sV = AS->saturated_vapor_keyed_output(iSmolar);
    BENCHMARK("ST regression") {
        AS->update(SmolarT_INPUTS, (sL + sV) / 2, T);
        return AS;
    };
}

TEST_CASE_METHOD(SuperAncillaryOffFixture, "Performance regression for TS; off", "[2438]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "CO2"));
    double T = 298.0;
    AS->update(QT_INPUTS, 1, T);
    auto sL = AS->saturated_liquid_keyed_output(iSmolar);
    auto sV = AS->saturated_vapor_keyed_output(iSmolar);
    BENCHMARK("ST regression") {
        AS->update(SmolarT_INPUTS, (sL + sV) / 2, T);
        return AS;
    };
}

TEST_CASE_METHOD(SuperAncillaryOnFixture, "Benchmarking caching options", "[caching]") {
    std::array<double, 16> buf15;
    buf15.fill(0.0);
    std::array<double, 100> buf100;
    buf100.fill(0.0);
    std::array<bool, 100> bool100;
    bool100.fill(false);
    std::vector<CachedElement> cache100(100);
    for (auto& i : cache100) {
        i = _HUGE;
    }

    std::vector<std::optional<double>> opt100(100);
    for (auto& i : opt100) {
        i = _HUGE;
    }

    BENCHMARK("memset array15 w/ 0") {
        std::memset(buf15.data(), 0, sizeof(buf15));
        return buf15;
    };
    BENCHMARK("std::fill_n array15") {
        std::fill_n(buf15.data(), 15, _HUGE);
        return buf15;
    };
    BENCHMARK("std::fill array15") {
        std::fill(buf15.begin(), buf15.end(), _HUGE);
        return buf15;
    };
    BENCHMARK("array15.fill()") {
        buf15.fill(_HUGE);
        return buf15;
    };
    BENCHMARK("memset array100 w/ 0") {
        memset(buf100.data(), 0, sizeof(buf100));
        return buf100;
    };
    BENCHMARK("memset bool100 w/ 0") {
        memset(bool100.data(), false, sizeof(bool100));
        return buf100;
    };
    BENCHMARK("std::fill_n array100") {
        std::fill_n(buf100.data(), 100, _HUGE);
        return buf100;
    };
    BENCHMARK("fill array100") {
        buf100.fill(_HUGE);
        return buf100;
    };
    BENCHMARK("fill cache100") {
        for (auto& i : cache100) {
            i = _HUGE;
        }
        return cache100;
    };
    BENCHMARK("fill opt100") {
        for (auto& i : opt100) {
            i = _HUGE;
        }
        return opt100;
    };
}
std::vector<std::tuple<double, double, double, double>> MSA22values = {
  {200, 199.97, 142.56, 1.29559},
  {300, 300.19, 214.07, 1.70203},
  {400, 400.98, 286.16, 1.99194},
  {500, 503.02, 359.49, 2.21952},
};

TEST_CASE("Ideal gas thermodynamic properties", "[2589]") {
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available

    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Air"));
    shared_ptr<CoolProp::AbstractState> RP(CoolProp::AbstractState::factory("REFPROP", "Air"));

    auto& rRP = *dynamic_cast<REFPROPMixtureBackend*>(AS.get());
    auto& rHEOS = *dynamic_cast<HelmholtzEOSMixtureBackend*>(AS.get());

    AS->specify_phase(iphase_gas);
    RP->specify_phase(iphase_gas);

    double pig = 101325;

    // Moran & Shapiro Table A-22 reference is h(T=0) = 0, but that doesn't play nicely
    // with tau=Tc/T = oo and delta = 0/rhor = 0

    for (auto [T_K, h_kJkg, u_kJkg, s_kJkgK] : MSA22values) {
        double rho = pig / (AS->gas_constant() * T_K);  // ideal-gas molar density assuming Z=1
        AS->update(DmolarT_INPUTS, rho, T_K);
        RP->update(DmolarT_INPUTS, rho, T_K);

        CHECK(AS->smass_idealgas() / AS->gas_constant() == Catch::Approx(RP->smass_idealgas() / AS->gas_constant()));
        CHECK(AS->hmass_idealgas() / AS->gas_constant() == Catch::Approx(RP->hmass_idealgas() / AS->gas_constant()));

        std::vector<double> mf(20, 1.0);
        auto o = rRP.call_THERM0dll(T_K, rho / 1e3, mf);
        CHECK(o.hmol_Jmol == Catch::Approx(RP->hmolar_idealgas()).epsilon(1e-12));
        CHECK(o.smol_JmolK == Catch::Approx(RP->smolar_idealgas()).epsilon(1e-12));
        CHECK(o.umol_Jmol == Catch::Approx(RP->umolar_idealgas()).epsilon(1e-12));

        CAPTURE(T_K);
        CAPTURE(AS->hmass_idealgas());
        CAPTURE(AS->hmass_idealgas() - h_kJkg * 1e3);
        CAPTURE(AS->smass_idealgas());
        CAPTURE(AS->smass_idealgas() - s_kJkgK * 1e3);
        CAPTURE(AS->umass_idealgas());
        CAPTURE(AS->umass_idealgas() - u_kJkg * 1e3);
    }
}
TEST_CASE_METHOD(SuperAncillaryOnFixture, "Phase for solid water should throw", "[2639]") {
    std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    for (auto p_Pa : linspace(AS->p_triple() * 1.0001, AS->pmax(), 1000)) {
        CAPTURE(p_Pa);
        auto Tm = AS->melting_line(iT, iP, p_Pa);
        CAPTURE(Tm);
        CHECK_THROWS(AS->update(PT_INPUTS, p_Pa, -5 + Tm));
    }
}

// The melting-line guards added in #2648 must honor DONT_CHECK_PROPERTY_LIMITS so the
// metastable/below-melting escape hatch behaves the same below and above the critical
// pressure.  Before the fix, the supercritical-pressure branch (p > psat_max) and the
// other==iP branch in T_phase_determination_pure_or_pseudopure ignored the override and
// threw regardless.  See GitHub #1936.
TEST_CASE_METHOD(PropertyLimitsFixture, "Below-melting PT guard honors DONT_CHECK_PROPERTY_LIMITS", "[1936]") {
    std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "CO2"));
    const double Tt = AS->Ttriple();
    const double pc = AS->p_critical();
    // CO2's melting line has positive slope, so each of these (T, p) pairs sits just below
    // the melting line.  The three pressures exercise the three distinct internal paths
    // that carry a melting-line guard:
    //   - p_sub  at Ttriple  -> p_phase_determination, subcritical superancillary branch
    //   - p_sup  at Ttriple  -> p_phase_determination, supercritical-pressure branch (p > psat_max)
    //   - p_hiT  at T > triple-routing threshold -> T_phase_determination, other==iP branch
    const double p_sub = 0.5 * (AS->p_triple() + pc);  // between ptriple and pcrit
    const double p_sup = 5 * pc;                       // well above pcrit
    struct Case
    {
        double p_Pa, T;
    };
    for (const Case& c : {Case{p_sub, Tt}, Case{p_sup, Tt}, Case{1e8, 230.0}}) {
        CAPTURE(c.p_Pa);
        CAPTURE(c.T);
        const double Tm = AS->melting_line(iT, iP, c.p_Pa);
        CAPTURE(Tm);
        REQUIRE(c.T < Tm - 0.001);  // sanity: the state really is below the melting line
        // Default: below the melting line throws
        {
            CoolProp::set_config_bool(DONT_CHECK_PROPERTY_LIMITS, false);
            CHECK_THROWS(AS->update(PT_INPUTS, c.p_Pa, c.T));
        }
        // With the override, the same state must resolve to a finite (metastable) density
        {
            CoolProp::set_config_bool(DONT_CHECK_PROPERTY_LIMITS, true);
            CHECK_NOTHROW(AS->update(PT_INPUTS, c.p_Pa, c.T));
            // Guard against a silent no-op update leaving the prior case's state behind
            CHECK(AS->T() == Catch::Approx(c.T).epsilon(1e-12));
            CHECK(AS->p() == Catch::Approx(c.p_Pa).epsilon(1e-12));
            CHECK(ValidNumber(AS->rhomolar()));
            CHECK(AS->rhomolar() > 0);
        }
    }
}

TEST_CASE("PT update below melting-line pmin succeeds without specify_phase for all HEOS fluids", "[melting]") {
    // Before the fix in HelmholtzEOSMixtureBackend.cpp, the phase-determination
    // paths called melting_line(iT, iP, p) unconditionally for any fluid with a
    // melting-line fit, including when p was below pmin (the triple-point pressure).
    // The evaluator threw an out-of-bounds error in that case, breaking any call
    // that omits specify_phase when the pressure is below the fit's lower bound --
    // for example Argon in an air mixture where the partial pressure (~941 Pa) is
    // far below Argon's pmin (~69 688 Pa).
    using namespace CoolProp;
    const std::vector<std::string> all_fluids = strsplit(get_global_param_string("fluids_list"), ',');
    for (const auto& name : all_fluids) {
        std::shared_ptr<AbstractState> AS;
        try {
            AS.reset(AbstractState::factory("HEOS", name));
        } catch (...) {
            continue;
        }
        if (!AS->has_melting_line()) continue;

        const double pmin = AS->melting_line(iP_min, -1, -1);
        // Just below the lower bound of the melting-line fit
        const double p_test = 0.99 * pmin;
        // Well above the triple point temperature -- unambiguously gas at p < ptriple
        const double T_test = AS->Ttriple() * 1.1;

        SECTION(name) {
            CAPTURE(pmin);
            CAPTURE(p_test);
            CAPTURE(T_test);
            CHECK_NOTHROW(AS->update(PT_INPUTS, p_test, T_test));
            CHECK(ValidNumber(AS->rhomolar()));
            CHECK(AS->rhomolar() > 0);
        }
    }
}

TEST_CASE("HeavyWater (D2O) melting line matches Herrig et al. check values", "[melting]") {
    // Melting-pressure equations Eqs. (4)-(7) of Herrig, Thol, Harvey, Lemmon,
    // "A Reference Equation of State for Heavy Water," J. Phys. Chem. Ref. Data
    // 47, 043102 (2018). The values below are the paper's computer-implementation
    // check values (Sec. 3.4) for the four ice-structure branches.
    using namespace CoolProp;
    std::shared_ptr<AbstractState> AS(AbstractState::factory("HEOS", "HeavyWater"));
    REQUIRE(AS->has_melting_line());
    struct Pt
    {
        double T_K, p_Pa;
    };
    // (T, p) check points, one per ice-structure branch; p in MPa from the paper.
    // NB: melting pressure p(T) is multi-valued near the ice-Ih/III/V triples (the
    // ice-Ih branch folds back), so we validate via the single-valued T(p) inverse
    // — the direction the parser indexes by pressure, and the one the EOS uses for
    // its lower temperature bound. Recovering each branch's check temperature from
    // its check pressure exercises that branch's transcribed coefficients.
    const Pt pts[] = {
      {270.0, 0.837888413e2 * 1e6},  // ice Ih,  Eq. (4)
      {255.0, 0.236470168e3 * 1e6},  // ice III, Eq. (5)
      {275.0, 0.619526971e3 * 1e6},  // ice V,   Eq. (6)
      {300.0, 0.959203594e3 * 1e6},  // ice VI,  Eq. (7)
    };
    for (const Pt& pt : pts) {
        CAPTURE(pt.T_K, pt.p_Pa);
        const double T = AS->melting_line(iT, iP, pt.p_Pa);
        CHECK(T == Catch::Approx(pt.T_K).epsilon(1e-6));
    }
}

TEST_CASE("REFPROP melting_line honors iP_min/iT_min/iP_max/iT_max sentinels", "[melting][REFPROP]") {
    Skip_if_No_REFPROP();  // Skip this test if REFPROPMixture backend is not available
    std::shared_ptr<CoolProp::AbstractState> RP(CoolProp::AbstractState::factory("REFPROP", "Water"));
    std::shared_ptr<CoolProp::AbstractState> HE(CoolProp::AbstractState::factory("HEOS", "Water"));

    double pmin = RP->melting_line(iP_min, -1, -1);
    double Tmin = RP->melting_line(iT_min, -1, -1);

    // iP_min is the triple-point pressure, for consistency with HEOS.
    CHECK(pmin == Catch::Approx(RP->p_triple()));
    CHECK(pmin == Catch::Approx(HE->melting_line(iP_min, -1, -1)).epsilon(1e-3));

    // iT_min is the melting line's lowest temperature.  For water that is the ice
    // Ih/III junction (251.165 K), which lies BELOW the triple-point temperature --
    // the one case (with heavy water) where it differs from the triple point.
    CHECK(Tmin == Catch::Approx(251.165).epsilon(1e-5));
    CHECK(Tmin < RP->Ttriple());
    // ...and Tmin is a valid point on the melting line (the floor MELTT accepts).
    CHECK_NOTHROW(RP->melting_line(iP, iT, Tmin));

    // The high-pressure end must be a finite value above the minimum.
    double pmax = RP->melting_line(iP_max, -1, -1);
    double Tmax = RP->melting_line(iT_max, -1, -1);
    CHECK(ValidNumber(pmax));
    CHECK(ValidNumber(Tmax));
    CHECK(pmax > pmin);
    CHECK(Tmax > Tmin);

    // A genuine melting lookup must still work and agree with HEOS (regression).
    CHECK(RP->melting_line(iT, iP, 1e8) == Catch::Approx(HE->melting_line(iT, iP, 1e8)).epsilon(1e-3));

    // A truly invalid input pair must throw a ValueError -- not crash building
    // its own error message via get_parameter_information() on an invalid key.
    CHECK_THROWS_AS(RP->melting_line(iDmolar, iHmolar, 0), CoolProp::ValueError);
}

// Tests for cubic EOS superancillaries (#2739)
TEST_CASE("Cubic superancillary saturation_ancillary accuracy vs EOS flash", "[cubic_superanc][2739]") {
    for (const auto& backend : std::vector<std::string>{"PR", "SRK"}) {
        CAPTURE(backend);
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory(backend, "Propane"));
        auto& ACB = *dynamic_cast<AbstractCubicBackend*>(AS.get());
        // Use the Tc from the superancillary (the max T supported by its domain)
        double Tc_sa = ACB.calc_superanc_Tmax();

        SECTION(backend + " accuracy across T range (0.3 to 0.99 of superanc Tc)") {
            for (double frac : {0.3, 0.5, 0.7, 0.8, 0.9, 0.95, 0.99}) {
                double T = frac * Tc_sa;
                CAPTURE(T);
                AS->update(QT_INPUTS, 0, T);
                double p_eos = AS->p();
                double rhoL_eos = AS->saturated_liquid_keyed_output(iDmolar);
                double rhoV_eos = AS->saturated_vapor_keyed_output(iDmolar);

                double p_anc = ACB.calc_saturation_ancillary(iP, 0, iT, T);
                double rhoL_anc = ACB.calc_saturation_ancillary(iDmolar, 0, iT, T);
                double rhoV_anc = ACB.calc_saturation_ancillary(iDmolar, 1, iT, T);

                CAPTURE(p_eos);
                CAPTURE(p_anc);
                CAPTURE(rhoL_eos);
                CAPTURE(rhoL_anc);
                CAPTURE(rhoV_eos);
                CAPTURE(rhoV_anc);
                // Superancillaries achieve < 1e-3 relative error everywhere
                CHECK(std::abs(p_anc - p_eos) / p_eos < 1e-3);
                CHECK(std::abs(rhoL_anc - rhoL_eos) / rhoL_eos < 1e-3);
                CHECK(std::abs(rhoV_anc - rhoV_eos) / rhoV_eos < 1e-3);
            }
        }

        // Very close to the superancillary critical point the EOS flash becomes unreliable,
        // but the superancillary is still valid.  Check that the returned values are physically
        // reasonable: rhoL > rhoV, p > 0, and p converges toward the superancillary's own pc.
        SECTION(backend + " physically reasonable very close to superanc Tc") {
            // Use the superancillary's pc (p at T just below Tmax) as the reference,
            // not AS->p_critical() which reflects the real fluid, not the cubic model.
            double pc_sa = ACB.calc_saturation_ancillary(iP, 0, iT, Tc_sa * (1.0 - 1e-7));
            for (double frac : {0.9999, 0.99999, 0.999999, 1.0 - 1e-7}) {
                double T = frac * Tc_sa;
                CAPTURE(T);
                double p_anc = ACB.calc_saturation_ancillary(iP, 0, iT, T);
                double rhoL_anc = ACB.calc_saturation_ancillary(iDmolar, 0, iT, T);
                double rhoV_anc = ACB.calc_saturation_ancillary(iDmolar, 1, iT, T);
                CAPTURE(p_anc);
                CAPTURE(rhoL_anc);
                CAPTURE(rhoV_anc);
                CHECK(p_anc > 0);
                CHECK(rhoL_anc > rhoV_anc);
                CHECK(std::abs(p_anc - pc_sa) / pc_sa < 0.01);  // within 1 % of superanc pc
            }
        }
    }
}

TEST_CASE("Cubic superancillary update_QT_pure_superanc", "[cubic_superanc][2739]") {
    for (const auto& backend : std::vector<std::string>{"PR", "SRK"}) {
        CAPTURE(backend);
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory(backend, "Propane"));
        auto& ACB = *dynamic_cast<AbstractCubicBackend*>(AS.get());
        double Tc_sa = ACB.calc_superanc_Tmax();

        SECTION(backend + " update_QT_pure_superanc consistency at several T") {
            for (double frac : {0.5, 0.7, 0.9, 0.9999, 0.99999, 1.0 - 1e-7}) {
                double T = frac * Tc_sa;
                CAPTURE(T);
                CHECK_NOTHROW(AS->update_QT_pure_superanc(0.5, T));
                CHECK(std::abs(AS->T() - T) < 1e-10);
                CHECK(AS->p() > 0);
            }
        }

        SECTION(backend + " update_QT_pure_superanc Q=0 and Q=1 densities bracket Q=0.5") {
            double T = 0.8 * Tc_sa;
            AS->update_QT_pure_superanc(0.0, T);
            double rhoL = AS->rhomolar();
            AS->update_QT_pure_superanc(1.0, T);
            double rhoV = AS->rhomolar();
            AS->update_QT_pure_superanc(0.5, T);
            double rhoM = AS->rhomolar();
            CAPTURE(rhoL);
            CAPTURE(rhoV);
            CAPTURE(rhoM);
            CHECK(rhoL > rhoM);
            CHECK(rhoM > rhoV);
        }
    }
}

TEST_CASE("Cubic pure-fluid DmolarT/DmassT round-trip vs PT", "[cubic_DmolarT][2673]") {
    for (const auto& backend : std::vector<std::string>{"PR", "SRK"}) {
        CAPTURE(backend);
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory(backend, "nButane"));
        auto& ACB = *dynamic_cast<AbstractCubicBackend*>(AS.get());
        const double Tc_sa = ACB.calc_superanc_Tmax();

        SECTION(backend + " liquid round-trip subcooled") {
            // Subcooled liquid: p > p_sat(T) at T < Tc.  Using PT_INPUTS at
            // (101325, 350 K) for nButane lands on the vapor side (p_sat(350) ~ 1.5 MPa),
            // so set p_in well above p_sat(T_in) to actually exercise the liquid branch.
            const double T_in = 0.7 * Tc_sa;
            const double p_sat = ACB.calc_saturation_ancillary(iP, 0, iT, T_in);
            const double p_in = 2.0 * p_sat;
            AS->update(PT_INPUTS, p_in, T_in);
            const double rho_molar = AS->rhomolar();
            const double rho_mass = AS->rhomass();

            CHECK_NOTHROW(AS->update(DmolarT_INPUTS, rho_molar, T_in));
            CHECK(AS->p() == Catch::Approx(p_in).epsilon(1e-6));
            CHECK(AS->T() == Catch::Approx(T_in).epsilon(1e-10));
            CHECK(AS->rhomolar() == Catch::Approx(rho_molar).epsilon(1e-12));
            CHECK(AS->phase() == iphase_liquid);

            CHECK_NOTHROW(AS->update(DmassT_INPUTS, rho_mass, T_in));
            CHECK(AS->p() == Catch::Approx(p_in).epsilon(1e-6));
            CHECK(AS->rhomass() == Catch::Approx(rho_mass).epsilon(1e-12));
            CHECK(AS->phase() == iphase_liquid);
        }

        SECTION(backend + " vapor round-trip below Tsat") {
            // pick T well below superanc Tc and a low pressure to guarantee vapor
            const double T_in = 0.7 * Tc_sa;
            const double p_sat = ACB.calc_saturation_ancillary(iP, 1, iT, T_in);
            const double p_in = 0.5 * p_sat;  // half saturation pressure -> vapor
            AS->update(PT_INPUTS, p_in, T_in);
            const double rho_molar = AS->rhomolar();
            CHECK_NOTHROW(AS->update(DmolarT_INPUTS, rho_molar, T_in));
            CHECK(AS->p() == Catch::Approx(p_in).epsilon(1e-6));
            CHECK(AS->phase() == iphase_gas);
        }

        SECTION(backend + " two-phase region returns iphase_twophase") {
            const double T_in = 0.7 * Tc_sa;
            const double rhoL = ACB.calc_saturation_ancillary(iDmolar, 0, iT, T_in);
            const double rhoV = ACB.calc_saturation_ancillary(iDmolar, 1, iT, T_in);
            const double p_sat = ACB.calc_saturation_ancillary(iP, 0, iT, T_in);
            const double rho_mid = 0.5 * (rhoL + rhoV);  // midpoint of the dome
            CHECK_NOTHROW(AS->update(DmolarT_INPUTS, rho_mid, T_in));
            CHECK(AS->phase() == iphase_twophase);
            CHECK(AS->p() == Catch::Approx(p_sat).epsilon(1e-6));
            CHECK(AS->Q() > 0.0);
            CHECK(AS->Q() < 1.0);
        }

        SECTION(backend + " supercritical T returns single phase") {
            const double T_in = 1.5 * Tc_sa;
            const double p_in = 5e6;
            AS->update(PT_INPUTS, p_in, T_in);
            const double rho_molar = AS->rhomolar();
            CHECK_NOTHROW(AS->update(DmolarT_INPUTS, rho_molar, T_in));
            CHECK(AS->p() == Catch::Approx(p_in).epsilon(1e-6));
            const auto ph = AS->phase();
            CHECK((ph == iphase_supercritical || ph == iphase_supercritical_gas || ph == iphase_supercritical_liquid));
        }
    }
}

// ============================================================================
// Lemmon-Akasaka 2022 R-1234yf EOS check values (Table 7)
// Lemmon & Akasaka, Int. J. Thermophys. 43:119 (2022), DOI 10.1007/s10765-022-03015-y
// Table 7: density in mol/dm^3, pressure in MPa, cv/cp in J/(mol K), w in m/s
// ============================================================================

TEST_CASE("Lemmon-IJT-2022 R1234yf pure fluid check values", "[R1234yf],[Lemmon-IJT-2022]") {
    const double tol = 1e-4;  // 0.01% relative
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234yf"));

    // T=280 K, rho=0 mol/dm3 (ideal-gas limit): cv=89.2037, cp=97.5182, w=149.388
    SECTION("T=280 K, rho->0 (ideal-gas limit)") {
        AS->update(DmolarT_INPUTS, 0.001, 280.0);
        CAPTURE(AS->cvmolar());
        CAPTURE(AS->cpmolar());
        CAPTURE(AS->speed_sound());
        CHECK(AS->cvmolar() == Catch::Approx(89.2037).epsilon(tol));
        CHECK(AS->cpmolar() == Catch::Approx(97.5182).epsilon(tol));
        CHECK(AS->speed_sound() == Catch::Approx(149.388).epsilon(tol));
    }
    // T=280 K, rho=11 mol/dm3=11000 mol/m3: p=28.95760 MPa, cv=101.930, cp=139.307, w=738.905
    SECTION("T=280 K, rho=11000 mol/m3 (compressed liquid)") {
        AS->update(DmolarT_INPUTS, 11000.0, 280.0);
        CAPTURE(AS->p());
        CAPTURE(AS->cvmolar());
        CAPTURE(AS->cpmolar());
        CAPTURE(AS->speed_sound());
        CHECK(AS->p() == Catch::Approx(28.95760e6).epsilon(tol));
        CHECK(AS->cvmolar() == Catch::Approx(101.930).epsilon(tol));
        CHECK(AS->cpmolar() == Catch::Approx(139.307).epsilon(tol));
        CHECK(AS->speed_sound() == Catch::Approx(738.905).epsilon(tol));
    }
    // T=280 K, rho=0.1 mol/dm3=100 mol/m3: p=0.2185345 MPa, cv=91.3497, cp=102.623, w=141.882
    SECTION("T=280 K, rho=100 mol/m3 (gas)") {
        AS->update(DmolarT_INPUTS, 100.0, 280.0);
        CAPTURE(AS->p());
        CAPTURE(AS->cvmolar());
        CAPTURE(AS->cpmolar());
        CAPTURE(AS->speed_sound());
        CHECK(AS->p() == Catch::Approx(0.2185345e6).epsilon(tol));
        CHECK(AS->cvmolar() == Catch::Approx(91.3497).epsilon(tol));
        CHECK(AS->cpmolar() == Catch::Approx(102.623).epsilon(tol));
        CHECK(AS->speed_sound() == Catch::Approx(141.882).epsilon(tol));
    }
    // T=340 K, rho=8 mol/dm3=8000 mol/m3: p=2.309798 MPa, cv=113.805, cp=195.748, w=265.888
    SECTION("T=340 K, rho=8000 mol/m3 (liquid)") {
        AS->update(DmolarT_INPUTS, 8000.0, 340.0);
        CAPTURE(AS->p());
        CAPTURE(AS->cvmolar());
        CAPTURE(AS->cpmolar());
        CAPTURE(AS->speed_sound());
        CHECK(AS->p() == Catch::Approx(2.309798e6).epsilon(tol));
        CHECK(AS->cvmolar() == Catch::Approx(113.805).epsilon(tol));
        CHECK(AS->cpmolar() == Catch::Approx(195.748).epsilon(tol));
        CHECK(AS->speed_sound() == Catch::Approx(265.888).epsilon(tol));
    }
    // T=340 K, rho=1 mol/dm3=1000 mol/m3: p=1.855076 MPa, cv=113.479, cp=168.646, w=114.354
    SECTION("T=340 K, rho=1000 mol/m3 (superheated vapor)") {
        AS->update(DmolarT_INPUTS, 1000.0, 340.0);
        CAPTURE(AS->p());
        CAPTURE(AS->cvmolar());
        CAPTURE(AS->cpmolar());
        CAPTURE(AS->speed_sound());
        CHECK(AS->p() == Catch::Approx(1.855076e6).epsilon(tol));
        CHECK(AS->cvmolar() == Catch::Approx(113.479).epsilon(tol));
        CHECK(AS->cpmolar() == Catch::Approx(168.646).epsilon(tol));
        CHECK(AS->speed_sound() == Catch::Approx(114.354).epsilon(tol));
    }
    // T=368 K, rho=4.2 mol/dm3=4200 mol/m3: p=3.394716 MPa, cv=149.703, cp=48981.3, w=76.3597
    SECTION("T=368 K, rho=4200 mol/m3 (near-critical)") {
        AS->update(DmolarT_INPUTS, 4200.0, 368.0);
        CAPTURE(AS->p());
        CAPTURE(AS->cvmolar());
        CAPTURE(AS->cpmolar());
        CAPTURE(AS->speed_sound());
        CHECK(AS->p() == Catch::Approx(3.394716e6).epsilon(tol));
        CHECK(AS->cvmolar() == Catch::Approx(149.703).epsilon(tol));
        // Cp diverges near the critical point; use a looser tolerance
        CHECK(AS->cpmolar() == Catch::Approx(48981.3).epsilon(5e-3));
        CHECK(AS->speed_sound() == Catch::Approx(76.3597).epsilon(tol));
    }
}

TEST_CASE("Lemmon-IJT-2022 R1234yf fixed-point constants", "[R1234yf],[Lemmon-IJT-2022]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234yf"));
    CHECK(AS->T_critical() == Catch::Approx(367.85).epsilon(1e-5));
    CHECK(AS->p_critical() == Catch::Approx(3384400.0).epsilon(1e-4));
    CHECK(AS->rhomolar_critical() == Catch::Approx(4180.0).epsilon(1e-4));
    CHECK(AS->Ttriple() == Catch::Approx(121.6).epsilon(1e-4));
}

// McLinden & Akasaka, J. Chem. Eng. Data 65:4201 (2020), DOI 10.1021/acs.jced.9b01198 —
// ISO 17584 international-standard EOS for R-1336mzz(Z). The paper publishes critical
// parameters in Table 7 (Tc=444.5 K, rhoc=3.044 mol/L, pc=2.903 MPa) and molar mass in
// the text; it does not include a computer-verification table of (p, cv, cp, w) check
// values, so regression coverage at the EOS-coefficient level comes instead from the
// R-1336mzz(Z)/R-1130(E) alphar check in the NIST-IR-8570 mixture test below (Table 4-4
// departure function exercises all pure-fluid residual Helmholtz terms indirectly).
//
// p_critical / rhomolar_critical tolerances are set to the paper's stated precision
// (4 sig figs, ~1e-3) rather than EOS-level precision: with the SUPERANCILLARY block
// loaded, those accessors return the EOS's *numerical* critical (where dp/drho|T = 0
// and d2p/drho2|T = 0, evaluated from the SA crit_anc), which for this fluid sits at
// pc=2.9037 MPa, rhoc=3044.5 mol/m^3 — both round to the paper values at 4 sig figs.
TEST_CASE("McLinden-JCED-2020 R1336mzz(Z) fixed-point constants", "[R1336mzzZ],[McLinden-JCED-2020-R1336mzzZ]") {
    shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1336mzz(Z)"));
    CHECK(AS->T_critical() == Catch::Approx(444.5).epsilon(1e-5));
    CHECK(AS->p_critical() == Catch::Approx(2.903e6).epsilon(1e-3));
    CHECK(AS->rhomolar_critical() == Catch::Approx(3044.0).epsilon(1e-3));
    CHECK(AS->molar_mass() == Catch::Approx(0.164056).epsilon(1e-5));
}

// ============================================================================
// Mixture binary pair checks — Bell-JPCRD-2022 and Bell-JPCRD-2023
//
// Check values are the dimensionless residual Helmholtz energy alphar at the
// state point defined by rho/rho_red = 0.8 and T_red/T = 0.8 (z1 = 0.4).
//
// Table XI from Bell, JPCRD 51, 013103 (2022), DOI 10.1063/5.0083545
//   (pairs unique to Paper 1: R1234yf/R1234zeE, R1234yf/R134a, R134a/R1234zeE)
//
// Table XIII from Bell, JPCRD 52, 013101 (2023), DOI 10.1063/5.0124188
//   (all five pairs in Paper 2, including R125/R1234yf, R1234yf/R152a,
//    R1234zeE/R227ea which supersede Paper 1 interim models)
//
// Note: Paper 1's Table XI used a pre-publication version of the R1234yf EOS
// and matches only to ~1e-6 with the final Lemmon-IJT-2022 EOS used here.
// Paper 2's Table XIII used the final EOS and agrees to ~1e-10.
// ============================================================================

TEST_CASE("Bell-JPCRD-2022 mixture alphar check values (Table XI)", "[mixtures],[Bell-JPCRD-2022]") {
    // Table XI was computed with a pre-publication R1234yf EOS. Pairs containing R1234yf
    // use check values recomputed with the final Lemmon-IJT-2022 R1234yf EOS (the R1234yf
    // EOS change shifts alphar by ~0.4%). The R134a+R1234zeE pair contains no R1234yf and
    // agrees with Table XI to ~1e-10.
    const double tol = 1e-10;

    // R1234yf + R1234zeE: z1=0.4, T=469 K, rho=3399 mol/m3
    // Table XI (pre-pub R1234yf EOS): -0.46059464176252; Lemmon-IJT-2022 R1234yf EOS: -0.46467899824257763
    SECTION("R1234yf + R1234ze(E): Table XI") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234yf&R1234zeE"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3399.0, 469.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46467899824257763).epsilon(tol));
    }
    // R1234yf + R134a: z1=0.4, T=462 K, rho=3698 mol/m3
    // Table XI (pre-pub R1234yf EOS): -0.46550859128831; Lemmon-IJT-2022 R1234yf EOS: -0.46550859405816197
    SECTION("R1234yf + R134a: Table XI") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234yf&R134a"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3698.0, 462.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46550859405816197).epsilon(tol));
    }
    // R134a + R1234zeE: z1=0.4, T=472 K, rho=3639 mol/m3, alphar=-0.46245130334193
    SECTION("R134a + R1234ze(E): Table XI") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R134a&R1234zeE"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3639.0, 472.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46245130334193).epsilon(tol));
    }
    // Inverted-order sections: verify betaT inversion is applied correctly in both orderings.
    // The GERG reducing function is symmetric under component swap + reciprocal beta, so
    // alphar must agree with the tabulated value within floating-point precision.
    SECTION("R1234yf + R1234ze(E): inverted component order") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234zeE&R1234yf"));
        AS->set_mole_fractions({0.6, 0.4});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3399.0, 469.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46467899824257763).epsilon(tol));
    }
    SECTION("R134a + R1234ze(E): inverted component order") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234zeE&R134a"));
        AS->set_mole_fractions({0.6, 0.4});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3639.0, 472.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46245130334193).epsilon(tol));
    }
    SECTION("R1234yf + R134a: inverted component order") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R134a&R1234yf"));
        AS->set_mole_fractions({0.6, 0.4});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3698.0, 462.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46550859405816197).epsilon(tol));
    }
}

TEST_CASE("Bell-JPCRD-2023 mixture alphar check values (Table XIII)", "[mixtures],[Bell-JPCRD-2023]") {
    // Table XIII used the final Lemmon-IJT-2022 R1234yf EOS; expect ~1e-10 agreement
    const double tol = 1e-10;

    // R32 + R1234yf: z1=0.4, T=445 K, rho=4149 mol/m3, alphar=-0.47311064743911
    SECTION("R32 + R1234yf: Table XIII") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R32&R1234yf"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 4149.0, 445.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.47311064743911).epsilon(tol));
    }
    // R32 + R1234zeE: z1=0.4, T=451 K, rho=4242 mol/m3, alphar=-0.48576186760231
    SECTION("R32 + R1234ze(E): Table XIII") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R32&R1234zeE"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 4242.0, 451.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.48576186760231).epsilon(tol));
    }
    // R125 + R1234yf: z1=0.4, T=445 K, rho=3513 mol/m3, alphar=-0.46576307479447
    SECTION("R125 + R1234yf: Table XIII") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R125&R1234yf"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3513.0, 445.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.46576307479447).epsilon(tol));
    }
    // R1234yf + R152a: z1=0.4, T=469 K, rho=3930 mol/m3, alphar=-0.48967548916638
    SECTION("R1234yf + R152a: Table XIII") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234yf&R152a"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3930.0, 469.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.48967548916638).epsilon(tol));
    }
    // R1234zeE + R227ea: z1=0.4, T=470 K, rho=3023 mol/m3, alphar=-0.45378834770736
    SECTION("R1234ze(E) + R227ea: Table XIII") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234zeE&R227ea"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3023.0, 470.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.45378834770736).epsilon(tol));
    }
}

// ============================================================================
// NIST IR 8570 (McLinden et al., 2025, DOI 10.6028/NIST.IR.8570) Tables 4-3
// and 4-4 mixing parameters: alphar check values for the three binary pairs
// added in this PR:
//   * R-1132(E)/R-32           (F=0, no departure)
//   * R-1132(E)/R-1234yf       (F=0, no departure)
//   * R-1336mzz(Z)/R-1130(E)   (F=1, one-term exponential departure)
//
// State point convention follows Bell-JPCRD-2022/2023: z1 = 0.4 with
// tau = T_red(x)/T = 0.8, delta = rho/rho_red(x) = 0.8, computed from the
// GERG-2008 reducing functions (NIST IR 8570 Eqs. 4-9, 4-10) using the
// betaT/gammaT/betaV/gammaV from Table 4-3, then T and rho rounded to the
// nearest K and mol/m^3 for portable hard-coded constants.  alphar is then
// evaluated at the rounded state point.  Inverted-component-order sections
// verify the GERG reducing-function symmetry (component swap + reciprocal
// beta = same alphar).
// ============================================================================

TEST_CASE("NIST IR 8570 mixture alphar check values (Tables 4-3 / 4-4)", "[mixtures],[NIST-IR-8570]") {
    const double tol = 1e-10;

    // R-1132(E) + R-32: betaT=0.9509, gammaT=1.0281, betaV=1.0336, gammaV=1.0040
    // T_red = 353.064175 K, rho_red = 7520.0025 mol/m^3 -> T = 441 K, rho = 6016 mol/m^3
    SECTION("R-1132(E) + R-32: Table 4-3") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1132E&R32"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 6016.0, 441.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.5172864096181671).epsilon(tol));
    }
    SECTION("R-1132(E) + R-32: inverted component order") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R32&R1132E"));
        AS->set_mole_fractions({0.6, 0.4});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 6016.0, 441.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.5172864096181671).epsilon(tol));
    }

    // R-1132(E) + R-1234yf: betaT=0.9835, gammaT=0.9999, betaV=0.9972, gammaV=1.0197
    // T_red = 359.566316 K, rho_red = 4941.0809 mol/m^3 -> T = 449 K, rho = 3953 mol/m^3
    SECTION("R-1132(E) + R-1234yf: Table 4-3") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1132E&R1234yf"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3953.0, 449.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.4749927188694013).epsilon(tol));
    }
    SECTION("R-1132(E) + R-1234yf: inverted component order") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1234yf&R1132E"));
        AS->set_mole_fractions({0.6, 0.4});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3953.0, 449.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.4749927188694013).epsilon(tol));
    }

    // R-1336mzz(Z) + R-1130(E): betaT=0.9740, gammaT=0.9195, betaV=1.1480, gammaV=0.9251, F=1.0
    // Departure function (Table 4-4): one-term exponential, n=-0.277036, t=2.956973, d=1, l=1
    // T_red = 466.899749 K, rho_red = 3931.9577 mol/m^3 -> T = 584 K, rho = 3146 mol/m^3
    SECTION("R-1336mzz(Z) + R-1130(E): Table 4-3 + 4-4") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1336mzz(Z)&R1130(E)"));
        AS->set_mole_fractions({0.4, 0.6});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3146.0, 584.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.4936442709738808).epsilon(tol));
    }
    SECTION("R-1336mzz(Z) + R-1130(E): inverted component order") {
        shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R1130(E)&R1336mzz(Z)"));
        AS->set_mole_fractions({0.6, 0.4});
        AS->specify_phase(CoolProp::iphase_gas);
        AS->update(DmolarT_INPUTS, 3146.0, 584.0);
        CAPTURE(AS->alphar());
        CHECK(AS->alphar() == Catch::Approx(-0.4936442709738808).epsilon(tol));
    }
}

TEST_CASE("NIST IR 8570 PropsSI saturation smoke check", "[mixtures],[NIST-IR-8570]") {
    // Just verify the new pairs are loadable end-to-end via the high-level API.
    SECTION("R-1132(E) + R-32 saturation at 300 K returns finite") {
        double p = CoolProp::PropsSI("P", "T", 300.0, "Q", 0, "R1132E[0.5]&R32[0.5]");
        CAPTURE(p);
        CHECK(std::isfinite(p));
        CHECK(p > 0);
    }
    SECTION("R-1132(E) + R-1234yf saturation at 300 K returns finite") {
        double p = CoolProp::PropsSI("P", "T", 300.0, "Q", 0, "R1132E[0.5]&R1234yf[0.5]");
        CAPTURE(p);
        CHECK(std::isfinite(p));
        CHECK(p > 0);
    }
    SECTION("R-1336mzz(Z) + R-1130(E) saturation at 380 K returns finite") {
        // Both pure components have Tc > 440 K; 380 K is well below both saturation envelopes.
        double p = CoolProp::PropsSI("P", "T", 380.0, "Q", 0, "R1336mzz(Z)[0.5]&R1130(E)[0.5]");
        CAPTURE(p);
        CHECK(std::isfinite(p));
        CHECK(p > 0);
    }
}

/*
TEST_CASE("Test that HS solver works for a few fluids", "[HS_solver]")
{
    std::vector<std::string> fluids; fluids.push_back("Propane"); fluids.push_back("D4"); fluids.push_back("Water");
    for (std::size_t i = 0; i < fluids.size(); ++i)
    {
        std::vector<std::string> fl(1,fluids[i]);
        shared_ptr<CoolProp::HelmholtzEOSMixtureBackend> HEOS = std::make_shared<CoolProp::HelmholtzEOSMixtureBackend>(fl);
        for (double p = HEOS->p_triple()*10; p < HEOS->pmax(); p *= 10)
        {
            double Tmin = HEOS->Ttriple();
            double Tmax = HEOS->Tmax();
            for (double T = Tmin + 1; T < Tmax-1; T += 10)
            {
                std::ostringstream ss;
                ss << "Check HS for " << fluids[i] << " for T=" << T << ", p=" << p;
                SECTION(ss.str(),"")
                {
                    CHECK_NOTHROW(HEOS->update(PT_INPUTS, p, T));
                    std::ostringstream ss1;
                    ss1 << "h=" << HEOS->hmolar() << ", s=" << HEOS->smolar();
                    SECTION(ss1.str(),"")
                    {
                        CAPTURE(T);
                        CAPTURE(p);
                        CAPTURE(HEOS->hmolar());
                        CAPTURE(HEOS->smolar());
                        CHECK_NOTHROW(HEOS->update(HmolarSmolar_INPUTS, HEOS->hmolar(), HEOS->smolar()));
                        double Terr = HEOS->T()- T;
                        CAPTURE(Terr);
                        CHECK(std::abs(Terr) < 1e-6);
                    }
                }
            }
        }
    }
}
*/

// One published computer-verification test point per fluid added in the
// Akasaka/Lemmon/Thol batch of EOS updates (issues #2762, #2763, #2764,
// #2765). Each row is lifted directly from the validation table in the
// corresponding paper; tolerances are generous enough to absorb the last
// printed digit of each published value but tight enough to catch a real
// regression in the EOS or its loader.
TEST_CASE("Fluid batch 2020-2024: verify EOS against paper validation tables", "[fluids][batch_2020_2024]") {
    struct row
    {
        const char* fluid;
        double T_K, rho_molm3;
        double p_Pa, cv_JmolK, cp_JmolK, w_ms;
        double rtol;  // relative tolerance for all four properties
        const char* note;
    };
    const std::vector<row> rows = {
      // Paper / Table / Row
      {"R1224YDZ", 400.0, 8000.0, 21.17909e6, 139.592, 185.184, 489.479, 1e-5, "Akasaka & Lemmon, IJT 2023, Table 7 row 4"},
      {"R1132E", 330.0, 12000.0, 3.845082e6, 70.9361, 165.548, 314.193, 1e-5, "Akasaka & Lemmon, IJT 2024, Table 6 row 4"},
      {"Tetrahydrofuran", 450.0, 10000.0, 12.357974600e6, 0.0, 167.23826646, 739.195761440, 1e-6,
       "Fiedler et al., IJT 2023, Table 11 row 3 (cv not published)"},
      {"PropyleneGlycol", 400.0, 13000.0, 61.287909e6, 0.0, 227.48403, 1467.8267, 1e-5,
       "Eisenbach et al., JPCRD 2021, Table 8 row 2 (cv not published)"},
      {"VinylChloride", 300.0, 15000.0, 23.0374719e6, 0.0, 91.4066946, 1008.04450, 1e-6,
       "Thol, Fenkl & Lemmon, IJT 2022, Table 5 row 4 (cv not published)"},
      {"R1123", 320.0, 11000.0, 5.456590e6, 74.3579, 158.839, 296.996, 1e-5, "Akasaka et al., IJR 2020, Table 8 row 4"},
      {"n-Perfluorobutane", 360.0, 5200.0, 3.128110e6, 223.0894, 303.2828, 226.8389, 1e-5, "Gao et al., IECR 2022, Table 14 C4F10 row 3"},
      {"n-Perfluoropentane", 390.0, 4200.0, 1.496384e6, 273.9917, 375.3160, 182.6921, 1e-5, "Gao et al., IECR 2022, Table 14 C5F12 row 3"},
      {"n-Perfluorohexane", 410.0, 3700.0, 0.9573522e6, 336.7461, 435.6546, 181.2565, 1e-5, "Gao et al., IECR 2022, Table 14 C6F14 row 3"},
      {"R1233zd(E)", 400.0, 8000.0, 10.79073e6, 122.693, 176.124, 441.123, 1e-5,
       "Akasaka & Lemmon, JPCRD 2022, Table IX row 4 (supersedes Mondejar-JCED-2015)"},
      {"R1130(E)", 320.0, 12500.0, 3.39671e6, 76.665, 115.586, 946.434, 1e-5,
       "Huber, Kazakov & Lemmon, IJT 2025, Table 4 row 3 (g_i != 1 in exponential terms)"},
      {"R1243zf", 280.0, 11000.0, 7.393335e6, 90.7467, 130.734, 648.467, 1e-5,
       "Akasaka & Lemmon, IJT 2025, Table 6 row 2 (3rd EOS, g_i != 1; supersedes Akasaka-JCED-2019)"},
    };

    for (const auto& r : rows) {
        SECTION(std::string(r.fluid) + " (" + r.note + ")") {
            CAPTURE(r.fluid);
            CAPTURE(r.T_K);
            CAPTURE(r.rho_molm3);

            const double p_calc = PropsSI("P", "T", r.T_K, "Dmolar", r.rho_molm3, r.fluid);
            const double cp_calc = PropsSI("Cpmolar", "T", r.T_K, "Dmolar", r.rho_molm3, r.fluid);
            const double w_calc = PropsSI("A", "T", r.T_K, "Dmolar", r.rho_molm3, r.fluid);

            CHECK(p_calc == Catch::Approx(r.p_Pa).epsilon(r.rtol));
            CHECK(cp_calc == Catch::Approx(r.cp_JmolK).epsilon(r.rtol));
            CHECK(w_calc == Catch::Approx(r.w_ms).epsilon(r.rtol));

            // cv was not published in every paper's verification table; skip
            // the check when the reference entry is exactly 0.0.
            if (r.cv_JmolK != 0.0) {
                const double cv_calc = PropsSI("Cvmolar", "T", r.T_K, "Dmolar", r.rho_molm3, r.fluid);
                CHECK(cv_calc == Catch::Approx(r.cv_JmolK).epsilon(r.rtol));
            }
        }
    }
}

TEST_CASE("Qmass output: pure fluid equals Qmolar", "[Qmass]") {
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));
    for (double Q : {0.0, 0.1, 0.5, 0.9, 1.0}) {
        AS->update(CoolProp::QT_INPUTS, Q, 350.0);
        CHECK(AS->Qmass() == Catch::Approx(Q).epsilon(1e-12));
    }
}

TEST_CASE("Qmass output: HEOS mixture differs from Qmolar and is internally consistent", "[Qmass][mixture]") {
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
    AS->set_mole_fractions({0.5, 0.5});

    // Retrieve component molar masses from CoolProp itself to avoid hardcoded constant mismatch
    auto AS_R32 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32"));
    auto AS_R125 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R125"));
    const double MM_R32 = AS_R32->molar_mass();
    const double MM_R125 = AS_R125->molar_mass();

    for (double Q : {0.1, 0.3, 0.5, 0.7, 0.9}) {
        AS->update(CoolProp::QT_INPUTS, Q, 280.0);

        const auto x = AS->mole_fractions_liquid();
        const auto y = AS->mole_fractions_vapor();
        const double MM_l = static_cast<double>(x[0]) * MM_R32 + static_cast<double>(x[1]) * MM_R125;
        const double MM_v = static_cast<double>(y[0]) * MM_R32 + static_cast<double>(y[1]) * MM_R125;
        const double Qmass_expected = (Q * MM_v) / (Q * MM_v + (1.0 - Q) * MM_l);

        CHECK(AS->Qmass() == Catch::Approx(Qmass_expected).epsilon(1e-6));
        // For an asymmetric mixture, Qmass should differ from Qmolar at intermediate Q
        if (Q > 0.05 && Q < 0.95) {
            CHECK(std::abs(AS->Qmass() - Q) > 1e-3);
        }
    }
}

TEST_CASE("Qmass input: HEOS R32+R125 round-trip via QmassT_INPUTS", "[Qmass][mixture]") {
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
    AS->set_mole_fractions({0.5, 0.5});
    AS->update(CoolProp::QT_INPUTS, 0.4, 280.0);
    const double Qmass_observed = AS->Qmass();
    const double p_ref = AS->p();
    const double Q_ref = AS->Q();

    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
    AS2->set_mole_fractions({0.5, 0.5});
    AS2->update(CoolProp::QmassT_INPUTS, Qmass_observed, 280.0);
    CHECK(AS2->p() == Catch::Approx(p_ref).epsilon(1e-8));
    CHECK(AS2->Q() == Catch::Approx(Q_ref).epsilon(1e-8));
    CHECK(AS2->Qmass() == Catch::Approx(Qmass_observed).epsilon(1e-10));
}

TEST_CASE("Qmass input: pure Water round-trips for QmassT and PQmass", "[Qmass][pure]") {
    auto ref = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));
    auto sut = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));

    SECTION("QmassT_INPUTS") {
        ref->update(CoolProp::QT_INPUTS, 0.4, 350.0);
        const double Qmass = ref->Qmass();
        const double p_ref = ref->p();
        sut->update(CoolProp::QmassT_INPUTS, Qmass, 350.0);
        CHECK(sut->T() == Catch::Approx(350.0).epsilon(1e-12));
        CHECK(sut->p() == Catch::Approx(p_ref).epsilon(1e-12));
        CHECK(sut->Q() == Catch::Approx(0.4).epsilon(1e-12));
    }

    SECTION("PQmass_INPUTS") {
        ref->update(CoolProp::QT_INPUTS, 0.4, 350.0);
        const double p_ref = ref->p();
        const double Qmass = ref->Qmass();
        sut->update(CoolProp::PQmass_INPUTS, p_ref, Qmass);
        CHECK(sut->Q() == Catch::Approx(0.4).epsilon(1e-12));
        CHECK(sut->T() == Catch::Approx(350.0).epsilon(1e-12));
    }
}

TEST_CASE("Qmass input: HEOS mixture round-trip via PQmass / HmolarQmass / DmolarQmass", "[Qmass][mixture]") {
    auto setup = []() {
        auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
        AS->set_mole_fractions({0.5, 0.5});
        return AS;
    };

    SECTION("PQmass") {
        auto ref = setup();
        ref->update(CoolProp::PQ_INPUTS, 1.5e6, 0.4);
        const double Qmass = ref->Qmass();
        const double T_ref = ref->T();

        auto sut = setup();
        sut->update(CoolProp::PQmass_INPUTS, 1.5e6, Qmass);
        CHECK(sut->T() == Catch::Approx(T_ref).epsilon(1e-8));
        CHECK(sut->Q() == Catch::Approx(0.4).epsilon(1e-8));
    }

    // NOTE: HmolarQmass and DmolarQmass sections commented out due to pre-existing HEOS mixture
    // flash limitation: HQ_flash and DQ_flash are not yet ready for mixtures. The PQmass section
    // (which uses PT_flash) exercises the full qmass_slot==2 iteration logic and passes.

    // SECTION("HmolarQmass") {
    //     auto ref = setup();
    //     ref->update(CoolProp::QT_INPUTS, 0.4, 280.0);
    //     const double H      = ref->hmolar();
    //     const double Qmass  = ref->Qmass();
    //     ref->update(CoolProp::HmolarQ_INPUTS, H, 0.4);
    //     const double T_ref  = ref->T();
    //
    //     auto sut = setup();
    //     sut->update(CoolProp::HmolarQmass_INPUTS, H, Qmass);
    //     CHECK(sut->T() == Catch::Approx(T_ref).epsilon(1e-8));
    //     CHECK(sut->Q() == Catch::Approx(0.4).epsilon(1e-6));
    // }
    //
    // SECTION("DmolarQmass") {
    //     auto ref = setup();
    //     ref->update(CoolProp::QT_INPUTS, 0.4, 280.0);
    //     const double D      = ref->rhomolar();
    //     const double Qmass  = ref->Qmass();
    //     const double T_ref  = ref->T();
    //
    //     auto sut = setup();
    //     sut->update(CoolProp::DmolarQmass_INPUTS, D, Qmass);
    //     CHECK(sut->T() == Catch::Approx(T_ref).epsilon(1e-8));
    //     CHECK(sut->Q() == Catch::Approx(0.4).epsilon(1e-6));
    // }
}

TEST_CASE("Qmass output: REFPROP R32+R125 matches HEOS to leading digits", "[Qmass][REFPROP]") {
    std::shared_ptr<CoolProp::AbstractState> AS;
    try {
        AS.reset(CoolProp::AbstractState::factory("REFPROP", "R32&R125"));
    } catch (...) {
        WARN("REFPROP not available; skipping");
        return;
    }
    AS->set_mole_fractions({0.5, 0.5});
    AS->update(CoolProp::QT_INPUTS, 0.4, 280.0);
    const double Qmass_refprop = AS->Qmass();

    auto AS_heos = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
    AS_heos->set_mole_fractions({0.5, 0.5});
    AS_heos->update(CoolProp::QT_INPUTS, 0.4, 280.0);
    const double Qmass_heos = AS_heos->Qmass();

    // Different EOS but same physical mixture; agreement to ~3 digits is plenty
    // to confirm the REFPROP override is computing something sensible.
    CHECK(Qmass_refprop == Catch::Approx(Qmass_heos).epsilon(1e-2));
    // Sanity: result is in (0, 1) and not equal to Qmolar=0.4 (mixture should differ)
    CHECK(Qmass_refprop > 0.0);
    CHECK(Qmass_refprop < 1.0);
    CHECK(std::abs(Qmass_refprop - 0.4) > 1e-3);
}

TEST_CASE("Qmass input: REFPROP R32+R125 native kq=2 fast path", "[Qmass][REFPROP]") {
    std::shared_ptr<CoolProp::AbstractState> AS;
    try {
        AS.reset(CoolProp::AbstractState::factory("REFPROP", "R32&R125"));
    } catch (...) {
        WARN("REFPROP not available; skipping");
        return;
    }
    AS->set_mole_fractions({0.5, 0.5});
    AS->update(CoolProp::QT_INPUTS, 0.4, 280.0);
    const double Qmass = AS->Qmass();
    const double P_ref = AS->p();
    const double Q_ref = AS->Q();

    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("REFPROP", "R32&R125"));
    AS2->set_mole_fractions({0.5, 0.5});
    AS2->update(CoolProp::QmassT_INPUTS, Qmass, 280.0);
    CHECK(AS2->p() == Catch::Approx(P_ref).epsilon(1e-5));
    CHECK(AS2->Q() == Catch::Approx(Q_ref).epsilon(1e-5));
    CHECK(AS2->Qmass() == Catch::Approx(Qmass).epsilon(1e-12));

    // PQmass round-trip
    auto AS3 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("REFPROP", "R32&R125"));
    AS3->set_mole_fractions({0.5, 0.5});
    AS3->update(CoolProp::PQmass_INPUTS, P_ref, Qmass);
    CHECK(AS3->T() == Catch::Approx(280.0).epsilon(1e-5));
    CHECK(AS3->Q() == Catch::Approx(Q_ref).epsilon(1e-5));
}

TEST_CASE("Qmass edge cases: bubble/dew, out-of-range, single-phase", "[Qmass][edge]") {
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
    AS->set_mole_fractions({0.5, 0.5});

    SECTION("Qmass = 0 (bubble) bypasses iteration") {
        AS->update(CoolProp::QmassT_INPUTS, 0.0, 280.0);
        CHECK(AS->Q() == Catch::Approx(0.0).epsilon(1e-12));
        CHECK(AS->Qmass() == Catch::Approx(0.0).epsilon(1e-12));
    }

    SECTION("Qmass = 1 (dew) bypasses iteration") {
        AS->update(CoolProp::QmassT_INPUTS, 1.0, 280.0);
        CHECK(AS->Q() == Catch::Approx(1.0).epsilon(1e-12));
        CHECK(AS->Qmass() == Catch::Approx(1.0).epsilon(1e-12));
    }

    SECTION("Qmass < 0 throws") {
        CHECK_THROWS_AS(AS->update(CoolProp::QmassT_INPUTS, -0.1, 280.0), CoolProp::ValueError);
    }

    SECTION("Qmass > 1 throws") {
        CHECK_THROWS_AS(AS->update(CoolProp::QmassT_INPUTS, 1.5, 280.0), CoolProp::ValueError);
    }

    SECTION("Qmass() in single-phase state throws") {
        AS->update(CoolProp::PT_INPUTS, 5e6, 400.0);  // single phase (well above critical for R32+R125)
        CHECK_THROWS_AS(AS->Qmass(), CoolProp::ValueError);
    }
}

TEST_CASE("Qmass: PropsSI integration (output + input)", "[Qmass][PropsSI]") {
    SECTION("Qmass as output for pure Water == Q") {
        const double Q = 0.3, T = 350.0;
        const double Qmolar = CoolProp::PropsSI("Q", "T", T, "Q", Q, "Water");
        const double Qmass = CoolProp::PropsSI("Qmass", "T", T, "Q", Q, "Water");
        CHECK(Qmolar == Catch::Approx(0.3).epsilon(1e-12));
        CHECK(Qmass == Catch::Approx(0.3).epsilon(1e-12));
    }
    SECTION("Qmass as input for pure Water round-trip via PropsSI") {
        const double T = 350.0;
        const double P_ref = CoolProp::PropsSI("P", "T", T, "Q", 0.3, "Water");
        const double P_via = CoolProp::PropsSI("P", "T", T, "Qmass", 0.3, "Water");
        CHECK(P_via == Catch::Approx(P_ref).epsilon(1e-12));
    }
    SECTION("Qmass as input for HEOS R32+R125 mixture via PropsSI") {
        // Note: PropsSI doesn't support setting mole fractions for mixtures
        // through a "&"-syntax fluid name without a separate concentration vector,
        // so we use the AbstractState API for the mixture round-trip test below.
        auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
        AS->set_mole_fractions({0.5, 0.5});
        AS->update(CoolProp::QT_INPUTS, 0.4, 280.0);
        const double Qmass_obs = AS->Qmass();
        const double P_ref = AS->p();

        auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
        AS2->set_mole_fractions({0.5, 0.5});
        AS2->update(CoolProp::QmassT_INPUTS, Qmass_obs, 280.0);
        CHECK(AS2->p() == Catch::Approx(P_ref).epsilon(1e-8));
    }
}

TEST_CASE("Qmass: PCSAFT mixture output works after Q-pair flash", "[Qmass][PCSAFT][mixture]") {
    // Verifies PCSAFT calc_phase_molar_masses override and the early-exit hook.
    // METHANE[0.0252]+BENZENE[0.9748] at Q=0, T=421.05 K is in the PCSAFT
    // VLE regression suite (existing test in this file, ~line 2942).
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("PCSAFT", "METHANE&BENZENE"));
    AS->set_mole_fractions({0.0252, 0.9748});
    AS->update(CoolProp::QT_INPUTS, 0.0, 421.05);
    // At Q=0 (saturated liquid) the endpoint short-circuit in calc_Qmass returns 0
    // without computing MM_l/MM_v — important because PCSAFT may not populate
    // SatV->mole_fractions at saturation endpoints.
    CHECK(AS->Q() == Catch::Approx(0.0).epsilon(1e-10));
    CHECK(AS->Qmass() == Catch::Approx(0.0).epsilon(1e-10));
    // QmassT_INPUTS at Qmass=0 must reach the same state via the endpoint
    // bypass in update_Qmass_pair (no iteration, no flash convergence concerns).
    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("PCSAFT", "METHANE&BENZENE"));
    AS2->set_mole_fractions({0.0252, 0.9748});
    AS2->update(CoolProp::QmassT_INPUTS, 0.0, 421.05);
    CHECK(AS2->p() == Catch::Approx(AS->p()).epsilon(1e-10));
    CHECK(AS2->Q() == Catch::Approx(0.0).epsilon(1e-10));
}

TEST_CASE("Qmass: SRK cubic mixture output works after Q-pair flash", "[Qmass][cubic][mixture]") {
    // Verifies the cubic backend's early-exit hook + inherited HEOS
    // calc_phase_molar_masses override (cubic shares HEOS's SatL/SatV machinery).
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("SRK", "Propane&n-Butane"));
    AS->set_mole_fractions({0.5, 0.5});
    AS->update(CoolProp::PQ_INPUTS, 5e5, 0.0);
    CHECK(AS->Q() == Catch::Approx(0.0).epsilon(1e-10));
    CHECK(AS->Qmass() == Catch::Approx(0.0).epsilon(1e-10));
    // Endpoint round-trip via Qmass-input pair (early-exit hook + endpoint shortcut).
    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("SRK", "Propane&n-Butane"));
    AS2->set_mole_fractions({0.5, 0.5});
    AS2->update(CoolProp::PQmass_INPUTS, 5e5, 0.0);
    CHECK(AS2->T() == Catch::Approx(AS->T()).epsilon(1e-10));
    CHECK(AS2->Q() == Catch::Approx(0.0).epsilon(1e-10));
}

TEST_CASE("User-fluid schema validation rejects malformed PCSAFT/cubic payloads", "[json_validation]") {
    // --- Cubic (SRK) ---
    // 1. Structurally invalid JSON must throw unconditionally.
    SECTION("Cubic SRK - invalid JSON syntax throws") {
        CHECK_THROWS_AS(CoolProp::add_fluids_as_JSON("SRK", "this is not json"), CoolProp::ValueError);
    }
    // 2. Valid JSON array but missing required schema fields (Tc_units, pc_units,
    //    molemass_units, acentric) — the Valijson validator catches the omissions
    //    and add_fluids_from_JSON_string throws unconditionally for cubics.
    SECTION("Cubic SRK - schema-invalid payload (missing required fields) throws") {
        // Provides name, CAS, Tc, pc, molemass but omits the *_units fields and
        // acentric, all of which are listed in the cubic schema's "required" array.
        const std::string bad_cubic = R"([{"name":"BadFluid","CAS":"000-00-0","Tc":400.0,"pc":3e6,"molemass":0.04}])";
        CHECK_THROWS_AS(CoolProp::add_fluids_as_JSON("SRK", bad_cubic), CoolProp::ValueError);
    }

    // --- PC-SAFT ---
    // The PCSAFT loader only throws on validation failure when debug_level > 0
    // (at level 0 it silently returns); raise it for these checks and restore
    // unconditionally via RAII, so other tests are unaffected even if the
    // assertion throws an unexpected type.

    // 3. Structurally invalid JSON under debug_level > 0 must throw.
    SECTION("PCSAFT - invalid JSON syntax throws at debug_level > 0") {
        // PCSAFT's loader only surfaces validation failures when debug_level > 0
        // (at level 0 it silently returns); raise it for this check and restore
        // unconditionally via RAII, so other tests are unaffected even if the
        // assertion throws an unexpected type.
        struct DebugLevelGuard
        {
            int saved;
            DebugLevelGuard() : saved(CoolProp::get_debug_level()) {}
            ~DebugLevelGuard() {
                CoolProp::set_debug_level(saved);
            }
        } guard;
        CoolProp::set_debug_level(1);
        CHECK_THROWS_AS(CoolProp::add_fluids_as_JSON("PCSAFT", "this is not json"), CoolProp::ValueError);
    }

    // 4. Valid JSON array but missing required schema fields (m, sigma, sigma_units,
    //    u, u_units, molemass, molemass_units) — the PCSAFT schema marks these in its
    //    "required" array, so Valijson rejects the payload and the loader throws when
    //    debug_level > 0.
    SECTION("PCSAFT - schema-invalid payload (missing required fields) throws at debug_level > 0") {
        struct DebugLevelGuard
        {
            int saved;
            DebugLevelGuard() : saved(CoolProp::get_debug_level()) {}
            ~DebugLevelGuard() {
                CoolProp::set_debug_level(saved);
            }
        } guard;
        CoolProp::set_debug_level(1);
        // Provides name and CAS but omits m, sigma, sigma_units, u, u_units,
        // molemass, molemass_units — all listed in the PCSAFT schema's "required" array.
        CHECK_THROWS_AS(CoolProp::add_fluids_as_JSON("PCSAFT", R"([{"name":"Bogus","CAS":"000-00-0"}])"), CoolProp::ValueError);
    }
}

TEST_CASE("Water TS_INPUTS flash near 631-634 K is smooth (no spike to 6e13 Pa)", "[water_flash][2079]") {
    // Issue #2079: previously CP.PropsSI('P','T',T,'S',6763.617,'Water')
    // for T in {631, 632, 633, 634} returned ~6e13 Pa (vs ~3.1 MPa
    // expected). The HEOS PT-style flash now converges smoothly across
    // this region; this guard makes sure it stays that way.
    const double s = 6763.617210539725;
    const double p_expected = 3.1e6;  // expected magnitude across the band
    for (double T : {631.0, 632.0, 633.0, 634.0}) {
        CAPTURE(T);
        const double p = CoolProp::PropsSI("P", "T", T, "S", s, "Water");
        CAPTURE(p);
        CHECK(std::isfinite(p));
        CHECK(p > 0);
        CHECK(p < 1e8);  // reject the old 6e13 spike with massive margin
        CHECK(std::abs(p - p_expected) / p_expected < 0.05);
    }
}

TEST_CASE("Water HS_INPUTS flash near H=3133800, S=6777 is smooth (no spike to 5.9e13 Pa)", "[water_flash][1730]") {
    // Issue #1730: PropsSI('P','H',3133800,'S',6777,'Water') previously
    // returned ~5.9e13 Pa while the neighbouring points returned ~2.97 MPa.
    // The HS flash now converges smoothly. Lock down the original three
    // reproducer points plus a handful around them.
    for (double H : {3132000.0, 3133000.0, 3133500.0, 3133800.0, 3134000.0, 3135000.0}) {
        CAPTURE(H);
        const double p = CoolProp::PropsSI("P", "H", H, "S", 6777.0, "Water");
        CAPTURE(p);
        CHECK(std::isfinite(p));
        CHECK(p > 0);
        CHECK(p < 1e8);
        CHECK(std::abs(p - 2.97e6) / 2.97e6 < 0.02);
    }
}

TEST_CASE("Saturation ancillary returns NaN above T_r instead of UB / SIGFPE (#1611)", "[ancillary][1611]") {
    // Issue #1611: pow(THETA, t) with THETA = 1 - T/T_r < 0 was
    // pow(negative, fractional) which produced NaN and (depending on
    // FP trap settings) sometimes a SIGFPE that escaped C++ try/catch.
    // Internal callers (mixture critical-point search, VLE init) probe
    // ancillaries above the pure-component T_r and rely on getting a
    // well-behaved value back, so the guard returns NaN explicitly
    // (no UB, no SIGFPE) instead of throwing.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "R134a"));
    auto& heos = *dynamic_cast<CoolProp::HelmholtzEOSMixtureBackend*>(AS.get());
    auto& fluid = heos.get_components()[0];
    double Tcrit = AS->T_critical();

    // Direct ancillary evaluation a few K above the reducing T returns
    // NaN cleanly (no SIGFPE, no UB).
    CHECK(std::isnan(fluid.ancillaries.pL.evaluate(Tcrit + 5.0)));
    CHECK(std::isnan(fluid.ancillaries.pV.evaluate(Tcrit + 5.0)));
    CHECK(std::isnan(fluid.ancillaries.rhoL.evaluate(Tcrit + 5.0)));
    CHECK(std::isnan(fluid.ancillaries.rhoV.evaluate(Tcrit + 5.0)));
    // Comfortably below T_r still produces finite values
    CHECK(std::isfinite(fluid.ancillaries.pL.evaluate(0.95 * Tcrit)));
    CHECK(std::isfinite(fluid.ancillaries.pL.evaluate(0.5 * Tcrit)));

    // The original user-facing reproducer no longer crashes
    // (PropsSI returns NaN with errstring set rather than SIGFPE).
    CHECK_NOTHROW(CoolProp::PropsSI("T", "P", 4863285.0, "Q", 0.0, "HEOS::R407C"));
    CHECK_NOTHROW(CoolProp::PropsSI("T", "P", 1.0e6, "Q", 0.0, "HEOS::R407C"));
}

TEST_CASE("INCOMP psat throws below TminPsat instead of returning 0 silently (#2209)", "[INCOMP][2209]") {
    // Issue #2209: PropsSI('P','Q',0,'T',373,'INCOMP::MEG[0.1]') returned
    // 0.0 because MEG.json has TminPsat=373.15 (which equals Tmax for
    // this fluid, leaving no usable Psat range below the upper bound)
    // and psat() silently returned 0.0 below TminPsat. Now throw a
    // ValueError so PropsSI surfaces a non-finite return AND populates
    // errstring rather than returning a misleading 0.
    const double v = CoolProp::PropsSI("P", "Q", 0, "T", 373.0, "INCOMP::MEG[0.1]");
    CHECK(!ValidNumber(v));
    const std::string err = CoolProp::get_global_param_string("errstring");
    CAPTURE(err);
    CHECK(err.find("TminPsat") != std::string::npos);
    // LiBr has TminPsat = 273.15 so T=373 is above it and still works
    const double v2 = CoolProp::PropsSI("P", "Q", 0, "T", 373.0, "INCOMP::LiBr[0.1]");
    CHECK(ValidNumber(v2));
    CHECK(v2 > 0);
}
TEST_CASE("Incompressible enthalpy is finite and continuous at T == Tbase (#1578)", "[INCOMP][1578]") {
    // Issue #1578: PropsSI for incompressible fluids used to throw "A fraction
    // cannot be evaluated with zero as denominator" whenever the requested
    // temperature equalled the fluid's Tbase (so x_in - x_base == 0). For most
    // fluids that is a single unlucky point, but Antifrogen N/L (AN/AL) have
    // Tbase == 293.15 K, which is also their reference temperature, so
    // enthalpy/entropy failed for *every* state. The singularity is now handled
    // by L'Hopital-style interpolation in Polynomial2DFrac::evaluate; this guards
    // against the throw returning.
    const double p = 101325.0;
    // (fluid name, Tbase [K]) pairs taken straight from the issue report.
    struct Case
    {
        std::string name;
        double Tbase;
    };
    const std::vector<Case> cases = {
      {"INCOMP::AS30", 273.15},    // single-point case from the issue
      {"INCOMP::TD12", 345.65},    // single-point case from the issue
      {"INCOMP::AN-30%", 293.15},  // Antifrogen N: Tbase == Tref, failed for all T
      {"INCOMP::AL-30%", 293.15},  // Antifrogen L: Tbase == Tref, failed for all T
    };
    for (const Case& c : cases) {
        const double dT = 0.1;
        double h_lo = 0, h_mid = 0, h_hi = 0;
        CHECK_NOTHROW(h_lo = CoolProp::PropsSI("Hmass", "T", c.Tbase - dT, "P", p, c.name));
        CHECK_NOTHROW(h_mid = CoolProp::PropsSI("Hmass", "T", c.Tbase, "P", p, c.name));
        CHECK_NOTHROW(h_hi = CoolProp::PropsSI("Hmass", "T", c.Tbase + dT, "P", p, c.name));
        CAPTURE(c.name);
        CAPTURE(c.Tbase);
        CAPTURE(h_lo);
        CAPTURE(h_mid);
        CAPTURE(h_hi);
        CAPTURE(CoolProp::get_global_param_string("errstring"));
        REQUIRE(ValidNumber(h_mid));
        // Enthalpy is ~linear in T over a 0.2 K window (cp is locally constant),
        // so the value at Tbase must equal the midpoint of its neighbours: this
        // catches a spike/dropout if the singular point is mishandled. The bound
        // is on the linearity residual (curvature ~ d(cp)/dT * dT^2), not the
        // slope (~cp*dT ~ 400 J/kg); 1.0 J/kg leaves a wide margin.
        const double midpoint = 0.5 * (h_lo + h_hi);
        CHECK(std::abs(h_mid - midpoint) < 1.0);  // [J/kg]
    }
}
TEST_CASE("Incompressible MPG2 viscosity matches Melinder source data (#1374)", "[INCOMP][1374]") {
    // Issue #1374: the fitted viscosity (and hence Prandtl number) of MPG2
    // (Melinder propylene glycol) was a uniform factor of 10 too small versus
    // MPG/APG and every other propylene-glycol fluid. Root cause: the
    // exp-polynomial constant term in MPG2.json was off by ln(10), so
    // viscosity = exp(poly) came out 10x low everywhere. The reference values
    // below are the Melinder propylene-glycol viscosity table
    // (dev/incompressible_liquids/CPIncomp/data/SecCool/xMass/"Melinder,
    // Propylene Glycol_Mu.txt") scaled by viscosityFactor = 1e-5 to obtain
    // Pa*s, sampled at exact (T, x) grid points where the fit reproduces it.
    const double p = 101325.0;
    const double rel = 0.01;  // 1% relative; pre-fix the values were ~90% low
    struct Pt
    {
        double T, x, mu;
    };
    // T [K], x = mass fraction, mu = dynamic viscosity [Pa*s]
    const std::vector<Pt> pts = {
      {283.15, 0.42, 742.1231823e-5},  // 10 C, 42%
      {283.15, 0.52, 1137.598557e-5},  // 10 C, 52%
      {283.15, 0.57, 1443.949841e-5},  // 10 C, 57%
      {303.15, 0.42, 326.47355e-5},    // 30 C, 42%
      {303.15, 0.52, 456.9447475e-5},  // 30 C, 52%
    };
    for (const Pt& pt : pts) {
        const std::string name = "INCOMP::MPG2" + format("[%f]", pt.x);
        const double actual = CoolProp::PropsSI("V", "T", pt.T, "P", p, name);
        CAPTURE(pt.T);
        CAPTURE(pt.x);
        CAPTURE(pt.mu);
        CAPTURE(actual);
        CAPTURE(CoolProp::get_global_param_string("errstring"));
        CHECK(check_abs(pt.mu, actual, rel));
    }
    // The Prandtl number reported in #1374 should be ~100 (like MPG/APG), not ~10.
    const double Pr = CoolProp::PropsSI("PRANDTL", "T", 283.15, "P", p, "INCOMP::MPG2[0.5]");
    CAPTURE(Pr);
    CHECK(Pr > 80.0);
}
TEST_CASE("PropsSImulti with empty input vectors returns empty result instead of segfaulting", "[PropsSImulti][2417]") {
    // Issue #2417: PropsSI('T','P',[],'Q',[],'Ammonia') segfaulted because
    // _PropsSI_outputs forced N1 = max(1, in1.size()) and then dereferenced
    // in1[0] / in2[0]. Empty inputs must now return an empty IO matrix.
    std::vector<std::string> outputs{"T"};
    std::vector<std::string> fluids{"Ammonia"};
    std::vector<double> fractions{1.0};
    std::vector<double> p_empty;
    std::vector<double> q_empty;
    auto IO = CoolProp::PropsSImulti(outputs, "P", p_empty, "Q", q_empty, "HEOS", fluids, fractions);
    CHECK(IO.empty());
    // And the non-empty path still works
    std::vector<double> p_one{101325.0};
    std::vector<double> q_one{0.0};
    auto IO2 = CoolProp::PropsSImulti(outputs, "P", p_one, "Q", q_one, "HEOS", fluids, fractions);
    REQUIRE(IO2.size() == 1);
    REQUIRE(IO2[0].size() == 1);
    CHECK(IO2[0][0] > 0);
}
TEST_CASE("first_saturation_deriv mixture: dT/dP via Gernert vs finite-difference along bubble curve", "[first_saturation_deriv][2091]") {
    // Issue #2091: the mixture path used the pure-fluid Clapeyron
    // expression (T*Δv / Δh) and silently returned wrong values.
    // The fix uses Gernert thesis 3.96/3.97 weighted by the OTHER
    // phase's compositions.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Methane&Ethane"));
    AS->set_mole_fractions({0.7, 0.3});

    double T = 180.0;
    AS->update(CoolProp::QT_INPUTS, 0.0, T);
    double dTdP = AS->first_saturation_deriv(CoolProp::iT, CoolProp::iP);

    // Finite difference along Q=0 (bubble) curve
    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Methane&Ethane"));
    AS2->set_mole_fractions({0.7, 0.3});
    double dT = 0.05;
    AS2->update(CoolProp::QT_INPUTS, 0.0, T + dT);
    double pP = AS2->p();
    AS2->update(CoolProp::QT_INPUTS, 0.0, T - dT);
    double pM = AS2->p();
    double dTdP_fd = (2 * dT) / (pP - pM);

    CAPTURE(dTdP);
    CAPTURE(dTdP_fd);
    CHECK(dTdP > 0);
    CHECK(std::abs(dTdP - dTdP_fd) / std::abs(dTdP_fd) < 5e-3);
}

TEST_CASE("first_saturation_deriv mixture: throws at intermediate Q", "[first_saturation_deriv][2091]") {
    // Two-phase intermediate quality is not on a single saturation curve
    // for mixtures; the new code throws (was previously silently wrong).
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Methane&Ethane"));
    AS->set_mole_fractions({0.7, 0.3});
    AS->update(CoolProp::QT_INPUTS, 0.5, 180.0);
    CHECK_THROWS(AS->first_saturation_deriv(CoolProp::iT, CoolProp::iP));
}

TEST_CASE("Two-phase chemical_potential mirrors sat-state values; fugacity_coefficient throws", "[mixtures][2345-followup]") {
    // Follow-up to PR #2345: calc_chemical_potential and calc_fugacity_coefficient
    // were calling MixtureDerivatives::* directly on the overall homogeneous state,
    // which is meaningless inside the two-phase dome.
    //   - mu_i^L == mu_i^V at VLE (the equilibrium condition), so the new code
    //     returns the Q-weighted sat-state value, which collapses to either
    //     endpoint up to flash tolerance.
    //   - phi_i^L != phi_i^V because the phase compositions differ; the new
    //     code throws to force callers to evaluate on SatL/SatV explicitly.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Methane&Ethane&Propane"));
    AS->set_mole_fractions({0.25, 0.25, 0.5});
    AS->update(CoolProp::PQ_INPUTS, 500e3, 0.5);
    REQUIRE(AS->phase() == CoolProp::iphase_twophase);

    auto* heos_ptr = dynamic_cast<CoolProp::HelmholtzEOSMixtureBackend*>(AS.get());
    REQUIRE(heos_ptr != nullptr);
    auto& satL = heos_ptr->get_SatL();
    auto& satV = heos_ptr->get_SatV();

    for (std::size_t i = 0; i < 3; ++i) {
        CAPTURE(i);
        // chemical_potential: mu_i^L == mu_i^V at VLE
        const double mu = AS->chemical_potential(i);
        const double muL = satL.chemical_potential(i);
        const double muV = satV.chemical_potential(i);
        CHECK(std::isfinite(mu));
        // sat-state pair equal up to flash tolerance
        CHECK(std::abs(muL - muV) < 1e-4 * std::abs(muL));
        // overall == Q-weighted combination of sat states (Q=0.5)
        CHECK(std::abs(mu - 0.5 * (muL + muV)) < 1e-9 * std::abs(0.5 * (muL + muV)));

        // fugacity_coefficient throws in two-phase
        CHECK_THROWS(AS->fugacity_coefficient(i));
        // but works on the sat states
        CHECK(std::isfinite(satL.fugacity_coefficient(i)));
        CHECK(std::isfinite(satV.fugacity_coefficient(i)));
    }
}

TEST_CASE("HAPropsSI Twb at high T (T > Tsat) returns the physical root (#2255)", "[HAPropsSI][2255]") {
    // Issue #2255: HAPropsSI('Twb','T',200+273.15,'W',0.2,'P',1000E3)
    // returned 180.7241 C (essentially Tsat at 1 MPa) instead of the
    // correct ~131 C. The wet-bulb residual function is meaningless
    // for Twb > Tsat(p) (W_s_wb goes negative), and the Brent solver
    // converged to a spurious "root" at the upper bracket.
    const double Twb_K = HumidAir::HAPropsSI("Twb", "T", 200 + 273.15, "W", 0.2, "P", 1.0e6);
    const double Twb_C = Twb_K - 273.15;
    CAPTURE(Twb_C);
    // Expected physical root is ~130-131 C; the buggy value was 180.72 C
    CHECK(Twb_C > 125.0);
    CHECK(Twb_C < 135.0);

    // Smoothness across the discontinuity reported by the second commenter:
    // Sweep T at fixed W=0.05, P=1 atm and verify Twb is monotonic and finite.
    double prev = -1.0;
    for (double T_C : {100.0, 105.0, 110.0, 115.0, 120.0, 130.0, 150.0, 200.0, 250.0, 300.0}) {
        const double Twb = HumidAir::HAPropsSI("Twb", "T", T_C + 273.15, "W", 0.05, "P", 101325.0) - 273.15;
        CAPTURE(T_C);
        CAPTURE(Twb);
        CHECK(std::isfinite(Twb));
        CHECK(Twb > 0);
        CHECK(Twb < T_C);  // wet bulb must be below dry bulb
        if (prev > 0) {
            // monotone increasing across the sweep (within fp tolerance)
            CHECK(Twb >= prev - 1e-6);
        }
        prev = Twb;
    }
}
TEST_CASE("HAPropsSI T_db from (T_wb, RelHum, P) — issue #2690 surviving failure modes", "[HAPropsSI][humid_air][2690]") {
    // Issue #2690: HAPropsSI('T_db','T_wb',T_wb,'RelHum',RH,'P',P) returned
    // "Temperature value (inf)" for narrow pressure bands at very low RH.
    // A reporter sweep (td.xlsx, May 2026) decomposes the failures into
    // distinct modes. The b3360b8c6 fix for #2255 (Twb solver bracket
    // handling) already addressed the bulk of the originally-reported
    // bands. This test pins the two surviving modes addressed in this PR.

    SECTION("Mode B — Tsat(p) crossing isolated outliers") {
        // The inner WetbulbTemperature historically used Tupper = Tmax + 1.
        // For T just below Tsat(p), this Tupper crosses Tsat and Brent steps
        // hit the W_s_wb singularity (p_ws_wb -> p, denominator -> 0).
        // The fix tightens Tupper to std::min(Tmax + 1, Tsat - 1e-3).
        const double T_db_a = HumidAir::HAPropsSI("T_db", "T_wb", 30 + 273.15, "RelHum", 1e-5, "P", 97950.0);
        CAPTURE(T_db_a);
        CHECK(std::isfinite(T_db_a));
        CHECK(T_db_a > 30 + 273.15);   // T_db must exceed T_wb
        CHECK(T_db_a < 200 + 273.15);  // and stay within HVAC range

        const double T_db_b = HumidAir::HAPropsSI("T_db", "T_wb", 28 + 273.15, "RelHum", 1e-4, "P", 87550.0);
        CAPTURE(T_db_b);
        CHECK(std::isfinite(T_db_b));
        CHECK(T_db_b > 28 + 273.15);
    }

    SECTION("Mode A — pressure-band cases incidentally fixed by b3360b8c6 stay green") {
        // Sample points from the reporter's failing band on CoolProp 7.2.0.
        // These passed once b3360b8c6 landed; pin them so the new Tupper
        // clamp (Mode B fix) doesn't accidentally regress them.
        for (double P : {90200.0, 90550.0, 90700.0, 91000.0, 91100.0, 91024.0}) {
            const double T_db = HumidAir::HAPropsSI("T_db", "T_wb", 30 + 273.15, "RelHum", 1e-5, "P", P);
            CAPTURE(P);
            CAPTURE(T_db);
            CHECK(std::isfinite(T_db));
            CHECK(T_db > 30 + 273.15);
            CHECK(T_db < 200 + 273.15);
        }
    }

    SECTION("Mode C — physically infeasible inputs surface a clear error, not 'inf'") {
        // At T_wb >= ~55 C with RH <= 1e-4 the wet-bulb energy balance
        // implies T_db > 500 K, beyond the validity of the humid-air
        // mixture model. The previous behavior was an opaque
        // "Temperature value (inf)" from check_bounds at the bounds-check
        // boundary. The fix detects infeasibility upfront and throws a
        // CoolProp::ValueError whose message names T_wb / RelHum / P /
        // T_db_estimate. HAPropsSI catches all exceptions and returns _HUGE,
        // so we verify (a) the result is not a valid number and (b) the
        // diagnostic error string contains the new message — not the old
        // misleading "outside the range of validity" wording.
        const double r1 = HumidAir::HAPropsSI("T_db", "T_wb", 60 + 273.15, "RelHum", 1e-5, "P", 90000.0);
        CHECK_FALSE(ValidNumber(r1));
        const std::string err1 = CoolProp::get_global_param_string("errstring");
        CAPTURE(err1);
        CHECK(err1.find("beyond the validity range") != std::string::npos);

        const double r2 = HumidAir::HAPropsSI("T_db", "T_wb", 65 + 273.15, "RelHum", 1e-4, "P", 95000.0);
        CHECK_FALSE(ValidNumber(r2));
        const std::string err2 = CoolProp::get_global_param_string("errstring");
        CAPTURE(err2);
        CHECK(err2.find("beyond the validity range") != std::string::npos);
    }

    SECTION("Reporter sweep (td.xlsx) — Modes B+C clean, Mode D out of scope") {
        // Abbreviated replay of the reporter's sweep over (RH, T_wb, P).
        // After this PR, for T_wb >= 5 °C every point should either
        // (a) return a finite T_db, or (b) surface the explicit
        // "beyond the validity range" Mode C infeasibility error —
        // never the misleading "Temperature value (inf)" of the prior
        // code path. Mode D (sub-freezing T_wb=0 °C) is a separate
        // failure mechanism and is explicitly excluded from this PR.
        int unexpected_failures_above_freezing = 0;
        int mode_c_above_freezing = 0;
        int fail_at_freezing = 0;
        const double T_wbs[] = {0, 5, 10, 15, 20, 25, 28, 29, 30, 31, 32, 35, 40, 45, 50, 55, 60, 65};
        const double RHs[] = {0.01, 1e-3, 1e-4, 1e-5};
        for (double RH : RHs) {
            for (double T_wb_C : T_wbs) {
                for (int P = 87000; P < 99000; P += 250) {  // step 250 keeps test ~< 1s
                    const double v = HumidAir::HAPropsSI("T_db", "T_wb", T_wb_C + 273.15, "RelHum", RH, "P", (double)P);
                    if (!ValidNumber(v)) {
                        if (T_wb_C == 0) {
                            ++fail_at_freezing;
                        } else {
                            const std::string err = CoolProp::get_global_param_string("errstring");
                            if (err.find("beyond the validity range") != std::string::npos) {
                                ++mode_c_above_freezing;
                            } else {
                                ++unexpected_failures_above_freezing;
                            }
                        }
                    }
                }
            }
        }
        CAPTURE(unexpected_failures_above_freezing);
        CAPTURE(mode_c_above_freezing);
        CAPTURE(fail_at_freezing);
        // Modes A+B: zero unexpected failures above freezing.
        CHECK(unexpected_failures_above_freezing == 0);
        // Mode C: the infeasibility detector should fire for at least the
        // T_wb >= 60 °C low-RH points; confirms the throw path is wired up.
        CHECK(mode_c_above_freezing > 0);
        // Mode D: sub-freezing failures still exist (out of scope here).
        CHECK(fail_at_freezing > 0);
    }

    SECTION("Regression guard — #2697 high-pressure Twb cases must still work") {
        // PR #2697 was reverted because raising T_max unconditionally to 640 K
        // broke ASHRAE A.8/A.9-style high-pressure wet-bulb computations.
        // Re-pin a representative high-P Twb case to catch a repeat over-correction.
        const double Twb = HumidAir::HAPropsSI("Twb", "T", 200 + 273.15, "W", 0.05, "P", 5.0e6);
        CAPTURE(Twb);
        CHECK(std::isfinite(Twb));
        CHECK(Twb > 100 + 273.15);
        CHECK(Twb < 250 + 273.15);
    }
}

TEST_CASE("HAPropsSI T_db from T_wb near the water triple point — issue #2906", "[HAPropsSI][humid_air][2906]") {
    // Issue #2906 (follow-up to #2690). Near 273.16 K the wet-bulb energy
    // balance in WetBulbSolver is discontinuous: h_w jumps by the latent heat
    // of fusion (~333 kJ/kg) as the saturant wick switches liquid<->ice, so the
    // forward map Twb(T_db) skips a band of wet-bulb temperatures (widest at low
    // RH, vanishing by RH ~ 0.7). For a target T_wb inside that band there is no
    // dry-bulb solution. The old solver handled this badly two ways: a scattered
    // set returned the opaque "Temperature value (inf)", but MOST of the band was
    // worse — the outer Brent latched onto the discontinuity T_db* and returned a
    // T_db whose actual wet-bulb was NOT the request (a silently-wrong "flat
    // section"). The fix verifies the solved T_db reproduces the requested T_wb
    // and otherwise throws a clean infeasibility naming the triple point.

    SECTION("No silently-wrong result: every finite T_db reproduces the requested T_wb") {
        // Core invariant. Sweep target T_wb through the gap region across RH and
        // a WIDE pressure range; any finite T_db must be self-consistent (its
        // forward wet-bulb equals the request), and unreachable targets must
        // surface a clean 'triple point' error — never the opaque "(inf)" and
        // never a wrong number. The band is widest at low pressure (reaching
        // ~1.2 K above the triple point near 20-30 kPa), so the T_wb sweep
        // extends to +1.5 C and pressures down to 20 kPa to exercise it.
        int valid = 0, errored_clean = 0, bad = 0;
        for (double RH : {0.01, 0.1, 0.5}) {
            for (int i = 0; i <= 42; ++i) {  // T_wb from -0.6 to +1.5 C in 0.05 C steps
                const double twb_C = -0.6 + 0.05 * i;
                for (int P = 20000; P <= 98000; P += 13000) {
                    const double tdb = HumidAir::HAPropsSI("T_db", "T_wb", twb_C + 273.15, "RelHum", RH, "P", (double)P);
                    if (ValidNumber(tdb)) {
                        const double back = HumidAir::HAPropsSI("Twb", "T", tdb, "RelHum", RH, "P", (double)P) - 273.15;
                        if (ValidNumber(back) && std::abs(back - twb_C) <= 1e-2)  // match the production guard's 1e-2 K contract
                            ++valid;
                        else
                            ++bad;  // silently-wrong T_db
                    } else {
                        const std::string err = CoolProp::get_global_param_string("errstring");
                        if (err.find("triple point") != std::string::npos)
                            ++errored_clean;
                        else
                            ++bad;  // opaque "(inf)" or other unexpected failure
                    }
                }
            }
        }
        CAPTURE(valid);
        CAPTURE(errored_clean);
        CAPTURE(bad);
        CHECK(bad == 0);           // no silently-wrong T_db, no opaque inf
        CHECK(valid > 0);          // reachable targets solve
        CHECK(errored_clean > 0);  // the genuine gap is reported cleanly
    }

    SECTION("Reachable wet-bulbs on both branches still solve") {
        // Ice branch (T_wb < 0 C) and liquid branch (T_wb > 0 C), away from the
        // gap, must keep returning a finite, self-consistent T_db.
        for (double tw : {-5.0, -0.5, 1.0, 5.0}) {
            const double tdb = HumidAir::HAPropsSI("T_db", "T_wb", tw + 273.15, "RelHum", 0.5, "P", 101325.0);
            CAPTURE(tw);
            CHECK(std::isfinite(tdb));
            CHECK(tdb >= tw + 273.15 - 1e-6);  // dry-bulb is never below wet-bulb
        }
    }

    SECTION("Canonical T_wb = 0 C failing pressures error cleanly, never opaque 'inf'") {
        // The reporter's headline case: at exactly 0 C a scattered set of P is in
        // the gap. Those must surface the explicit triple-point message; none may
        // leak the old "(inf)" wording.
        int clean = 0, opaque = 0, unexpected = 0;
        for (int P = 87000; P < 99000; P += 50) {
            const double v = HumidAir::HAPropsSI("T_db", "T_wb", 273.15, "RelHum", 0.01, "P", (double)P);
            if (ValidNumber(v)) {
                continue;
            }
            const std::string err = CoolProp::get_global_param_string("errstring");
            if (err.find("triple point") != std::string::npos)
                ++clean;
            else if (err.find("(inf)") != std::string::npos)
                ++opaque;
            else
                ++unexpected;  // any other failure text is an unrecognized regression
        }
        CAPTURE(clean);
        CAPTURE(opaque);
        CAPTURE(unexpected);
        CHECK(clean > 0);
        CHECK(opaque == 0);
        CHECK(unexpected == 0);
    }
}

TEST_CASE("Out-of-range Q in update() does not corrupt cached state (#2195)", "[update][2195]") {
    // Issue #2195: PQ_INPUTS / QT_INPUTS / etc. assigned _Q = value
    // BEFORE validating the range, so a thrown OutOfRangeError left _Q at
    // the bad value (e.g. 1.1). A subsequent hmass() call then computed
    //   _hmolar = _Q * SatV->hmolar() + (1 - _Q) * SatL->hmolar()
    // with _Q = 1.1, returning a meaningless extrapolated number that
    // looked plausible. The fix validates first; on throw the state is
    // either left clean or surfaces NaN, never a misleading finite value.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));
    AS->update(CoolProp::PQ_INPUTS, 10e6, 0.5);
    const double h_legal = AS->hmass();
    CHECK(std::isfinite(h_legal));
    CHECK(h_legal > 1e6);

    CHECK_THROWS(AS->update(CoolProp::PQ_INPUTS, 10e6, 1.1));
    // After the failed update, hmass must NOT silently return a finite
    // value computed from the bad Q. NaN is acceptable (cleared cache);
    // the legal cached value is also acceptable.
    const double h_after = AS->hmass();
    CAPTURE(h_after);
    CHECK((!std::isfinite(h_after) || h_after == h_legal));

    CHECK_THROWS(AS->update(CoolProp::PQ_INPUTS, 10e6, -0.1));
    CHECK_THROWS(AS->update(CoolProp::QT_INPUTS, 1.5, 400.0));
    CHECK_THROWS(AS->update(CoolProp::QT_INPUTS, -0.5, 400.0));
}
TEST_CASE("Water below 0 C at atmospheric pressure is not silently labelled liquid (#1098)", "[water_phase][1098]") {
    // Issue #1098 (2017): PhaseSI returned "liquid" for water at T=-5 C,
    // P=1 atm. The HEOS solid path is not implemented but the response
    // should at least not be a misleading "liquid". On current master
    // PhaseSI returns "unknown: ..." with a helpful "T below Tmelt(p)"
    // message and PropsSI("Phase",...) throws. Pin both behaviours so
    // the original silent-"liquid" failure mode cannot return.
    const std::string phase = CoolProp::PhaseSI("T", 273.15 - 5, "P", 101325.0, "Water");
    CAPTURE(phase);
    CHECK(phase != "liquid");
    CHECK(phase != "twophase");
    CHECK(phase != "gas");
    // PropsSI("Phase", ...) catches the underlying ValueError and surfaces
    // it as a non-finite return + populated errstring (Cython then raises).
    const double v = CoolProp::PropsSI("Phase", "T", 273.15 - 5, "P", 101325.0, "Water");
    CHECK(!ValidNumber(v));
}

TEST_CASE("DmassSmass round-trip on the dew curve preserves enthalpy (#1907)", "[water_flash][1907]") {
    // Issue #1907: looping along the saturated-vapor curve and
    // re-flashing each (D, S) pair produced wildly inconsistent
    // enthalpies. Root cause was that HSU_D_flash assigned _T to the
    // converged temperature without re-evaluating alphar at that T,
    // leaving the alphar-derivative cache from the LAST solver
    // iteration. Subsequent h/s/p queries used stale derivatives.
    //
    // Walk densities along the dew curve, capture (h_dew, s_dew),
    // re-flash via DmassSmass and verify hmass agrees.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "water"));
    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "water"));
    // Avoid densities near rho_crit where DmassQ has multiple T-roots — the
    // post-#2835 strict path raises MultipleSolutionsError there. The low-d
    // / falling-branch densities below are unique-root.
    for (double d : {200.0, 175.0, 130.0, 70.0, 30.0, 15.126, 11.141, 5.0}) {
        CAPTURE(d);
        AS->update(CoolProp::DmassQ_INPUTS, d, 1.0);
        const double T_dew = AS->T();
        const double h_dew = AS->hmass();
        const double s_dew = AS->smass();
        const double p_dew = AS->p();

        AS2->update(CoolProp::DmassSmass_INPUTS, d, s_dew);
        CAPTURE(T_dew);
        CAPTURE(h_dew);
        CAPTURE(s_dew);
        CAPTURE(AS2->T());
        CAPTURE(AS2->hmass());
        CAPTURE(AS2->smass());
        CHECK(std::abs(AS2->T() - T_dew) / T_dew < 1e-6);
        CHECK(std::abs(AS2->hmass() - h_dew) / h_dew < 1e-3);
        CHECK(std::abs(AS2->smass() - s_dew) / s_dew < 1e-6);
        CHECK(std::abs(AS2->p() - p_dew) / p_dew < 1e-3);
    }
}

TEST_CASE("D+{H,S,U} round-trip for sub-triple compressed-liquid water (CoolProp-lgk)", "[water_flash][HSU_D_subtriple][lgk]") {
    // Dense liquid water exists below the triple-point temperature (273.16 K)
    // wherever the state is above the melting curve Tmelt(p): ~266 K at 100 MPa,
    // down toward ~251 K near the 209 MPa melting minimum.  IAPWS-95 is valid
    // there, so a density+caloric flash must round-trip these compressed-liquid
    // states.  Previously PHSU_D_flash bracketed the single-phase T-search at
    // [Ttriple, Tmax*1.5] and threw "D < DLtriple" for any state colder than the
    // triple-point isochore (i.e. all T < Ttriple), even above the melting line.
    auto ref = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));
    auto rt = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Water"));
    const double Tt = Props1SI("Water", "Ttriple");

    const CoolProp::input_pairs pair = GENERATE(CoolProp::DmassHmass_INPUTS, CoolProp::DmassSmass_INPUTS, CoolProp::DmassUmass_INPUTS);
    CAPTURE(static_cast<int>(pair));

    for (double p : {100e6, 150e6, 200e6}) {
        const double Tmelt = ref->melting_line(CoolProp::iT, CoolProp::iP, p);
        CAPTURE(p, Tmelt, Tt);
        // The sampled band is [Tmelt+1, Tt-0.5]; require it non-inverted so the
        // sweep genuinely lands below the triple point (not a vacuous pass).
        REQUIRE(Tmelt + 1.0 < Tt - 0.5);
        // Strictly above the melting curve, strictly below the triple point.
        for (double T : linspace(Tmelt + 1.0, Tt - 0.5, 6)) {
            CAPTURE(T);
            ref->update(CoolProp::PT_INPUTS, p, T);
            const double d = ref->rhomass();
            double other = 0;
            switch (pair) {
                case CoolProp::DmassHmass_INPUTS:
                    other = ref->hmass();
                    break;
                case CoolProp::DmassSmass_INPUTS:
                    other = ref->smass();
                    break;
                default:
                    other = ref->umass();
                    break;
            }
            CAPTURE(d, other);
            REQUIRE_NOTHROW(rt->update(pair, d, other));
            CHECK(rt->rhomass() == Catch::Approx(d).epsilon(1e-5));
            CHECK(rt->T() == Catch::Approx(T).epsilon(1e-4));
        }
    }

    // Deep point near the melting-curve minimum (~251.2 K at ~208.5 MPa, the
    // coldest liquid water attainable).  A coarse-scan-only floor lands ~1 K
    // high (~252.3 K) and would wrongly reject this valid liquid state; the
    // refined two-stage melting-minimum search must round-trip it.
    {
        const double p = 208.5e6;
        const double Tmelt = ref->melting_line(CoolProp::iT, CoolProp::iP, p);
        const double T = Tmelt + 0.5;  // valid liquid just above the melting line, well below Ttriple
        REQUIRE(T < Tt);
        ref->update(CoolProp::PT_INPUTS, p, T);
        const double d = ref->rhomass();
        const double other = (pair == CoolProp::DmassHmass_INPUTS)   ? ref->hmass()
                             : (pair == CoolProp::DmassSmass_INPUTS) ? ref->smass()
                                                                     : ref->umass();
        CAPTURE(p, Tmelt, T, d, other);
        REQUIRE_NOTHROW(rt->update(pair, d, other));
        CHECK(rt->rhomass() == Catch::Approx(d).epsilon(1e-5));
        CHECK(rt->T() == Catch::Approx(T).epsilon(1e-4));
    }
}

TEST_CASE("REFPROP DmolarSmolar honours imposed phase (#2042)", "[REFPROP][2042]") {
    CoolProp::Skip_if_No_REFPROP();
    // Issue #2042: a multi-component natural-gas mixture with phase
    // imposed to gas via specify_phase still routed through DSFLSH ->
    // DSFL2, which threw "2-phase iteration did not converge". Imposed
    // single-phase now uses DSFL1 + THERMdll directly.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(
      CoolProp::AbstractState::factory("REFPROP", "METHANE&ETHANE&PROPANE&BUTANE&ISOBUTAN&PENTANE&IPENTANE&HEXANE&NITROGEN&H2S&CO2"));
    AS->set_mole_fractions({0.30241, 0.03639, 0.02119, 0.007, 0.0031, 0.0039, 0.0015, 0.0008, 0.0025, 0.0002, 0.62101});
    AS->update(CoolProp::PT_INPUTS, 14500000.0, 315.35);
    const double rho_in = 405.4197781472575;
    const double s_in = 2004.9031527899563;
    AS->specify_phase(CoolProp::iphase_gas);
    REQUIRE_NOTHROW(AS->update(CoolProp::DmassSmass_INPUTS, rho_in, s_in));
    CHECK(std::abs(AS->rhomass() - rho_in) / rho_in < 1e-6);
    CHECK(AS->T() > 0);
    CHECK(AS->p() > 0);
}

TEST_CASE("change_EOS rejects unknown EOS name", "[change_EOS][1703]") {
    // Issue #1703: change_EOS used to silently no-op for unrecognized
    // EOS names; it now throws. Valid names (SRK, Peng-Robinson,
    // XiangDeiters) must still work; an out-of-range index must still throw.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "CO2"));
    CHECK_THROWS(AS->change_EOS(0, "kdsfakhds"));
    CHECK_THROWS(AS->change_EOS(0, ""));
    CHECK_THROWS(AS->change_EOS(99, "SRK"));
    CHECK_NOTHROW(AS->change_EOS(0, "SRK"));
    CHECK_NOTHROW(AS->change_EOS(0, "Peng-Robinson"));
    CHECK_NOTHROW(AS->change_EOS(0, "XiangDeiters"));
}

TEST_CASE("Ammonia d(U)/d(P)|sigma at P=60110.77... is finite (#2244)", "[ammonia][2244]") {
    // Issue #2244: PropsSI('d(U)/d(P)|sigma','P',60110.7723310773,'Q',0,
    // 'Ammonia') used to throw while neighbouring P values worked.
    // The exact reproducer plus a small bracket are now all smooth on
    // current master; pin them so the boundary condition stays fixed.
    const double P = 60110.7723310773;
    for (double dP : {-0.001, 0.0, 0.001}) {
        CAPTURE(dP);
        const double v = CoolProp::PropsSI("d(U)/d(P)|sigma", "P", P + dP, "Q", 0, "Ammonia");
        CAPTURE(v);
        CHECK(std::isfinite(v));
        CHECK(v > 1.0);
        CHECK(v < 2.0);  // expected ~1.33
    }
}

TEST_CASE("Ammonia (R717) PT_INPUTS in superheated vapor returns valid enthalpy (#2461)", "[ammonia][R717][2461]") {
    // Issue #2461: a chained PropsSI workflow on R717 (ammonia) at
    // P=130000 Pa, T=Tsat+2K threw "options.T is not valid in
    // saturation_P_pure_1D_T". On current master the same calls
    // succeed; pin the PT path that the user's original code exercises.
    const double P_low = 1.3e5;
    const double T_sat = CoolProp::PropsSI("T", "P", P_low, "Q", 1, "R717");
    const double T_evap = T_sat + 2.0;  // 2 K superheat
    const double h = CoolProp::PropsSI("H", "P", P_low, "T", T_evap, "R717");
    CAPTURE(T_sat);
    CAPTURE(T_evap);
    CAPTURE(h);
    CHECK(std::isfinite(h));
    // Superheated ammonia at near-atmospheric P has h around 1.5e6 J/kg
    CHECK(h > 1.4e6);
    CHECK(h < 1.7e6);
}

// GitHub #2773: saturation flashes can have multiple T solutions for the same
// (h | s | rho, Q) input. update_with_guesses now uses guess.T to pick the
// branch via TOMS748 rootfinding inside each provably-monotonic Chebyshev
// sub-interval of the saturation superancillary. h_sat and s_sat
// superancillaries are built lazily on first use against the EOS in its
// current configuration.
TEST_CASE("DmolarQ branch selection via guess.T", "[2773][branch_selection]") {

    // Anchor target density between rho(near triple) and rho(near peak) on
    // the rising branch — this guarantees two T-roots exist (one on the
    // rising branch below the density max, one on the falling branch above).
    std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    AS->update(CoolProp::QT_INPUTS, 0.0, 277.0);  // close to peak
    const double rho_near_peak = AS->rhomolar();
    AS->update(CoolProp::QT_INPUTS, 0.0, 273.5);  // close to triple
    const double rho_near_triple = AS->rhomolar();
    REQUIRE(rho_near_peak > rho_near_triple);  // confirms density max is real
    const double rho_target = 0.5 * (rho_near_peak + rho_near_triple);
    AS->update(CoolProp::QT_INPUTS, 0.0, 290.0);
    REQUIRE(AS->rhomolar() < rho_target);  // confirms falling branch reaches target

    const double T_density_max = 277.13;  // approximate peak T

    SECTION("Guess near low-T (rising) branch → root below density max") {
        CoolProp::GuessesStructure g;
        g.T = 274.0;
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::DmolarQ_INPUTS, rho_target, 0.0, g));
        CHECK(AS->T() < T_density_max);
        CHECK(AS->rhomolar() == Catch::Approx(rho_target).epsilon(1e-6));
    }
    SECTION("Guess near high-T (falling) branch → root above density max") {
        CoolProp::GuessesStructure g;
        g.T = 282.0;
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::DmolarQ_INPUTS, rho_target, 0.0, g));
        CHECK(AS->T() > T_density_max);
        CHECK(AS->rhomolar() == Catch::Approx(rho_target).epsilon(1e-6));
    }
}

TEST_CASE("HmolarQ branch selection via guess.T (water saturated vapor)", "[2773][branch_selection]") {
    // h_g(T) on water saturated vapor has a maximum near T ≈ 540 K. Anchor
    // h_target = h_g(T_low) where T_low is on the rising side; by smoothness
    // of h_g there is necessarily a second T_high > T_peak on the falling
    // side that also satisfies h_g(T_high) = h_target.
    std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    const double T_low_anchor = 470.0;
    AS->update(CoolProp::QT_INPUTS, 1.0, T_low_anchor);
    const double h_target = AS->hmolar();
    const double T_h_max_approx = 540.0;  // approximate h_g peak T

    SECTION("Guess near T_low_anchor → low-T root") {
        CoolProp::GuessesStructure g;
        g.T = T_low_anchor;
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_target, 1.0, g));
        CHECK(AS->T() < T_h_max_approx);
        CHECK(AS->T() == Catch::Approx(T_low_anchor).epsilon(0.01));
    }
    SECTION("Guess far above the h-peak → high-T root") {
        CoolProp::GuessesStructure g;
        g.T = 620.0;
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_target, 1.0, g));
        CHECK(AS->T() > T_h_max_approx);                              // a different root past the peak
        CHECK(AS->T() != Catch::Approx(T_low_anchor).epsilon(0.05));  // not the same root
    }
}

TEST_CASE("Default update() throws MultipleSolutionsError on ambiguous saturation flash", "[2773][strict_mode]") {
    // GitHub #2773 / #2834: when an HQ / SQ / DQ saturation flash input lies
    // in a multi-root region, the no-guess default update() now raises
    // MultipleSolutionsError instead of silently picking one. Users in this
    // case should call update_with_guesses with a guess.T.

    SECTION("Water DmolarQ in the rho_L-non-monotonic region near 4 °C") {
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::QT_INPUTS, 0.0, 277.0);
        const double rho_near_peak = AS->rhomolar();
        AS->update(CoolProp::QT_INPUTS, 0.0, 273.5);
        const double rho_near_triple = AS->rhomolar();
        const double rho_target = 0.5 * (rho_near_peak + rho_near_triple);
        // Default flash should now refuse the ambiguous input cleanly.
        CHECK_THROWS_AS(AS->update(CoolProp::DmolarQ_INPUTS, rho_target, 0.0), CoolProp::MultipleSolutionsError);
    }

    SECTION("Water HmolarQ in the h_g-non-monotonic region around 540 K peak") {
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::QT_INPUTS, 1.0, 470.0);
        const double h_target = AS->hmolar();  // also reached on the high-T side
        CHECK_THROWS_AS(AS->update(CoolProp::HmolarQ_INPUTS, h_target, 1.0), CoolProp::MultipleSolutionsError);
    }

    SECTION("Single-root DQ still succeeds via the default path") {
        // Far from the density max, rho_L(T) is monotone — single root, no error.
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::QT_INPUTS, 0.0, 400.0);
        const double rho_400 = AS->rhomolar();
        REQUIRE_NOTHROW(AS->update(CoolProp::DmolarQ_INPUTS, rho_400, 0.0));
        CHECK(AS->T() == Catch::Approx(400.0).epsilon(1e-6));
    }
}

TEST_CASE("QSmolar branch selection via guess.T (water saturated vapor)", "[2773][branch_selection]") {
    // s_g(T) on water saturated vapor descends monotonically from triple to
    // critical, so it does not by itself exhibit two roots — but exercising
    // the QSmolar_INPUTS dispatch validates that the new code path runs end-
    // to-end and returns a sensible T.
    std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
    const double T_anchor = 500.0;
    AS->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
    const double s_target = AS->smolar();
    CoolProp::GuessesStructure g;
    g.T = T_anchor;
    REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::QSmolar_INPUTS, 1.0, s_target, g));
    CHECK(AS->T() == Catch::Approx(T_anchor).epsilon(0.01));
}

// Edge-case coverage gaps surfaced in PR #2835 review (S4):
TEST_CASE("Saturation branch flash: edge cases (#2773)", "[2773][edge_cases]") {

    SECTION("Mass-input dispatch: HmassQ_INPUTS converts and resolves") {
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        const double T_anchor = 470.0;
        AS->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
        const double h_mass = AS->hmass();  // J/kg
        CoolProp::GuessesStructure g;
        g.T = T_anchor;
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::HmassQ_INPUTS, h_mass, 1.0, g));
        CHECK(AS->T() == Catch::Approx(T_anchor).epsilon(0.01));
    }

    SECTION("Mass-input dispatch: QSmass_INPUTS converts and resolves") {
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        const double T_anchor = 500.0;
        AS->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
        const double s_mass = AS->smass();  // J/kg/K
        CoolProp::GuessesStructure g;
        g.T = T_anchor;
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::QSmass_INPUTS, 1.0, s_mass, g));
        CHECK(AS->T() == Catch::Approx(T_anchor).epsilon(0.01));
    }

    SECTION("Reference-state change works correctly across instances") {
        // Build the h-superancillary against the default reference state,
        // then switch to NBP and verify a fresh HEOS instance returns the
        // NBP-frame T-root. The cache is shared (single shared_ptr) but the
        // shift-c0 trick translates the new caller's target into the cache's
        // frame at query time — no rebuild needed. NBP works for water
        // (IIR is rejected because Ttriple > 273.15 K).
        //
        // RAII guard ensures the global ref state is reset to DEF even if
        // an assertion below fails — otherwise downstream water tests would
        // operate under NBP and behave unpredictably.
        struct WaterRefStateGuard
        {
            ~WaterRefStateGuard() {
                CoolProp::set_reference_stateS("Water", "DEF");
            }
        } guard;

        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        const double T_anchor = 470.0;
        AS->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
        const double h_def = AS->hmolar();
        CoolProp::GuessesStructure g;
        g.T = T_anchor;
        // Force the caloric superancillary build under the DEF reference.
        REQUIRE_NOTHROW(AS->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_def, 1.0, g));
        // Switch reference state. The cache stays as-is; only the offset
        // stamp records what frame it's in.
        CoolProp::set_reference_stateS("Water", "NBP");
        std::shared_ptr<CoolProp::AbstractState> AS2(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS2->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
        const double h_nbp = AS2->hmolar();
        REQUIRE(std::abs(h_nbp - h_def) > 100.0);  // confirms the offset is real
        // resolve_T_via_superancillary translates h_nbp into the cache's DEF
        // frame via R·T_red·(a2_cache − a2_caller), so TOMS748 finds the same
        // saturation T_anchor that satisfies both frames.
        REQUIRE_NOTHROW(AS2->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_nbp, 1.0, g));
        CHECK(AS2->T() == Catch::Approx(T_anchor).epsilon(0.01));
    }

    SECTION("Mixture: NotImplementedError preserved") {
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "R32&R125"));
        std::vector<double> z = {0.5, 0.5};
        AS->set_mole_fractions(z);
        CoolProp::GuessesStructure g;
        g.T = 300.0;
        CHECK_THROWS_AS(AS->update_with_guesses(CoolProp::DmolarQ_INPUTS, 10000.0, 0.0, g), CoolProp::NotImplementedError);
    }

    SECTION("guess.T outside saturation range: clear SolutionError") {
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::QT_INPUTS, 1.0, 470.0);
        const double h_target = AS->hmolar();
        CoolProp::GuessesStructure g;
        g.T = 700.0;  // above water's critical (647 K) — outside range
        CHECK_THROWS_AS(AS->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_target, 1.0, g), CoolProp::SolutionError);
    }

    SECTION("Multi-root region throws MultipleSolutionsError on default update()") {
        // h_g(T) on water saturated vapor is non-monotonic with peak near 540 K.
        // h_target = h_g(470 K) is also reached near 605 K — two distinct
        // roots that the dedup must NOT merge.
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::QT_INPUTS, 1.0, 470.0);
        const double h_low = AS->hmolar();
        CHECK_THROWS_AS(AS->update(CoolProp::HmolarQ_INPUTS, h_low, 1.0), CoolProp::MultipleSolutionsError);
    }

    SECTION("Mass-input multi-root region also throws MultipleSolutionsError") {
        // Same as above but exercises the HmassQ_INPUTS → HmolarQ_INPUTS
        // conversion path in mass_to_molar_inputs (review I4 follow-up).
        std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
        AS->update(CoolProp::QT_INPUTS, 1.0, 470.0);
        const double h_low_mass = AS->hmass();
        CHECK_THROWS_AS(AS->update(CoolProp::HmassQ_INPUTS, h_low_mass, 1.0), CoolProp::MultipleSolutionsError);
    }
}

// Verify the option-D shift-c0 trick: the caloric superancillary cache is
// reference-state-agnostic. Two coexisting HEOS instances at different
// reference states should both get correct answers without forcing the cache
// to rebuild on every alternation. See #2773.
TEST_CASE("Caloric superancillary is reference-state-agnostic (no thrashing)", "[2773][ref_state_shared]") {
    // RAII guard: ensure water is reset to DEF on exit, regardless of
    // assertion failures, so downstream tests aren't contaminated.
    struct WaterRefStateGuard
    {
        WaterRefStateGuard() {
            CoolProp::set_reference_stateS("Water", "DEF");
        }
        ~WaterRefStateGuard() {
            CoolProp::set_reference_stateS("Water", "DEF");
        }
    } guard;

    // (1) Build the cache via the first HEOS instance under DEF.
    std::shared_ptr<CoolProp::AbstractState> AS_def(CoolProp::AbstractState::factory("HEOS", "Water"));
    const double T_anchor = 470.0;
    AS_def->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
    const double h_def_anchor = AS_def->hmolar();
    CoolProp::GuessesStructure g;
    g.T = T_anchor;
    REQUIRE_NOTHROW(AS_def->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_def_anchor, 1.0, g));
    CHECK(AS_def->T() == Catch::Approx(T_anchor).epsilon(1e-6));

    const auto build_count_after_first = static_cast<unsigned int>(AS_def->get_fluid_parameter_double(0, "SUPERANC::caloric_build_count"));
    REQUIRE(build_count_after_first >= 1u);

    // (2) Switch the global reference state to NBP. AS_def keeps its own DEF
    // alpha0 (each HEOS holds its own copy); a fresh HEOS gets NBP.
    CoolProp::set_reference_stateS("Water", "NBP");
    std::shared_ptr<CoolProp::AbstractState> AS_nbp(CoolProp::AbstractState::factory("HEOS", "Water"));
    AS_nbp->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
    const double h_nbp_anchor = AS_nbp->hmolar();
    REQUIRE(std::abs(h_nbp_anchor - h_def_anchor) > 100.0);  // confirm offset is real

    // (3) Both instances must resolve their own h-target back to T_anchor.
    REQUIRE_NOTHROW(AS_nbp->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_nbp_anchor, 1.0, g));
    CHECK(AS_nbp->T() == Catch::Approx(T_anchor).epsilon(1e-6));
    REQUIRE_NOTHROW(AS_def->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_def_anchor, 1.0, g));
    CHECK(AS_def->T() == Catch::Approx(T_anchor).epsilon(1e-6));

    // (4) Alternate queries. With option-D the cache stays built once; the
    // shift trick translates each user's target into the cache's frame.
    for (int i = 0; i < 5; ++i) {
        REQUIRE_NOTHROW(AS_def->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_def_anchor, 1.0, g));
        CHECK(AS_def->T() == Catch::Approx(T_anchor).epsilon(1e-6));
        REQUIRE_NOTHROW(AS_nbp->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_nbp_anchor, 1.0, g));
        CHECK(AS_nbp->T() == Catch::Approx(T_anchor).epsilon(1e-6));
    }

    // (5) The build count must equal what it was after step (1) — no
    // thrashing rebuilds despite alternating reference states.
    const auto build_count_final = static_cast<unsigned int>(AS_def->get_fluid_parameter_double(0, "SUPERANC::caloric_build_count"));
    CHECK(build_count_final == build_count_after_first);

    // Same for QSmolar with mixed reference states.
    AS_def->update(CoolProp::QT_INPUTS, 1.0, 500.0);
    const double s_def_anchor = AS_def->smolar();
    AS_nbp->update(CoolProp::QT_INPUTS, 1.0, 500.0);
    const double s_nbp_anchor = AS_nbp->smolar();
    REQUIRE(std::abs(s_nbp_anchor - s_def_anchor) > 1.0);  // confirm offset is real
    g.T = 500.0;
    REQUIRE_NOTHROW(AS_def->update_with_guesses(CoolProp::QSmolar_INPUTS, 1.0, s_def_anchor, g));
    CHECK(AS_def->T() == Catch::Approx(500.0).epsilon(1e-3));
    REQUIRE_NOTHROW(AS_nbp->update_with_guesses(CoolProp::QSmolar_INPUTS, 1.0, s_nbp_anchor, g));
    CHECK(AS_nbp->T() == Catch::Approx(500.0).epsilon(1e-3));

    // RAII guard at the top of the test resets the reference state on exit.
}

// Verify thread safety of the lazy build path. Spawn N threads, each creating
// its own HEOS for water and running multiple HmolarQ flashes concurrently.
// Without the mutex inside ensure_HS_under_lock this would race on
// optional<...>::emplace and could corrupt the shared SuperAncillary.
// With the mutex, exactly one thread builds the cache and the others wait.
TEST_CASE("Caloric superancillary thread-safe lazy build (#2773)", "[2773][thread_safety]") {
    // Capture the build count before this test runs so the assertion below is
    // insensitive to any prior test having already triggered a build.
    std::shared_ptr<CoolProp::AbstractState> probe(CoolProp::AbstractState::factory("HEOS", "Water"));
    const auto build_count_before = static_cast<unsigned int>(probe->get_fluid_parameter_double(0, "SUPERANC::caloric_build_count"));
    probe.reset();

    constexpr int N_THREADS = 8;
    constexpr int N_ITERS_PER_THREAD = 50;
    std::atomic<int> error_count{0};
    std::atomic<int> success_count{0};

    auto worker = [&]() {
        try {
            std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));
            const double T_anchor = 470.0;
            AS->update(CoolProp::QT_INPUTS, 1.0, T_anchor);
            const double h_target = AS->hmolar();
            CoolProp::GuessesStructure g;
            g.T = T_anchor;
            for (int i = 0; i < N_ITERS_PER_THREAD; ++i) {
                AS->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_target, 1.0, g);
                if (std::abs(AS->T() - T_anchor) > 1e-3) {
                    error_count.fetch_add(1, std::memory_order_relaxed);
                    return;
                }
            }
            success_count.fetch_add(1, std::memory_order_relaxed);
        } catch (...) {
            error_count.fetch_add(1, std::memory_order_relaxed);
        }
    };

    std::vector<std::thread> threads;
    threads.reserve(N_THREADS);
    for (int t = 0; t < N_THREADS; ++t) {
        threads.emplace_back(worker);
    }
    for (auto& t : threads) {
        t.join();
    }

    CHECK(error_count.load() == 0);
    CHECK(success_count.load() == N_THREADS);

    // Build counter delta should be at most 1: with the mutex, exactly one
    // thread wins the race to build; the others observe the cache and skip.
    // Allow 0 if a prior test already built the cache.
    std::shared_ptr<CoolProp::AbstractState> probe2(CoolProp::AbstractState::factory("HEOS", "Water"));
    const auto build_count_after = static_cast<unsigned int>(probe2->get_fluid_parameter_double(0, "SUPERANC::caloric_build_count"));
    CHECK(build_count_after - build_count_before <= 1u);
}

// Benchmark the new superancillary-based with_guesses path against the
// existing default flash for the input pairs covered by #2773. Tagged
// [!benchmark] so it doesn't run with the default test selection — invoke
// with e.g. `CatchTestRunner "[2773][bench]"`.
//
// Only DQ has a working baseline: default HQ_flash and QS_flash are unreliable
// for water (and propane) at many sensible operating points (the symptom that
// motivates #2773). Where the baseline can be benchmarked, it is; otherwise the
// with_guesses path's absolute timing stands on its own.
TEST_CASE("DQ/HQ/QS flash benchmarks (#2773)", "[2773][bench][!benchmark]") {
    std::shared_ptr<CoolProp::AbstractState> AS(CoolProp::AbstractState::factory("HEOS", "Water"));

    // DQ: pick a T well away from the 4 °C density max so the existing
    // single-root Brent path doesn't bracket-hop. T = 400 K is on the
    // monotonic-decreasing side of rho_L(T).
    AS->update(CoolProp::QT_INPUTS, 0.0, 400.0);
    const double rho_DQ = AS->rhomolar();
    CoolProp::GuessesStructure g_DQ;
    g_DQ.T = 400.0;

    // HQ: anchor on a rising-branch h_g for water saturated vapor.
    AS->update(CoolProp::QT_INPUTS, 1.0, 470.0);
    const double h_HQ = AS->hmolar();
    CoolProp::GuessesStructure g_HQ;
    g_HQ.T = 470.0;

    // QS: saturated liquid n-propane at 300 K.
    std::shared_ptr<CoolProp::AbstractState> AS_prop(CoolProp::AbstractState::factory("HEOS", "n-Propane"));
    AS_prop->update(CoolProp::QT_INPUTS, 0.0, 300.0);
    const double s_QS = AS_prop->smolar();
    CoolProp::GuessesStructure g_QS;
    g_QS.T = 300.0;

    BENCHMARK("DQ default      update(DmolarQ,rho,Q=0)") {
        return AS->update(CoolProp::DmolarQ_INPUTS, rho_DQ, 0.0);
    };
    BENCHMARK("DQ with guesses update_with_guesses(DmolarQ,rho,Q=0,T)") {
        return AS->update_with_guesses(CoolProp::DmolarQ_INPUTS, rho_DQ, 0.0, g_DQ);
    };
    // Default HQ_flash and QS_flash are skipped — both throw or crash for the
    // chosen anchor points (pre-existing #2773 symptom).
    BENCHMARK("HQ with guesses update_with_guesses(HmolarQ,h,Q=1,T)") {
        return AS->update_with_guesses(CoolProp::HmolarQ_INPUTS, h_HQ, 1.0, g_HQ);
    };
    BENCHMARK("QS with guesses update_with_guesses(QSmolar,Q=0,s,T) [propane]") {
        return AS_prop->update_with_guesses(CoolProp::QSmolar_INPUTS, 0.0, s_QS, g_QS);
    };
}

TEST_CASE("INCOMP backend rejects molar property requests with a clean error", "[INCOMP][1908]") {
    // Issue #1908: PropsSI('Dmolar','T',298.15,'P',101325,'INCOMP::AEG[0.1]')
    // returned -infinity (the AbstractState default for _rhomolar) and the
    // Python wrapper surfaced the unhelpful "PropsSI failed ungracefully"
    // message because errstring was empty. The INCOMP backend now throws
    // a NotImplementedError naming the mass-basis equivalent so PropsSI
    // propagates a useful errstring.
    double v = CoolProp::PropsSI("Dmolar", "T", 298.15, "P", 101325.0, "INCOMP::AEG[0.1]");
    CHECK(!ValidNumber(v));
    std::string err = CoolProp::get_global_param_string("errstring");
    CAPTURE(err);
    CHECK(err.find("INCOMP") != std::string::npos);
    // Mass-basis output must still work for the same state
    double rhomass = CoolProp::PropsSI("Dmass", "T", 298.15, "P", 101325.0, "INCOMP::AEG[0.1]");
    CHECK(rhomass > 0);
    CHECK(rhomass < 2000);
}

TEST_CASE("mole_fractions_liquid/vapor reject single-phase states (#2308)", "[mole_fractions][2308]") {
    // Issue #2308: SatL/SatV retain composition vectors from the most recent
    // VLE flash (or phase-envelope build); calc_mole_fractions_liquid/vapor
    // were returning those stale values when the current state was actually
    // single-phase, which is misleading. Now they throw.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Nitrogen&Methane&Ethane&Propane"));
    AS->set_mole_fractions({0.10, 0.34, 0.41, 0.15});

    // Build the phase envelope so SatL/SatV pick up some non-trivial state
    AS->build_phase_envelope("");

    // Single-phase point: T well above the dew curve at 1.5 bar
    AS->update(CoolProp::PT_INPUTS, 1.5e5, 298.15);
    REQUIRE_FALSE(AS->phase() == CoolProp::iphase_twophase);
    CHECK_THROWS_AS(AS->mole_fractions_liquid(), CoolProp::ValueError);
    CHECK_THROWS_AS(AS->mole_fractions_vapor(), CoolProp::ValueError);

    // Two-phase point: PQ flash, Q=0.5
    AS->update(CoolProp::PQ_INPUTS, 1.5e5, 0.5);
    REQUIRE(AS->phase() == CoolProp::iphase_twophase);
    REQUIRE_NOTHROW(AS->mole_fractions_liquid());
    REQUIRE_NOTHROW(AS->mole_fractions_vapor());
    auto x = AS->mole_fractions_liquid();
    auto y = AS->mole_fractions_vapor();
    REQUIRE(x.size() == 4);
    REQUIRE(y.size() == 4);
    // Each composition must sum to ~1.0
    double sx = 0.0, sy = 0.0;
    for (auto v : x)
        sx += v;
    for (auto v : y)
        sy += v;
    CHECK(sx == Catch::Approx(1.0).epsilon(1e-9));
    CHECK(sy == Catch::Approx(1.0).epsilon(1e-9));
}

TEST_CASE("REFPROP supports DmolarQ / DmassQ inputs (#1845)", "[REFPROP][1845]") {
    CoolProp::Skip_if_No_REFPROP();
    // Issue #1845: DmassQ_INPUTS / DmolarQ_INPUTS were missing from the
    // REFPROP backend dispatch. REFPROP itself supports them via DQFL2dll.
    auto AS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("REFPROP", "CO2"));
    REQUIRE_NOTHROW(AS->update(CoolProp::DmassQ_INPUTS, 15.0, 1.0));
    const double T_refprop = AS->T();
    CHECK(AS->rhomass() == Catch::Approx(15.0).epsilon(1e-9));
    CHECK(T_refprop > 200.0);
    CHECK(T_refprop < 250.0);
    // Cross-check with HEOS
    auto AS2 = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "CO2"));
    AS2->update(CoolProp::DmassQ_INPUTS, 15.0, 1.0);
    CHECK(AS->T() == Catch::Approx(AS2->T()).epsilon(1e-6));
}

TEST_CASE("TABULAR_NX/NY config keys exist and default to 200", "[Configuration][TABULAR]") {
    // The tabular backend grid resolution is configurable; confirm the keys
    // are present and the documented default is honored.
    CHECK(CoolProp::get_config_int(TABULAR_NX) == 200);
    CHECK(CoolProp::get_config_int(TABULAR_NY) == 200);
}

TEST_CASE("BICUBIC PT below saturation no longer segfaults (#1950)", "[BICUBIC][1950]") {
    // Issue #1950: BICUBIC&HEOS update(PT_INPUTS, p, T) where T is just below
    // Tsat(p) and the saturation curve sits inside the table cell:
    //   - find_native_nearest_good_indices returns a valid cell on the vapor side
    //   - saturation-curve check bumps `cached_single_phase_i--` to land in the
    //     table's two-phase notch, where CellCoeffs has no alpha[] populated
    //   - evaluate_single_phase dereferences alpha[12] → segfault
    //
    // After the fix, the bumped cell is checked for validity; if the alternate
    // neighbour is set, we use it; otherwise we throw a clean ValueError.
    auto BICU = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("BICUBIC&HEOS", "Nitrogen"));
    // P=2 bar, T=78 K is sub-saturation for N2 (Tsat(2 bar) ~ 83.6 K) — was the
    // original repro from the issue that crashed.
    REQUIRE_NOTHROW(BICU->update(CoolProp::PT_INPUTS, 2.0e5, 78.0));
    // BICU should land on a valid liquid cell and produce a sensible density.
    const double rho = BICU->rhomass();
    CHECK(std::isfinite(rho));
    CHECK(rho > 700.0);  // liquid N2 ~803 kg/m^3 at this state
    CHECK(rho < 900.0);

    // Cross-check vs HEOS — the magnitudes should agree to within bicubic noise.
    auto HEOS = std::shared_ptr<CoolProp::AbstractState>(CoolProp::AbstractState::factory("HEOS", "Nitrogen"));
    HEOS->update(CoolProp::PT_INPUTS, 2.0e5, 78.0);
    CHECK(rho == Catch::Approx(HEOS->rhomass()).epsilon(1e-2));  // 1% bicubic tolerance
}

TEST_CASE("REFPROP update_DmolarT_direct matches update(DmolarT)", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> direct(AbstractState::factory("REFPROP", "Propane"));
    std::shared_ptr<AbstractState> flash(AbstractState::factory("REFPROP", "Propane"));
    double T = 300.0, rhomolar = 12000.0;  // dense liquid, single phase
    flash->update(DmolarT_INPUTS, rhomolar, T);
    auto* be = dynamic_cast<REFPROPMixtureBackend*>(direct.get());
    REQUIRE(be != nullptr);
    be->update_DmolarT_direct(rhomolar, T);
    CHECK(direct->p() == Catch::Approx(flash->p()).epsilon(1e-9));
    CHECK(direct->hmolar() == Catch::Approx(flash->hmolar()).epsilon(1e-9));
    CHECK(direct->smolar() == Catch::Approx(flash->smolar()).epsilon(1e-9));
}

TEST_CASE("REFPROP saturation shim reproduces saturated densities", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> host(AbstractState::factory("REFPROP", "Propane"));
    host->update(QT_INPUTS, 0.5, 300.0);  // two-phase
    auto* be = dynamic_cast<REFPROPMixtureBackend*>(host.get());
    REQUIRE(be != nullptr);
    auto shimL = be->build_saturation_shim(0);  // liquid
    auto shimV = be->build_saturation_shim(1);  // vapor
    CHECK(shimL->rhomolar() == Catch::Approx(be->saturated_liquid_keyed_output(iDmolar)).epsilon(1e-10));
    CHECK(shimV->rhomolar() == Catch::Approx(be->saturated_vapor_keyed_output(iDmolar)).epsilon(1e-10));
    // The shim must NOT have triggered a re-SETUP: enthalpy from THERMdll at (T, rhoL)
    // must equal a fresh single-phase evaluation at the same point.
    std::shared_ptr<AbstractState> probe(AbstractState::factory("REFPROP", "Propane"));
    probe->specify_phase(iphase_liquid);
    probe->update(DmolarT_INPUTS, shimL->rhomolar(), 300.0);
    CHECK(shimL->hmolar() == Catch::Approx(probe->hmolar()).epsilon(1e-9));
}

TEST_CASE("REFPROP saturated keyed outputs (h,s,cp,visc) match endpoint flashes", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> twophase(AbstractState::factory("REFPROP", "Propane"));
    twophase->update(QT_INPUTS, 0.5, 300.0);
    std::shared_ptr<AbstractState> bubble(AbstractState::factory("REFPROP", "Propane"));
    bubble->update(QT_INPUTS, 0.0, 300.0);
    std::shared_ptr<AbstractState> dew(AbstractState::factory("REFPROP", "Propane"));
    dew->update(QT_INPUTS, 1.0, 300.0);

    CHECK(twophase->saturated_liquid_keyed_output(iHmolar) == Catch::Approx(bubble->hmolar()).epsilon(1e-7));
    CHECK(twophase->saturated_vapor_keyed_output(iHmolar) == Catch::Approx(dew->hmolar()).epsilon(1e-7));
    CHECK(twophase->saturated_liquid_keyed_output(iSmolar) == Catch::Approx(bubble->smolar()).epsilon(1e-7));
    CHECK(twophase->saturated_liquid_keyed_output(iCpmolar) == Catch::Approx(bubble->cpmolar()).epsilon(1e-6));
    CHECK(twophase->saturated_vapor_keyed_output(iviscosity) == Catch::Approx(dew->viscosity()).epsilon(1e-6));
    CHECK(twophase->saturated_liquid_keyed_output(iconductivity) == Catch::Approx(bubble->conductivity()).epsilon(1e-6));
}

TEST_CASE("REFPROP first_saturation_deriv matches HEOS for a pure fluid", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> RP(AbstractState::factory("REFPROP", "Propane"));
    std::shared_ptr<AbstractState> HE(AbstractState::factory("HEOS", "Propane"));
    for (int Ti = 200; Ti <= 360; Ti += 40) {
        double T = Ti;
        RP->update(QT_INPUTS, 0.0, T);
        HE->update(QT_INPUTS, 0.0, T);
        CHECK(RP->first_saturation_deriv(iT, iP) == Catch::Approx(HE->first_saturation_deriv(iT, iP)).epsilon(1e-4));
        CHECK(RP->first_saturation_deriv(iDmolar, iT) == Catch::Approx(HE->first_saturation_deriv(iDmolar, iT)).epsilon(1e-3));
        CHECK(RP->first_saturation_deriv(iHmolar, iP) == Catch::Approx(HE->first_saturation_deriv(iHmolar, iP)).epsilon(1e-3));
    }
    // Pure fluid: a two-phase state with 0<Q<1 must also work (vapor-pressure slope is Q-independent).
    RP->update(QT_INPUTS, 0.5, 300.0);
    HE->update(QT_INPUTS, 0.5, 300.0);
    CHECK(RP->first_saturation_deriv(iT, iP) == Catch::Approx(HE->first_saturation_deriv(iT, iP)).epsilon(1e-4));
}

TEST_CASE("REFPROP first_two_phase_deriv matches HEOS for a pure fluid", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> RP(AbstractState::factory("REFPROP", "Propane"));
    std::shared_ptr<AbstractState> HE(AbstractState::factory("HEOS", "Propane"));
    RP->update(QT_INPUTS, 0.4, 300.0);
    HE->update(QT_INPUTS, 0.4, 300.0);
    CHECK(RP->first_two_phase_deriv(iDmolar, iHmolar, iP) == Catch::Approx(HE->first_two_phase_deriv(iDmolar, iHmolar, iP)).epsilon(1e-4));
    CHECK(RP->first_two_phase_deriv(iDmolar, iP, iHmolar) == Catch::Approx(HE->first_two_phase_deriv(iDmolar, iP, iHmolar)).epsilon(1e-3));
}

TEST_CASE("REFPROP saturated keyed output throws in single phase", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> AS(AbstractState::factory("REFPROP", "Propane"));
    AS->update(PT_INPUTS, 101325, 300.0);  // single-phase gas
    CHECK_THROWS(AS->saturated_liquid_keyed_output(iHmolar));
    // A subsequent two-phase update must still work (no stale state leaks).
    AS->update(QT_INPUTS, 0.3, 280.0);
    CHECK(ValidNumber(AS->saturated_liquid_keyed_output(iHmolar)));
}

TEST_CASE("REFPROP first_two_phase_deriv_splined matches HEOS (pure)", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> RP(AbstractState::factory("REFPROP", "Propane"));
    std::shared_ptr<AbstractState> HE(AbstractState::factory("HEOS", "Propane"));
    double x_end = 0.3;
    RP->update(QT_INPUTS, 0.1, 300.0);
    HE->update(QT_INPUTS, 0.1, 300.0);
    CHECK(RP->first_two_phase_deriv_splined(iDmolar, iHmolar, iP, x_end)
          == Catch::Approx(HE->first_two_phase_deriv_splined(iDmolar, iHmolar, iP, x_end)).epsilon(1e-3));
    CHECK(RP->first_two_phase_deriv_splined(iDmolar, iP, iHmolar, x_end)
          == Catch::Approx(HE->first_two_phase_deriv_splined(iDmolar, iP, iHmolar, x_end)).epsilon(1e-3));
}

TEST_CASE("REFPROP saturation derivs work for a mixture", "[REFPROPsat]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> RP(AbstractState::factory("REFPROP", "Methane&Ethane"));
    std::vector<double> z = {0.6, 0.4};
    RP->set_mole_fractions(z);
    RP->update(QT_INPUTS, 0.0, 180.0);  // bubble
    // dT/dp along the bubble curve should be finite and positive away from the critical point.
    double dTdp = RP->first_saturation_deriv(iT, iP);
    CHECK(ValidNumber(dTdp));
    CHECK(dTdp > 0);
    // Two-phase interior derivatives are not implemented for mixtures (need the
    // constant-overall-composition saturation slope); they must throw, not return garbage.
    RP->update(QT_INPUTS, 0.4, 180.0);
    CHECK_THROWS(RP->first_two_phase_deriv(iDmolar, iHmolar, iP));
    CHECK_THROWS(RP->first_two_phase_deriv_splined(iDmolar, iHmolar, iP, 0.5));
}

TEST_CASE("REFPROP set_binary_interaction_string model param is length-guarded (CoolProp-tw7t)", "[REFPROP][refprop][binary_interaction]") {
    Skip_if_No_REFPROP();
    std::shared_ptr<AbstractState> RP(AbstractState::factory("REFPROP", "Methane&Ethane"));
    RP->set_mole_fractions({0.6, 0.4});

    // hmodij is a 3-character REFPROP (FORTRAN) field. An over-long model value
    // must be rejected by the length guard, NOT strcpy'd into the 3-byte buffer
    // (which overflowed the stack by 1-2 bytes — CoolProp-tw7t). The length-4
    // case is the precise regression: the old guard `value.length() > 4` let it
    // through and overflowed; ASAN only flags it with a boundary-length input,
    // which no prior test supplied.
    CHECK_THROWS_AS(RP->set_binary_interaction_string(0, 1, "model", "ABCD"), CoolProp::ValueError);     // 4 chars
    CHECK_THROWS_AS(RP->set_binary_interaction_string(0, 1, "model", "TOOLONG"), CoolProp::ValueError);  // 7 chars
    // An unknown parameter must also fail cleanly rather than silently no-op.
    CHECK_THROWS_AS(RP->set_binary_interaction_string(0, 1, "bogus", "x"), CoolProp::ValueError);

    // A valid-length (<=3 char) model exercises the bounded copy: it must not
    // overflow hmodij[3]. Whether REFPROP accepts the specific code is version-
    // dependent, so we only require the call does not corrupt the stack (ASAN
    // would abort the binary if it did).
    CHECK_NOTHROW([&] {
        try {
            RP->set_binary_interaction_string(0, 1, "model", "KW0");
        } catch (const CoolProp::ValueError&) { /* REFPROP may reject the code; acceptable */
        }
    }());

    // The getter reads the same fixed 3-char field; constructing a std::string
    // from hmodij as a C-string over-reads past the 3-byte buffer (CWE-126), so
    // it must read exactly the field width and trim the FORTRAN space padding.
    // Exercise the read path (ASAN guards the over-read); CAS: Methane=74-82-8,
    // Ethane=74-84-0. The CAS lookup is REFPROP-version dependent, so tolerate
    // a ValueError but require a within-field-width result when it succeeds.
    CHECK_NOTHROW([&] {
        try {
            std::string m = RP->get_binary_interaction_string("74-82-8", "74-84-0", "model");
            CHECK(m.size() <= 3);
        } catch (const CoolProp::ValueError&) { /* CAS lookup version-dependent; acceptable */
        }
    }());
}

TEST_CASE("REFPROP cross-check: sat-state fugacity_coefficient agrees with HEOS for Methane/Ethane/Propane", "[REFPROPsat][2345-followup]") {
    Skip_if_No_REFPROP();
    const std::vector<double> z = {0.25, 0.25, 0.5};

    std::shared_ptr<AbstractState> HEOS(AbstractState::factory("HEOS", "Methane&Ethane&Propane"));
    HEOS->set_mole_fractions(z);
    HEOS->update(PQ_INPUTS, 500e3, 0.5);

    std::shared_ptr<AbstractState> RP(AbstractState::factory("REFPROP", "Methane&Ethane&Propane"));
    RP->set_mole_fractions(z);
    RP->update(PQ_INPUTS, 500e3, 0.5);

    // Bubble/dew T should agree across the two libraries to a few mK; that's the
    // anchor for the fugacity-coefficient comparison below.
    CHECK(std::abs(HEOS->T() - RP->T()) < 0.05);

    auto* heos_mix_ptr = dynamic_cast<HelmholtzEOSMixtureBackend*>(HEOS.get());
    REQUIRE(heos_mix_ptr != nullptr);
    auto& satL_heos = heos_mix_ptr->get_SatL();
    auto& satV_heos = heos_mix_ptr->get_SatV();

    // The REFPROP sat states are re-flashed at the bubble/dew T of the
    // liquid/vapor composition respectively — those T's differ slightly from
    // the original two-phase T at Q=0.5, so this is a near-apples comparison
    // rather than exact.  The 1 % tolerance below absorbs the mismatch.
    std::shared_ptr<AbstractState> satL_rp(AbstractState::factory("REFPROP", "Methane&Ethane&Propane"));
    satL_rp->set_mole_fractions(RP->mole_fractions_liquid());
    satL_rp->update(PQ_INPUTS, RP->p(), 0.0);
    std::shared_ptr<AbstractState> satV_rp(AbstractState::factory("REFPROP", "Methane&Ethane&Propane"));
    satV_rp->set_mole_fractions(RP->mole_fractions_vapor());
    satV_rp->update(PQ_INPUTS, RP->p(), 1.0);

    for (std::size_t i = 0; i < 3; ++i) {
        CAPTURE(i);
        const double phiL_heos = satL_heos.fugacity_coefficient(i);
        const double phiL_rp = satL_rp->fugacity_coefficient(i);
        const double phiV_heos = satV_heos.fugacity_coefficient(i);
        const double phiV_rp = satV_rp->fugacity_coefficient(i);
        CAPTURE(phiL_heos);
        CAPTURE(phiL_rp);
        CAPTURE(phiV_heos);
        CAPTURE(phiV_rp);
        // Both libraries use Helmholtz-based mixture models; for this well-studied
        // alkane system the fugacity coefficients should agree to ~1%.
        CHECK(std::abs(phiL_heos - phiL_rp) / std::abs(phiL_rp) < 1e-2);
        CHECK(std::abs(phiV_heos - phiV_rp) / std::abs(phiV_rp) < 1e-2);
    }
}

// Regression guard for the SurfaceTensionCorrelation ctor: a clang-tidy
// prefer-member-initializer "fix" once hoisted N=n.size() and s=n into the
// member-init list, where n is still empty (it's populated in the body), so
// every surface tension silently evaluated to 0.0.  These checks fail loudly
// if that ever recurs.  IAPWS reference values, ~1% tolerance.
TEST_CASE("Surface tension of water is nonzero and matches IAPWS", "[surface_tension]") {
    const double st_300 = CoolProp::PropsSI("I", "T", 300, "Q", 0, "Water");
    const double st_350 = CoolProp::PropsSI("I", "T", 350, "Q", 0, "Water");
    CAPTURE(st_300);
    CAPTURE(st_350);
    // Load-bearing: the regression made these exactly 0.
    CHECK(st_300 > 0.0);
    CHECK(st_350 > 0.0);
    // IAPWS: sigma(300 K) ~ 0.07170 N/m, sigma(350 K) ~ 0.06301 N/m.
    CHECK(st_300 == Catch::Approx(0.07170).epsilon(0.01));
    CHECK(st_350 == Catch::Approx(0.06301).epsilon(0.01));
    // Surface tension decreases monotonically toward the critical point.
    CHECK(st_350 < st_300);
    // A second fluid, looser bound, just to exercise another correlation.
    CHECK(CoolProp::PropsSI("I", "T", 300, "Q", 0, "R134a") > 0.0);
}

#endif
