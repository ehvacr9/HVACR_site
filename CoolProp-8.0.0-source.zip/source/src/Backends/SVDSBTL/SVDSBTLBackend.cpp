// SVDSBTLBackend implementation.  Architecturally inherits from
// AbstractState (mirroring IF97Backend), holds an SVDSurface per
// supported input pair, and dispatches calc_* through the active
// surface resolved at update() time.

#include "CoolProp/Backends/SVDSBTL/SVDSBTLBackend.h"

#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <exception>
#include <filesystem>
#include <memory>
#include <optional>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "boost/math/tools/toms748_solve.hpp"

#include "CoolProp/AbstractState.h"
#include "Backends/Helmholtz/HelmholtzEOSMixtureBackend.h"
#include "CoolProp/Configuration.h"
#include "CoolProp/Hash.h"
#include "CoolProp/SchemaValidation.h"
#include "CoolProp/sbtl/SVDSurface.h"
#include "CoolProp/sbtl/SVDSurfaceFactory.h"
#include "CoolProp/sbtl/SVDSurfaceSerializer.h"
#include "CoolProp/detail/atomic_write.h"
#include "CoolProp/detail/filepaths.h"
#include "CoolProp/sbtl/SVDSurfaceSerializer.h"
#include "CoolProp/sbtl/SaturationSurrogate.h"
#include "CoolProp/schemas/SVDSBTLOptions.h"
#include "CoolProp/DataStructures.h"
#include "CoolProp/Exceptions.h"
#include "CoolProp/detail/json.h"

// File-scope suppression for bugprone-unchecked-optional-access: the
// optionals on PointEvaluation are filled by resolve_point_() based on
// the Kind invariant (SinglePhase / DomeBlend / Patched / OutOfRange /
// TwoPhaseDisallowed) and unconditionally read by evaluate_property_()
// only when that invariant guarantees the field is set.  Per-line
// checking would require either (a) refactoring PointEvaluation to use
// non-optional NaN-sentinel fields (mass disruption) or (b) interleaving
// has_value() asserts that compile to nothing in release.  Neither
// matches the kind-invariant design here, so the check is suppressed at
// file scope — every access in this file is preceded by a kind switch.
//
// NOLINTBEGIN(bugprone-unchecked-optional-access)

namespace CoolProp {

namespace {

// The MVP set of input pairs.  Adding DU / HS / etc. in a follow-up
// is a one-line append here plus the matching preset + load helpers
// in `build_surface_for_pair_`.
constexpr std::array<CoolProp::input_pairs, 4> kSupportedPairs = {CoolProp::HmassP_INPUTS, CoolProp::PT_INPUTS, CoolProp::DmassT_INPUTS,
                                                                  CoolProp::PSmass_INPUTS};

// Quality tolerance for the #3190 dome-edge guards.  A Q=0/1 round-trip
// (y_mass = y_sat/M forward, y_mol = y_mass*M back) is not bit-exact, so an
// input sitting on the saturation boundary can land a few ULP outside
// [yL, yV].  Accepting within this band (and clamping Q to [0, 1]) keeps the
// round-trip two-phase; matches the +/-1e-9 Q band HEOS p_phase_determination
// uses at the dome edge.  Shared by try_fast_dome_reclassify_ (atlas-hit path)
// and both atlas-miss dome-blend blocks in resolve_point_.
constexpr double kDomeQTol = 1e-9;

// Build-time preset knobs (grid shape + pmin override) extracted from
// the validated options document.  This is the shared
// CoolProp::sbtl::presets::PresetOptions struct, so a new knob is a new
// field there (plus its resolve line below) — not a new parameter
// threaded through every preset signature.
using PresetOptions = CoolProp::sbtl::presets::PresetOptions;

// Polish the patch backend's T after an HmassP_INPUTS update so the
// returned state is forward-consistent in h(T, p), not just R7-97-
// backward-consistent.  Without this, in-bbox queries inherit the
// patch source's backward-equation residual (±25 mK for IF97 R1/R3,
// ±10 mK for R2/R5) — visible as ~10-20 mK / 0.1-0.4 J/(kg·K) s
// residuals in the SVDSBTL&IF97 fail-map even inside the patch box.
// Mirrors the polish in src/SBTL/SurfacePresets.cpp's IF97 sampling
// lambda (foi.9.10).  Best-effort: on bracket-failure or out-of-range,
// leaves the state as the HmassP backward seed (still functional, just
// at the ±25 mK floor).
void polish_patch_state_(::CoolProp::AbstractState& s, double p, double h) {
    auto resid = [&s, p, h](double T) -> double {
        try {
            s.update(::CoolProp::PT_INPUTS, p, T);
            return s.hmass() - h;
        } catch (...) {  // NOLINT(bugprone-empty-catch)
            return std::nan("");
        }
    };
    const double T_seed = s.T();
    // Use backend-reported T limits rather than IF97-specific constants:
    // patch_source_ may be HEOS / REFPROP / IF97 with different envelopes,
    // and pinning to water bounds either silently clips (HEOS with T_min
    // > 273.16) or overshoots (backend with T_max < 2273.15).
    const double T_lo = std::max(T_seed - 0.5, s.Tmin());
    const double T_hi = std::min(T_seed + 0.5, s.Tmax());
    auto restore_seed = [&s, p, T_seed]() noexcept {
        try {
            s.update(::CoolProp::PT_INPUTS, p, T_seed);
        } catch (...) {  // NOLINT(bugprone-empty-catch)
        }
    };
    if (!(T_lo < T_hi)) {
        return;
    }
    const double r_lo = resid(T_lo);
    const double r_hi = resid(T_hi);
    if (!std::isfinite(r_lo) || !std::isfinite(r_hi) || r_lo * r_hi > 0.0) {
        // Bracket missed (rare): restore the backward seed and bail.
        restore_seed();
        return;
    }
    try {
        std::uintmax_t max_iter = 30;
        const auto bracket =
          boost::math::tools::toms748_solve(resid, T_lo, T_hi, r_lo, r_hi, boost::math::tools::eps_tolerance<double>(40), max_iter);
        s.update(::CoolProp::PT_INPUTS, p, 0.5 * (bracket.first + bracket.second));
    } catch (...) {
        // toms748_solve / final update threw: restore the backward seed
        // so the caller sees the ±25 mK floor instead of a half-mutated
        // state at the last failed PT probe.
        restore_seed();
    }
}

// Entropy twin of polish_patch_state_: polish the patch backend's T
// after a PSmass_INPUTS update so the returned state is forward-
// consistent in s(T, p), not just R7-97-backward-consistent.  Same
// best-effort bracket-or-restore contract.
void polish_patch_state_s_(::CoolProp::AbstractState& s, double p, double s_val) {
    auto resid = [&s, p, s_val](double T) -> double {
        try {
            s.update(::CoolProp::PT_INPUTS, p, T);
            return s.smass() - s_val;
        } catch (...) {  // NOLINT(bugprone-empty-catch)
            return std::nan("");
        }
    };
    const double T_seed = s.T();
    const double T_lo = std::max(T_seed - 0.5, s.Tmin());
    const double T_hi = std::min(T_seed + 0.5, s.Tmax());
    auto restore_seed = [&s, p, T_seed]() noexcept {
        try {
            s.update(::CoolProp::PT_INPUTS, p, T_seed);
        } catch (...) {  // NOLINT(bugprone-empty-catch)
        }
    };
    if (!(T_lo < T_hi)) {
        return;
    }
    const double r_lo = resid(T_lo);
    const double r_hi = resid(T_hi);
    if (!std::isfinite(r_lo) || !std::isfinite(r_hi) || r_lo * r_hi > 0.0) {
        restore_seed();
        return;
    }
    try {
        std::uintmax_t max_iter = 30;
        const auto bracket =
          boost::math::tools::toms748_solve(resid, T_lo, T_hi, r_lo, r_hi, boost::math::tools::eps_tolerance<double>(40), max_iter);
        s.update(::CoolProp::PT_INPUTS, p, 0.5 * (bracket.first + bracket.second));
    } catch (...) {
        restore_seed();
    }
}

// Read the preset build knobs out of a validated options document:
// `grid.NT/NR/rank` and the optional `pmin` lower-pressure override.
// Missing keys leave the struct defaults in place — the validator has
// already rejected anything ill-formed.  The schema guarantees pmin > 0
// when present; the >= p_triple check lives in subcritical_pressure_range
// (it needs the fluid to resolve p_triple).  A future knob = one more
// field read here, no signature changes downstream.
PresetOptions resolve_preset_options(const nlohmann::json& opts) {
    PresetOptions po;
    if (opts.is_object() && opts.contains("grid") && opts.at("grid").is_object()) {
        const auto& grid = opts.at("grid");
        if (grid.contains("NT")) po.NT = static_cast<std::size_t>(cpjson::get_integer(grid, "NT"));
        if (grid.contains("NR")) po.NR = static_cast<std::size_t>(cpjson::get_integer(grid, "NR"));
        if (grid.contains("rank")) po.rank = cpjson::get_integer(grid, "rank");
    }
    if (opts.is_object() && opts.contains("pmin")) {
        po.p_min = opts.at("pmin").get<double>();
    }
    return po;
}

// Sample-and-build for a given input pair using the matching preset.
// Build knobs come from `po` so the caller can drive NT/NR/rank and the
// pmin floor from the options blob.  The source_backend string is
// threaded into the SurfaceSpec so sample_grid can spawn per-thread
// AbstractState instances when PARALLEL_SVDSBTL_SAMPLING is on
// (CoolProp-43h).
CoolProp::sbtl::SVDSurface build_surface_for_pair_(::CoolProp::AbstractState& source, const std::string& source_backend, CoolProp::input_pairs pair,
                                                   const PresetOptions& po) {
    namespace cp_sbtl = CoolProp::sbtl;
    cp_sbtl::SurfaceSpec spec;
    switch (pair) {
        case CoolProp::HmassP_INPUTS:
            spec = cp_sbtl::presets::ph_subcritical(source, po);
            break;
        case CoolProp::PT_INPUTS:
            spec = cp_sbtl::presets::pt_subcritical(source, po);
            break;
        case CoolProp::DmassT_INPUTS:
            // DmassT is temperature-indexed — dt_subcritical ignores
            // po.p_min (the pressure floor does not apply there).
            spec = cp_sbtl::presets::dt_subcritical(source, po);
            break;
        case CoolProp::PSmass_INPUTS:
            spec = cp_sbtl::presets::ps_subcritical(source, po);
            break;
        default:
            throw ValueError("SVDSBTL backend: no preset registered for the requested input pair");
    }
    spec.source_backend = source_backend;
    return cp_sbtl::build_surface(source, std::move(spec));
}

// Parse + validate `options_json` against the SVDSBTL schema.  Returns
// the canonical-JSON form (or "{}" when options_json was empty); throws
// CoolProp::ValueError on schema violation.
std::string parse_and_canonicalise(const std::string& options_json) {
    if (options_json.empty()) {
        return "{}";
    }
    CoolProp::validate_json_against_schema(options_json, kSVDSBTLOptionsSchemaJson);
    return CoolProp::to_canonical_json_str(options_json);
}

// FNV-1a 64 over the canonical options blob — mirrors the opthash the
// SVDSurface cache uses so the critpatch sidecar lives alongside the
// matching .svd.bin.z files and shares the cache-invalidation lifetime.
// The implementation here is intentionally a tiny duplicate; the
// canonical version lives in SVDSurfaceSerializer but isn't exposed
// for re-use, and the cost of duplicating is one short function.
std::uint64_t opthash_fnv1a_(const std::string& s) noexcept {
    constexpr std::uint64_t kFNVOffset = 0xcbf29ce484222325ULL;
    constexpr std::uint64_t kFNVPrime = 0x100000001b3ULL;
    std::uint64_t h = kFNVOffset;
    for (const unsigned char c : s) {
        h ^= static_cast<std::uint64_t>(c);
        h *= kFNVPrime;
    }
    return h;
}

// Critpatch sidecar path: lives next to the .svd.bin.z files so
// directory-level cache cleanup catches both.  The opthash binds the
// patch to the same options blob the surfaces were built against.
//
// Defense-in-depth against path traversal: rejects any
// fluid_name / source_backend containing '/', '\\', or "..".  Mirrors
// the validation in SVDSurfaceSerializer::default_cache_path; without
// it a caller passing an attacker-controlled fluid name through
// AbstractState::factory could read or write outside the cache dir,
// since `default_cache_dir()` derives the parent dir from
// `getenv("HOME")` (CodeQL tracks this as taint on fopen).
std::filesystem::path critpatch_cache_path_(const std::string& fluid_name, const std::string& source_backend, const std::string& options_canonical) {
    const auto unsafe = [](const std::string& s) {
        return s.empty() || s.find('/') != std::string::npos || s.find('\\') != std::string::npos || s.find("..") != std::string::npos;
    };
    if (unsafe(fluid_name)) {
        throw std::invalid_argument("SVDSBTLBackend: invalid fluid_name (must be a bare component name)");
    }
    if (unsafe(source_backend)) {
        throw std::invalid_argument("SVDSBTLBackend: invalid source_backend");
    }
    const std::filesystem::path dir = CoolProp::sbtl::SVDSurfaceSerializer::default_cache_dir();
    const std::uint64_t opthash = opthash_fnv1a_(options_canonical);
    // Match the SVDSurface filename pattern <Fluid>.<Source>.<...>.<opthash>.svd.bin.z
    // but with .critpatch.bin suffix (no zlib — too small to matter).
    std::ostringstream oss;
    oss << fluid_name << '.' << source_backend << ".critpatch." << std::hex << opthash << ".bin";
    return dir / oss.str();
}

}  // namespace

SVDSBTLBackend::SVDSBTLBackend(const std::string& fluid_name,      // NOLINT(modernize-pass-by-value)
                               const std::string& source_backend,  // NOLINT(modernize-pass-by-value)
                               const std::string& options_json)    // NOLINT(modernize-pass-by-value)
  : fluid_name_(fluid_name), source_backend_(source_backend), mole_fractions_({1.0}), options_canonical_(parse_and_canonicalise(options_json)) {
    // Validate the source backend up-front.  Anything outside the
    // {HEOS, REFPROP, IF97} set is rejected — adding a new source
    // (SRK, PR, etc.) needs deliberate per-backend wiring for
    // two-phase routing and the cache-key encoding below, so failing
    // loudly is better than silently mismatching.
    if (source_backend_ != "HEOS" && source_backend_ != "REFPROP" && source_backend_ != "IF97") {
        throw ValueError(format("SVDSBTL: unsupported source backend '%s' (allowed: HEOS, REFPROP, IF97)", source_backend_.c_str()));
    }
    // IF97 is parameterized — the only fluid it knows is Water.  Catch
    // the obvious misuse here rather than at the first surface-build
    // call.
    if (source_backend_ == "IF97" && fluid_name != "Water") {
        throw ValueError(format("SVDSBTL&IF97 is Water-only; got fluid '%s'", fluid_name.c_str()));
    }
    // Opt-in `prebuild`: materialize every supported surface at
    // construction instead of lazy-loading the secondary pairs.  Off by
    // default (lazy); turned on for docs / benchmarking / warm-cache
    // pre-fill, where building up front also turns a build/env failure
    // into a loud construction-time throw instead of a silent blank on
    // the first query.  (CoolProp-rhb5)
    bool prebuild = false;
    {
        nlohmann::json opts = cpjson::parse(options_canonical_.empty() ? "{}" : options_canonical_);
        if (opts.is_object() && opts.contains("prebuild")) {
            prebuild = cpjson::get_bool(opts, "prebuild");
            // prebuild is build-eagerness only — it changes neither surface
            // nor critpatch content.  Strip it from the canonical options
            // so the cache opthash (and the critpatch sidecar key) are
            // identical to a default no-prebuild instance: a
            // {"prebuild":true} build therefore shares its serialized
            // surfaces with plain SVDSBTL&<source> queries (and vice
            // versa), rather than caching a redundant copy under a
            // different opthash.
            opts.erase("prebuild");
            options_canonical_ = to_canonical_json_str(opts.dump());
        }
    }
    for (const auto pair : kSupportedPairs) {
        // DmassT/DmolarT share the DmassT_INPUTS surface, built lazily on
        // the first density-input query (see update()/fast_evaluate()).
        // Building it eagerly here would (a) make HmassP/PT-only consumers
        // pay for the heavy dt_subcritical dense SVD, and (b) THROW for an
        // IF97 source — dt_subcritical can't be sampled on a (D,T) grid
        // from IF97, producing an all-NaN matrix (this broke the
        // SVDSBTL&IF97 docs example at construction).  (CoolProp-eal will
        // generalize lazy loading to every pair.)
        //
        // PSmass/PSmolar are likewise lazy: PS is a secondary pair, so
        // HmassP/PT-only consumers should not pay the heavy ps_subcritical
        // dense SVD up front.  Built on the first (p, s) query in
        // update()/fast_evaluate().
        //
        // `prebuild` overrides reason (a) — the caller has asked for the
        // whole fluid — but NOT reason (b): a DmassT surface still can't
        // be sampled from an IF97 source, so it stays skipped for IF97
        // even under prebuild (PT/HmassP/PSmass build fine for IF97).
        if (!prebuild && (pair == ::CoolProp::DmassT_INPUTS || pair == ::CoolProp::PSmass_INPUTS)) {
            continue;
        }
        if (pair == ::CoolProp::DmassT_INPUTS && source_backend_ == "IF97") {
            continue;
        }
        ensure_surface_(pair);
    }
    build_critical_patch_(options_canonical_);
}

bool SVDSBTLBackend::available_in_high_level() {
    // Off by default — PropsSI rebuilds the AbstractState per call and
    // loading an SVDSurface from .svd.bin.z costs ~80 ms per
    // construction, vs ~5 us for the actual evaluation.  Throughput
    // workloads should use AbstractState directly + update() / batched
    // fast_evaluate.  Set ALLOW_SVDSBTL_IN_PROPSSI=true to opt back
    // in (e.g. for one-off interactive queries where the constructor
    // cost is irrelevant).
    return get_config_bool(ALLOW_SVDSBTL_IN_PROPSSI);
}

bool SVDSBTLBackend::CriticalPatch::contains(::CoolProp::input_pairs pair, double a, double b) const noexcept {
    if (!enabled) {
        return false;
    }
    const auto it = bbox_per_pair.find(static_cast<int>(pair));
    if (it == bbox_per_pair.end()) {
        return false;
    }
    const auto& bb = it->second;
    return (a >= bb.a_lo && a <= bb.a_hi && b >= bb.b_lo && b <= bb.b_hi);
}

std::shared_ptr<::CoolProp::AbstractState> SVDSBTLBackend::patch_source_ref_() {
    if (patch_source_) {
        return patch_source_;
    }
    // critical_patch_.source is empty when the options blob left it
    // null / default — fall back to the SVD truth source so the
    // patch IS the source by definition.
    const std::string backend = critical_patch_.source.empty() ? source_backend_ : critical_patch_.source;
    patch_source_.reset(::CoolProp::AbstractState::factory(backend, fluid_name_));
    return patch_source_;
}

void SVDSBTLBackend::build_critical_patch_(const std::string& options_canonical) {
    critical_patch_ = CriticalPatch{};  // disabled by default
    // Default behaviour when no options are supplied (mode unset) is
    // "auto", which now triggers the binary-search shrink loop in
    // auto_calibrate_critical_bbox_() (cached to a sidecar file so
    // subsequent constructions skip it).
    std::string mode = "auto";
    // Fallback multipliers: Water-sized.  Used when mode == "fixed"
    // without a bbox override, or when the auto-calibration fails
    // (source backend throws) and we can't load a cached result either.
    std::array<double, 4> bbox_mult = {0.95, 1.05, 0.75, 1.15};  // T_lo, T_hi, p_lo, p_hi
    bool user_supplied_bbox = false;
    std::string patch_source;

    if (!options_canonical.empty()) {
        const nlohmann::json opts = cpjson::parse(options_canonical);
        if (opts.is_object() && opts.contains("critical_patch") && opts.at("critical_patch").is_object()) {
            const auto& cp = opts.at("critical_patch");
            if (cp.contains("mode") && cp.at("mode").is_string()) {
                mode = cp.at("mode").get<std::string>();
            }
            if (cp.contains("source") && cp.at("source").is_string()) {
                patch_source = cp.at("source").get<std::string>();
            }
            if (cp.contains("bbox") && cp.at("bbox").is_array() && cp.at("bbox").size() == 4) {
                for (std::size_t i = 0; i < 4; ++i) {
                    bbox_mult[i] = cp.at("bbox").at(i).get<double>();
                }
                user_supplied_bbox = true;
            }
        }
    }
    if (mode == "off") {
        return;
    }
    if (mode != "auto" && mode != "fixed") {
        // schema validation should have caught this already
        return;
    }
    // Mode "auto" → try cache, then calibrate if missing.  User-supplied
    // bbox overrides auto-calibration even in "auto" mode (escape hatch
    // for users who want to pin the bbox without flipping mode to "fixed").
    if (mode == "auto" && !user_supplied_bbox) {
        const auto cached = load_critpatch_cache_(fluid_name_, source_backend_, options_canonical);
        if (cached) {
            bbox_mult = *cached;
        } else {
            // Need a patch_source for the calibration probe; ensure it's
            // set up before the calibrator pokes at SVD properties (the
            // calibration only reads from the SVD surface + source_, but
            // future calibrators may want patch_source_, so initialise
            // here to keep the calibrator simple).
            critical_patch_.source = patch_source;
            try {
                bbox_mult = auto_calibrate_critical_bbox_();
                save_critpatch_cache_(fluid_name_, source_backend_, options_canonical, bbox_mult);
            } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
                // Calibrator threw (source backend rejected a probe,
                // SVD surface missing a property, etc.) — fall back to
                // the Water-sized defaults rather than disabling the
                // patch entirely.  The defaults are conservative
                // (over-large) for non-water fluids, but better
                // accuracy than no patch.
            }
        }
    }

    // Set the patch source up-front so an invalid `critical_patch.source`
    // override fails at construction (factory throws on unknown backend)
    // instead of on the first in-patch query.  Also: the bbox must be
    // sampled from the SAME backend that will serve the patch — if a
    // user runs SVDSBTL&IF97 with critical_patch.source="HEOS", the
    // (p, h) envelope has to come from HEOS's h(T, p) so the in-patch
    // (h, p) classification matches what HEOS would return.
    critical_patch_.enabled = true;
    critical_patch_.source = patch_source;
    auto src = patch_source_ref_();  // factories the patch backend; throws on invalid

    const double Tc = src->T_critical();
    const double pc = src->p_critical();
    const double T_lo = bbox_mult[0] * Tc;
    const double T_hi = bbox_mult[1] * Tc;
    const double p_lo = bbox_mult[2] * pc;
    const double p_hi = bbox_mult[3] * pc;

    // PT_INPUTS — native bbox is (p, T): a = p, b = T.
    critical_patch_.bbox_per_pair[static_cast<int>(::CoolProp::PT_INPUTS)] = CriticalPatchBbox{p_lo, p_hi, T_lo, T_hi};

    // HmassP_INPUTS — bbox is (p, h); PSmass_INPUTS — bbox is (p, s).
    // Walk the (T, p) bbox's perimeter once through the PATCH backend
    // and take the conservative axis-aligned envelope of the resulting
    // h and s values (both collected from the same probe).  Catches
    // every (T, p) in the critical box; may include cells slightly
    // outside (false positive → source backend used outside the strict
    // box, correct but slightly slower; no false negatives).
    double h_lo = std::numeric_limits<double>::infinity();
    double h_hi = -std::numeric_limits<double>::infinity();
    double s_lo = std::numeric_limits<double>::infinity();
    double s_hi = -std::numeric_limits<double>::infinity();
    constexpr int kPerimeterSamples = 24;
    auto try_hs = [&](double T, double p) {
        try {
            src->update(::CoolProp::PT_INPUTS, p, T);
            const double h = src->hmass();
            if (std::isfinite(h)) {
                h_lo = std::min(h_lo, h);
                h_hi = std::max(h_hi, h);
            }
            const double s = src->smass();
            if (std::isfinite(s)) {
                s_lo = std::min(s_lo, s);
                s_hi = std::max(s_hi, s);
            }
        } catch (...) {  // NOLINT(bugprone-empty-catch)
            // Source may reject (T, p) inside the dome at p just below
            // pc — those cells aren't critical-supercritical anyway.
            // Skipping them only narrows the h/s-bbox, which is the
            // safer direction.
        }
    };
    for (int i = 0; i <= kPerimeterSamples; ++i) {
        const double f = static_cast<double>(i) / kPerimeterSamples;
        try_hs(T_lo + f * (T_hi - T_lo), p_lo);
        try_hs(T_lo + f * (T_hi - T_lo), p_hi);
        try_hs(T_lo, p_lo + f * (p_hi - p_lo));
        try_hs(T_hi, p_lo + f * (p_hi - p_lo));
    }
    if (std::isfinite(h_lo) && std::isfinite(h_hi) && h_lo < h_hi) {
        critical_patch_.bbox_per_pair[static_cast<int>(::CoolProp::HmassP_INPUTS)] = CriticalPatchBbox{p_lo, p_hi, h_lo, h_hi};
    }
    if (std::isfinite(s_lo) && std::isfinite(s_hi) && s_lo < s_hi) {
        critical_patch_.bbox_per_pair[static_cast<int>(::CoolProp::PSmass_INPUTS)] = CriticalPatchBbox{p_lo, p_hi, s_lo, s_hi};
    }

    // NOTE: DmassT / DmolarT are intentionally NOT critical-patched yet.
    // A DT bbox would route the whole critical box to patch_source_, but
    // the patch source isn't guaranteed to serve DmassT_INPUTS (IF97 in
    // particular), so an unconditional DT bbox would turn atlas-servable
    // near-critical DT cells into OOB for SVDSBTL&IF97.  Doing it safely
    // needs a patch-source DmassT capability probe + dedicated tests —
    // tracked as a follow-up (PR #2984 / CoolProp-i7j).  Until then DT
    // states in the [0.999, 1.001]·Tc gap fall through to the DT-dome
    // path or OOB, same as the no-critical-patch default.
}

std::array<double, 4> SVDSBTLBackend::auto_calibrate_critical_bbox_() {
    // Binary-search-shrink the (T_lo, T_hi, p_lo, p_hi) bbox toward
    // (Tc, pc) until the strip JUST OUTSIDE the candidate patch can be
    // served by the SVD within IAPWS conformance budgets.  Each of the
    // four axes is shrunk independently; the resulting bbox is the
    // smallest axis-aligned rectangle that contains every cell where
    // the rank-r SVD's reconstruction error exceeds budget.
    //
    // Why "just outside" matters: probes INSIDE the candidate bbox
    // would be served by the patch (the source backend, by definition
    // exact), so testing them tells us nothing about SVD accuracy.
    // Probes just outside are the ones the SVD will own if we accept
    // this candidate, so those are the ones whose error budget we
    // need to respect.

    auto src = patch_source_ref_();
    const double Tc = src->T_critical();
    const double pc = src->p_critical();

    // Per-property relative-error budgets for the calibration probe.
    // INTENTIONALLY 50-100x wider than the IAPWS G13-15 perm values
    // (200 ppm rho, 100 ppm h, 200 ppm s, 1000 ppm w).  The patch
    // exists to cover the critical-singularity rank-truncation cusp
    // — where SVD reconstruction error reaches ~1%-10% in rho and
    // ~5%-50% in w.  Thin-support corner cells far from the critical
    // point also exceed the strict IAPWS budget by 10-100x (this is
    // CoolProp-3c4 accuracy ceiling territory), but they're not what
    // the patch is for — the patch can't cover scattered failures
    // with an axis-aligned bbox.  Using IAPWS-strict budgets here
    // would refuse to shrink the patch because every wide candidate
    // includes some corner outliers; relaxing to "1% relative" cleanly
    // separates the critical-cusp divergence from the corner ceiling.
    constexpr double kBudget_rho = 1.0e-2;  // 1%
    constexpr double kBudget_h = 1.0e-2;    // 1%
    constexpr double kBudget_s = 1.0e-2;    // 1%
    constexpr double kBudget_w = 5.0e-2;    // 5%

    // The PT surface is where the calibration probes go — it's the
    // canonical (T, p) → (rho, h, s, w) source the patch shape is
    // expressed in.  Bail to defaults if the surface isn't registered
    // (would indicate a non-standard preset; safer to use the
    // Water-sized fallback than to error out).
    const auto it = surfaces_.find(static_cast<int>(::CoolProp::PT_INPUTS));
    if (it == surfaces_.end() || !it->second) {
        throw ValueError("SVDSBTL auto-calibration: no PT_INPUTS surface registered");
    }
    const auto& pt_surface = *it->second;

    // Probe at (T, p): SVD vs source; return max relative error across
    // (rho, h, s, w), or NaN if either side rejects the point.
    auto probe_rel_err = [&](double T, double p) -> double {
        try {
            src->update(::CoolProp::PT_INPUTS, p, T);
            const double rho_src = src->rhomass();
            const double h_src = src->hmass();
            const double s_src = src->smass();
            double w_src = std::numeric_limits<double>::quiet_NaN();
            try {
                w_src = src->speed_sound();
            } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
                // Some sources reject speed_sound near the critical
                // point — skip and rely on (rho, h, s) alone there.
            }

            const auto resolved = pt_surface.resolve(p, T);
            if (resolved.region_idx < 0) {
                // SVD has no region containing this (p, T); not an
                // accuracy failure, just out-of-table.  Don't reject
                // the shrink based on it — the strip walker checks
                // multiple probes per axis position, and at least one
                // should land inside the SVD envelope.
                return std::numeric_limits<double>::quiet_NaN();
            }
            const double rho_svd = pt_surface.eval_with_region(::CoolProp::iDmass, resolved.region_idx, resolved.svd_x, resolved.svd_y);
            const double h_svd = pt_surface.eval_with_region(::CoolProp::iHmass, resolved.region_idx, resolved.svd_x, resolved.svd_y);
            const double s_svd = pt_surface.eval_with_region(::CoolProp::iSmass, resolved.region_idx, resolved.svd_x, resolved.svd_y);
            double w_svd = std::numeric_limits<double>::quiet_NaN();
            if (pt_surface.contains_property(::CoolProp::ispeed_sound)) {
                w_svd = pt_surface.eval_with_region(::CoolProp::ispeed_sound, resolved.region_idx, resolved.svd_x, resolved.svd_y);
            }

            double worst = 0.0;
            if (std::isfinite(rho_src) && std::isfinite(rho_svd) && std::abs(rho_src) > 0.0) {
                worst = std::max(worst, std::abs(rho_svd - rho_src) / std::abs(rho_src) / kBudget_rho);
            }
            if (std::isfinite(h_src) && std::isfinite(h_svd) && std::abs(h_src) > 0.0) {
                worst = std::max(worst, std::abs(h_svd - h_src) / std::abs(h_src) / kBudget_h);
            }
            if (std::isfinite(s_src) && std::isfinite(s_svd) && std::abs(s_src) > 0.0) {
                worst = std::max(worst, std::abs(s_svd - s_src) / std::abs(s_src) / kBudget_s);
            }
            if (std::isfinite(w_src) && std::isfinite(w_svd) && std::abs(w_src) > 0.0) {
                worst = std::max(worst, std::abs(w_svd - w_src) / std::abs(w_src) / kBudget_w);
            }
            // worst is in units of "fraction of the largest budget";
            // <= 1 means all properties pass; > 1 means at least one
            // property exceeds its budget.
            return worst;
        } catch (const std::exception&) {
            // Source rejected the probe — return NaN so the caller
            // treats this probe as a no-op (doesn't influence the
            // shrink decision either way).
            return std::numeric_limits<double>::quiet_NaN();
        }
    };

    // Strip walker: at a candidate axis multiplier, sample N probes
    // along the strip JUST OUTSIDE that axis (at axis-position ± eps,
    // varying over the other two axes' wide span).  Returns true iff
    // at least N - kStripOutlierBudget finite probes pass their budget
    // — isolated outliers (typically thin-Hermite-support cells at
    // region edges, e.g. just-below-dome cells near critical) don't
    // block the calibrator from shrinking past them.  The patch is
    // for the critical-singularity divergence, not the
    // CoolProp-3c4 corner-cell accuracy ceiling; the outlier budget
    // cleanly separates the two.
    constexpr int kStripSamples = 12;
    constexpr int kStripOutlierBudget = 2;  // tolerate up to 2/12 = 17% outliers
    constexpr double kStripEps = 0.005;     // 0.5% offset outside the candidate
    auto strip_passes = [&](double T_lo_mult, double T_hi_mult, double p_lo_mult, double p_hi_mult, int axis) {
        // axis: 0=T_lo, 1=T_hi, 2=p_lo, 3=p_hi
        const double T_lo = T_lo_mult * Tc;
        const double T_hi = T_hi_mult * Tc;
        const double p_lo = p_lo_mult * pc;
        const double p_hi = p_hi_mult * pc;
        // Outer reference for the variation axis: matches the
        // Water-default bbox so the strip walker samples the region
        // that the default patch would have covered.  Going wider
        // would sample cells well outside the default patch where
        // the SVD is the only owner anyway — those are CoolProp-3c4
        // accuracy-ceiling territory and shouldn't influence the
        // patch shape.
        constexpr double kT_outer_lo = 0.95;
        constexpr double kT_outer_hi = 1.05;
        constexpr double kp_outer_lo = 0.75;
        constexpr double kp_outer_hi = 1.15;
        int n_finite = 0;
        int n_outliers = 0;
        for (int i = 0; i < kStripSamples; ++i) {
            const double f = (i + 0.5) / kStripSamples;
            double T_probe = T_lo, p_probe = p_lo;
            if (axis == 0) {
                T_probe = T_lo * (1.0 - kStripEps);  // just below T_lo
                p_probe = (kp_outer_lo + f * (kp_outer_hi - kp_outer_lo)) * pc;
            } else if (axis == 1) {
                T_probe = T_hi * (1.0 + kStripEps);  // just above T_hi
                p_probe = (kp_outer_lo + f * (kp_outer_hi - kp_outer_lo)) * pc;
            } else if (axis == 2) {
                p_probe = p_lo * (1.0 - kStripEps);  // just below p_lo
                T_probe = (kT_outer_lo + f * (kT_outer_hi - kT_outer_lo)) * Tc;
            } else {
                p_probe = p_hi * (1.0 + kStripEps);  // just above p_hi
                T_probe = (kT_outer_lo + f * (kT_outer_hi - kT_outer_lo)) * Tc;
            }
            const double err = probe_rel_err(T_probe, p_probe);
            if (std::isfinite(err)) {
                ++n_finite;
                if (err > 1.0) {
                    ++n_outliers;
                }
            }
        }
        // Require: at least one finite probe (otherwise we're shrinking
        // past a region the source rejects entirely), AND fewer than
        // kStripOutlierBudget budget-violating probes.
        return n_finite > 0 && n_outliers <= kStripOutlierBudget;
    };

    // Binary search per axis.  Strategy: start at the Water-sized
    // defaults (which are known to give G13-15 conformant SVDSBTL&IF97
    // for water) and only SHRINK toward 1.0 (= the critical point).
    // Never widen — that way Water gets back its tested bbox, and
    // other fluids tighten if their critical regions are less
    // extended.
    //
    // Axis indices: 0=T_lo, 1=T_hi, 2=p_lo, 3=p_hi.
    // "safer" (wider patch) is the default; "tighter" is 1.0.
    std::array<double, 4> defaults = {0.95, 1.05, 0.75, 1.15};
    // CoolProp-4u9: cap T_hi multiplier so the patch doesn't claim
    // T territory beyond the HEOS validity envelope.  For fluids
    // where T_max barely exceeds Tc (R245fa: T_max=440 K, Tc=427 K),
    // the default T_hi_mult=1.05 maps to T_hi=448 K > T_max=440 K.
    // The HmassP-envelope perimeter walk skips those unreachable
    // corners, leaving the (h, p) bbox missing cells with h≈h_crit
    // at p just below pc — runtime HmassP queries in that thin
    // strip get NaN (atlas misses; patch bbox check fails) even
    // though they're physically inside the patch's (T, p) rectangle.
    // Clamping T_hi_mult at (T_max - 0.5) / Tc keeps the patch's
    // T extent inside HEOS validity; the perimeter walk produces a
    // tight, correct (h, p) bbox and the strip routes cleanly.
    // No-op for fluids with T_max >> Tc (Water, CO2, methane —
    // cap value > 1.05).
    const double T_hi_cap = (src->Tmax() - 0.5) / Tc;
    if (T_hi_cap < defaults[1]) {
        defaults[1] = T_hi_cap;
    }
    std::array<double, 4> tight = {1.0, 1.0, 1.0, 1.0};
    std::array<double, 4> mults = defaults;
    constexpr int kBisectSteps = 6;  // 6 = 1/64 multiplier resolution
    for (int axis = 0; axis < 4; ++axis) {
        // First confirm the default passes the strip test — if it
        // doesn't (e.g. a fluid where the default patch is itself too
        // small), bail to defaults and let the user override via
        // critical_patch.bbox.  No widening here.
        if (!strip_passes(mults[0], mults[1], mults[2], mults[3], axis)) {
            continue;
        }
        // The (safe, aggressive) pair encodes the shrink direction per
        // axis: safe = defaults[axis] (Water-sized, known to pass);
        // aggressive = 1.0 (smallest patch, may or may not pass).  Lo-
        // side axes (0=T_lo, 2=p_lo) have safe < aggressive numerically;
        // hi-side axes (1=T_hi, 3=p_hi) have safe > aggressive.  Either
        // way, the bisection moves `safe` toward `aggressive` whenever
        // the candidate passes, and pulls `aggressive` toward `safe`
        // when it doesn't.
        double safe = defaults[axis];
        double aggressive = tight[axis];
        for (int step = 0; step < kBisectSteps; ++step) {
            const double mid = 0.5 * (safe + aggressive);
            auto trial = mults;
            trial[axis] = mid;
            if (strip_passes(trial[0], trial[1], trial[2], trial[3], axis)) {
                safe = mid;
            } else {
                aggressive = mid;
            }
        }
        // safe is the latest known-passing value — commit it.
        mults[axis] = safe;
    }
    return mults;
}

std::optional<std::array<double, 4>> SVDSBTLBackend::load_critpatch_cache_(const std::string& fluid_name, const std::string& source_backend,
                                                                           const std::string& options_canonical) {
    const auto path = critpatch_cache_path_(fluid_name, source_backend, options_canonical);
    std::error_code ec;
    if (!std::filesystem::exists(path, ec) || ec) {
        return std::nullopt;
    }
    // Use FILE* (POSIX/Windows-portable; binary fixed-width 44 bytes is
    // small enough that stdio buffering overhead is irrelevant).
    std::FILE* f = std::fopen(path.string().c_str(), "rb");
    if (!f) {
        return std::nullopt;
    }
    std::array<char, 8> magic{};
    std::uint32_t version = 0;
    std::array<double, 4> mults{};
    const auto rd_n = std::fread(magic.data(), 1, 8, f);
    if (rd_n != 8 || std::string(magic.data(), 8) != "CPCRITPB") {
        (void)std::fclose(f);
        return std::nullopt;
    }
    // v1 → v2: T_hi_cap clamp added in CoolProp-4u9.  Bump to invalidate
    // pre-clamp caches so they get recomputed with the corrected ceiling
    // (no migration — calibrator is cheap, re-runs on cache miss).
    if (std::fread(&version, sizeof(version), 1, f) != 1 || version != 2u) {
        (void)std::fclose(f);
        return std::nullopt;
    }
    if (std::fread(mults.data(), sizeof(double), 4, f) != 4) {
        (void)std::fclose(f);
        return std::nullopt;
    }
    (void)std::fclose(f);
    // Sanity-clamp: refuse obviously-wrong cached values rather than
    // letting a corrupt file silently produce a broken patch.
    if (!(mults[0] > 0.0 && mults[0] < mults[1] && mults[1] < 2.0 && mults[2] > 0.0 && mults[2] < mults[3] && mults[3] < 10.0)) {
        return std::nullopt;
    }
    return mults;
}

void SVDSBTLBackend::save_critpatch_cache_(const std::string& fluid_name, const std::string& source_backend, const std::string& options_canonical,
                                           const std::array<double, 4>& mults) {
    const auto path = critpatch_cache_path_(fluid_name, source_backend, options_canonical);
    std::error_code ec;
    std::filesystem::create_directories(path.parent_path(), ec);
    if (ec) {
        // Cache directory inaccessible — non-fatal (the calibration
        // result is still usable in-process; next construction just
        // re-runs the calibrator).
        return;
    }
    constexpr std::array<char, 8> kMagic = {'C', 'P', 'C', 'R', 'I', 'T', 'P', 'B'};
    constexpr std::uint32_t kVersion = 2;
    constexpr std::size_t kPayloadSize = kMagic.size() + sizeof(kVersion) + 4 * sizeof(double);
    std::array<char, kPayloadSize> buf{};
    std::memcpy(buf.data(), kMagic.data(), kMagic.size());
    std::memcpy(buf.data() + kMagic.size(), &kVersion, sizeof(kVersion));
    std::memcpy(buf.data() + kMagic.size() + sizeof(kVersion), mults.data(), 4 * sizeof(double));
    // Atomic write: temp + rename, with owner-only perms applied to the
    // temp file before rename so multi-process notebook builds never
    // see a torn-write critpatch sidecar (CoolProp-4no.2).  Any failure
    // is non-fatal — same semantics as the previous fopen-then-fwrite
    // path: cache miss on next load just re-runs the calibrator.
    try {
        ::write_bytes_atomic(path, buf.data(), buf.size(), /*restrict_perms=*/true);
    } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
        // swallowed — cache write is best-effort
    }
}

std::shared_ptr<CoolProp::AbstractState> SVDSBTLBackend::source_reference_() {
    if (!source_) {
        // The single AbstractState handle that all internal
        // truth-source calls go through: HEOS sampling for the SVD
        // tables, SuperAncillary (when source is HEOS), critical-
        // patch fallback queries, and two-phase PQ/QT routing.
        //
        // IF97's factory takes the literal "Water" (its only fluid);
        // the constructor already validated fluid_name_=="Water" for
        // this source.  REFPROP and HEOS use the same fluid string.
        source_.reset(CoolProp::AbstractState::factory(source_backend_, fluid_name_));
    }
    return source_;
}

std::shared_ptr<superancillary::SuperAncillary<std::vector<double>>> SVDSBTLBackend::superanc_() {
    if (superanc_resolved_) {
        return superanc_cached_;
    }
    superanc_resolved_ = true;
    // The SuperAncillary lives on the per-fluid CoolPropFluid record;
    // HEOSMixtureBackend wraps it via get_superanc().  Anything that's
    // not a HEOS instance simply won't have one.
    auto* helmholtz_ptr = dynamic_cast<CoolProp::HelmholtzEOSMixtureBackend*>(source_reference_().get());
    if (helmholtz_ptr == nullptr) {
        return superanc_cached_;  // stays nullptr
    }
    try {
        superanc_cached_ = helmholtz_ptr->get_superanc();
    } catch (const std::exception&) {
        // get_superanc() throws for pseudo-pure / mixtures; SVDSBTL
        // already rejects those at construction, so this is mostly
        // defensive.  Leave superanc_cached_ as nullptr.
        return superanc_cached_;
    }
    if (superanc_cached_) {
        // Caloric expansions (h_sat, s_sat, u_sat) are lazily built --
        // trigger them eagerly here so the first two-phase calc_*
        // doesn't pay the build cost on the hot path.  Cheap (~30 ms
        // total) and runs once per backend lifetime.
        helmholtz_ptr->ensure_caloric_superancillaries();
    }
    return superanc_cached_;
}

void SVDSBTLBackend::set_mole_fractions(const std::vector<CoolPropDbl>& mole_fractions) {
    if (mole_fractions.size() > 1) {
        throw NotImplementedError("SVDSBTL backend is pure-fluid only; mixtures are not supported");
    }
    if (mole_fractions.size() == 1) {
        mole_fractions_ = mole_fractions;
    }
}

std::vector<CoolProp::input_pairs> SVDSBTLBackend::registered_input_pairs() const {
    std::vector<CoolProp::input_pairs> out;
    out.reserve(surfaces_.size());
    for (const auto& kv : surfaces_) {
        out.push_back(static_cast<CoolProp::input_pairs>(kv.first));
    }
    return out;
}

bool SVDSBTLBackend::sat_surrogate_consulted() const noexcept {
    return sat_surrogate_used_;
}

const CoolProp::sbtl::SaturationSurrogate* SVDSBTLBackend::sat_surrogate_handle_() {
    if (sat_surrogate_resolved_) {
        return sat_surrogate_.get();
    }
    sat_surrogate_resolved_ = true;
    // NOTE: surrogate build consumes the source backend's update slot
    // (mutates source_reference_() state via ~2*n_knots QT_INPUTS
    // calls before returning).  Same shared state any other resolve_
    // point path uses; downstream callers must always update before
    // reading, which they already do — but if a future refactor caches
    // source state across calls, this build path will silently invalidate
    // it on the first sat-touching call after construction.
    // Surrogate is the fallback for sources without a SuperAncillary;
    // if we have one we shouldn't build the surrogate at all.  Callers
    // (sat_T_from_p_ / sat_eval_) prefer SA on the resolution side too,
    // so even if we did build it the surrogate would be unused — saves
    // ~50-100 source.update calls on HEOS-source backends.
    if (superanc_() != nullptr) {
        return nullptr;
    }
    try {
        auto src = source_reference_();
        if (!src) {
            return nullptr;
        }
        sat_surrogate_ = CoolProp::sbtl::SaturationSurrogate::build_from_source(*src);
    } catch (const std::exception&) {
        sat_surrogate_.reset();
    }
    return sat_surrogate_.get();
}

double SVDSBTLBackend::sat_T_from_p_(double p) {
    try {
        auto sa = superanc_();
        if (sa) {
            return sa->get_T_from_p(p);
        }
        const auto* surrogate = sat_surrogate_handle_();
        if (surrogate) {
            sat_surrogate_used_ = true;
            return surrogate->get_T_from_p(p);
        }
    } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
        // Out-of-range / numerical failure: signal NaN so callers
        // can fall through to source PQ.  Matches the "throw on
        // surrogate, NaN on backend interface" contract documented
        // on SaturationSurrogate.
    }
    return std::nan("");
}

double SVDSBTLBackend::sat_eval_(double T, char what, int side) {
    try {
        auto sa = superanc_();
        if (sa) {
            return sa->eval_sat(T, what, static_cast<short>(side));
        }
        const auto* surrogate = sat_surrogate_handle_();
        if (surrogate) {
            sat_surrogate_used_ = true;
            return surrogate->eval_sat(T, what, side);
        }
    } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch) see sat_T_from_p_ note
    }
    return std::nan("");
}

void SVDSBTLBackend::ensure_surface_(CoolProp::input_pairs pair) {
    // Idempotent: the lazy DmassT/DmolarT callers in update() /
    // fast_evaluate() may invoke this on every query, so skip the
    // load/build when the surface is already resident.
    if (surfaces_.find(static_cast<int>(pair)) != surfaces_.end()) {
        return;
    }
    namespace cp_sbtl = CoolProp::sbtl;
    // Cache filename: <fluid>.<source>.<input_pair_name>.<opthash>.svd.bin.z
    //  - input_pair_name (e.g. "PT_INPUTS", "HmassP_INPUTS") instead
    //    of the raw enum int, so reordering DataStructures.h's
    //    `input_pairs` enum can no longer silently misalign caches
    //    (closes CoolProp-b6v).
    //  - opthash: 16-hex FNV-1a 64 prefix over the canonical-JSON
    //    options blob; two different option sets get different cache
    //    files automatically (canonical "{}" is treated as the all-
    //    defaults case so the no-options path still picks up its
    //    intended cache file).
    const std::string opthash = to_hex16(fnv1a_64(options_canonical_.empty() ? std::string{"{}"} : options_canonical_));
    const std::string path = cp_sbtl::SVDSurfaceSerializer::default_cache_path(fluid_name_, source_backend_, pair, opthash);
    std::unique_ptr<cp_sbtl::SVDSurface> surface;

    if (std::filesystem::exists(path)) {
        try {
            surface = std::make_unique<cp_sbtl::SVDSurface>(cp_sbtl::SVDSurfaceSerializer::load_from_file(path));
        } catch (const std::exception&) {
            // Corrupted cache — fall through to rebuild.  Logging would
            // be nice here but TabularBackend doesn't log either.
            surface.reset();
        }
    }

    if (!surface) {
        auto source = source_reference_();
        const nlohmann::json opts = cpjson::parse(options_canonical_.empty() ? "{}" : options_canonical_);
        const PresetOptions preset_opts = resolve_preset_options(opts);
        surface = std::make_unique<cp_sbtl::SVDSurface>(build_surface_for_pair_(*source, source_backend_, pair, preset_opts));
        try {
            cp_sbtl::SVDSurfaceSerializer::save_to_file(*surface, path);
        } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
            // Cache write failure is non-fatal — the in-memory surface
            // still works for this run.
        }
    }

    surfaces_[static_cast<int>(pair)] = std::move(surface);
}

// Near-dome reclassification guard (issue #3190).  See header for the
// full rationale.  Fast-only: never falls back to source-PQ, so the
// single-phase hot path stays cheap.  Leaves `pt` untouched on a false
// return (the caller then accepts the atlas single-phase classification).
bool SVDSBTLBackend::try_fast_dome_reclassify_(PointEvaluation& pt, char what, double p_val, double value_mass) {
    double T_sat = std::numeric_limits<double>::quiet_NaN();
    double yL = std::numeric_limits<double>::quiet_NaN();
    double yV = std::numeric_limits<double>::quiet_NaN();
    try {
        T_sat = sat_T_from_p_(p_val);
        if (!std::isfinite(T_sat)) {
            return false;
        }
        yL = sat_eval_(T_sat, what, 0);
        yV = sat_eval_(T_sat, what, 1);
    } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch) — mirrors the atlas-miss dome blend
        return false;
    }
    if (!std::isfinite(yL) || !std::isfinite(yV) || !(yV > yL)) {
        return false;
    }
    const double y_mol = value_mass * calc_molar_mass();
    const double Q = (y_mol - yL) / (yV - yL);
    // Boundary inclusive, with a small tolerance band so a round-trip
    // input that lands a few ULP outside [yL, yV] (h(p, Q=0) re-flashed
    // is yL +/- rounding) still classifies two-phase.  Outside the band
    // the point is genuinely single-phase.  See kDomeQTol.
    if (Q < -kDomeQTol || Q > 1.0 + kDomeQTol) {
        return false;
    }
    pt.kind = PointEvaluation::Kind::DomeBlend;
    pt.status = CoolProp::fast_evaluate_ok;
    pt.T = T_sat;
    pt.T_sat = T_sat;
    // Clamp sub-tolerance noise onto [0, 1] so the saturated endpoint
    // reports exactly Q=0 / Q=1 and the lever rule returns rhoL / rhoV.
    pt.Q = std::min(1.0, std::max(0.0, Q));
    // Stash the endpoints we already computed so the DomeBlend caloric
    // arms don't re-evaluate them; the opposite-property and rho
    // endpoints stay lazy (ensure_dome_*_endpoints_).
    if (what == 'H') {
        pt.hL_mol = yL;
        pt.hV_mol = yV;
    } else {  // 'S'
        pt.sL_mol = yL;
        pt.sV_mol = yV;
    }
    return true;
}

// resolve_point_: the shared kernel called by both update() and
// fast_evaluate().  Maps (input_pair, v1, v2) to a PointEvaluation
// without mutating any backend state.  The same routing logic — input-
// pair dispatch, critical-patch bbox check, atlas resolve, dome
// detection with sat-line lever-rule — lives in one place so any
// future entry point (batched PropsSI, Python update_array wrapper,
// ...) plugs in by reusing this method.
//
// Two-phase PQ_INPUTS / QT_INPUTS are folded into the DomeBlend kind
// — same sat-line endpoints, same Q, same downstream property dispatch.
SVDSBTLBackend::PointEvaluation SVDSBTLBackend::resolve_point_(CoolProp::input_pairs input_pair, double value1, double value2) {
    PointEvaluation pt;
    pt.input_pair = input_pair;
    pt.v1 = value1;
    pt.v2 = value2;

    // --- PQ / QT inputs: dome by definition, no surface needed. ---
    if (input_pair == CoolProp::PQ_INPUTS || input_pair == CoolProp::QT_INPUTS) {
        double p_sat = 0.0;
        double T_sat = 0.0;
        double Q = 0.0;
        if (input_pair == CoolProp::PQ_INPUTS) {
            p_sat = value1;
            Q = value2;
        } else {
            Q = value1;
            T_sat = value2;
        }
        if (Q < 0.0 || Q > 1.0) {
            throw ValueError("SVDSBTL backend: two-phase Q must be in [0, 1]");
        }
        // Try SA-or-surrogate fast path first; only fall through to
        // source.update PQ/QT when neither sat provider is available.
        // sat_T_from_p_ / sat_eval_ return NaN when both are missing.
        //
        // Only the dome p / T endpoints are resolved here — the saturation
        // ENTHALPY endpoints (hL/hV) and h_mass are NOT (CoolProp-qp0n): a
        // PQ/QT -> p / Q / rho query never needs them, so they are left to
        // the lazy ensure_dome_h_endpoints_ arm, matching the lazy rho / s
        // endpoints and the DmassT dome path.
        const double T_sat_fast = (input_pair == CoolProp::PQ_INPUTS) ? sat_T_from_p_(p_sat) : T_sat;
        double p_sat_fast = (input_pair == CoolProp::PQ_INPUTS) ? p_sat : std::nan("");
        if (input_pair == CoolProp::QT_INPUTS && std::isfinite(T_sat_fast)) {
            p_sat_fast = sat_eval_(T_sat_fast, 'P', 0);
        }
        if (std::isfinite(T_sat_fast) && std::isfinite(p_sat_fast)) {
            T_sat = T_sat_fast;
            p_sat = p_sat_fast;
        } else {
            // Last-resort source-backend PQ/QT fallback — only reached when
            // both SA and the surrogate are unavailable (truly degenerate
            // source, or surrogate-build failure on a fluid REFPROP can't
            // sample cleanly).  Reads only T_sat / p_sat; hL/hV stay lazy.
            auto src = source_reference_();
            if (input_pair == CoolProp::PQ_INPUTS) {
                src->update(CoolProp::PQ_INPUTS, p_sat, 0.0);
                T_sat = src->T();
            } else {
                src->update(CoolProp::QT_INPUTS, 0.0, T_sat);
                p_sat = src->p();
            }
        }
        pt.kind = PointEvaluation::Kind::DomeBlend;
        pt.status = CoolProp::fast_evaluate_ok;
        pt.T = T_sat;
        pt.T_sat = T_sat;
        pt.p = p_sat;
        pt.Q = Q;
        // h_mass / hL / hV left unset: the DomeBlend iHmass/iHmolar/iUmass
        // arms fill them lazily via ensure_dome_h_endpoints_ if an h / u
        // query arrives (CoolProp-qp0n).
        return pt;
    }

    // --- Single-phase / dome routing through the surface atlas. ---
    // Molar input pairs share a surface with their mass-basis sibling;
    // the conversion happens in the (a, b) extraction below.
    auto surface_key = input_pair;
    if (input_pair == CoolProp::HmolarP_INPUTS) {
        surface_key = CoolProp::HmassP_INPUTS;
    } else if (input_pair == CoolProp::DmolarT_INPUTS) {
        surface_key = CoolProp::DmassT_INPUTS;
    } else if (input_pair == CoolProp::PSmolar_INPUTS) {
        surface_key = CoolProp::PSmass_INPUTS;
    }
    const auto it = surfaces_.find(static_cast<int>(surface_key));
    if (it == surfaces_.end() || !it->second) {
        throw ValueError(std::string("SVDSBTL backend: no surface registered for this input pair (") + CoolProp::get_input_pair_short_desc(input_pair)
                         + ")");
    }
    const auto* surface = it->second.get();
    pt.surface = surface;

    // Extract (a, b) primary/secondary axes and the canonical h_mass
    // input shortcut where applicable.
    double a = 0.0;  // primary axis: always p for the MVP presets
    double b = 0.0;  // secondary axis: h for HmassP/HmolarP, T for PT
    switch (input_pair) {
        case CoolProp::HmassP_INPUTS:
            a = value2;
            pt.p = value2;
            pt.h_mass = value1;
            b = value1;
            break;
        case CoolProp::HmolarP_INPUTS:
            a = value2;
            pt.p = value2;
            pt.h_mass = value1 / calc_molar_mass();
            b = *pt.h_mass;
            break;
        case CoolProp::PT_INPUTS:
            a = value1;
            pt.p = value1;
            pt.T = value2;
            b = value2;
            break;
        case CoolProp::PSmass_INPUTS:
            // PSmass_INPUTS: value1 = p (Pa), value2 = s (J/kg/K) —
            // pressure first, unlike HmassP_INPUTS's (h, p) order.
            a = value1;
            pt.p = value1;
            pt.s_mass = value2;
            b = value2;
            break;
        case CoolProp::PSmolar_INPUTS:
            // PSmolar_INPUTS: value1 = p, value2 = s_molar (J/mol/K).
            // Convert s_molar -> s_mass via M for surface lookup.
            a = value1;
            pt.p = value1;
            pt.s_mass = value2 / calc_molar_mass();
            b = *pt.s_mass;
            break;
        case CoolProp::DmassT_INPUTS:
            // DmassT_INPUTS: value1 = D (kg/m^3), value2 = T (K).
            // DT preset uses T as primary, D as secondary.
            a = value2;
            pt.T = value2;
            pt.rho_mass = value1;
            b = value1;
            break;
        case CoolProp::DmolarT_INPUTS:
            // DmolarT_INPUTS: value1 = D_molar (mol/m^3), value2 = T.
            // Convert D_molar -> D_mass via M for surface lookup.
            a = value2;
            pt.T = value2;
            pt.rho_mass = value1 * calc_molar_mass();
            b = *pt.rho_mass;
            break;
        default:
            throw ValueError(std::string("SVDSBTL backend update: unsupported input pair (") + CoolProp::get_input_pair_short_desc(input_pair) + ")");
    }

    // Critical-patch bbox routing.  Patch lookups defer their property
    // reads to evaluate_property_ via patch_source_.
    //
    // For HmassP / HmolarP inputs we follow IF97's source-backend
    // update with polish_patch_state_(): IF97's HmassP_INPUTS uses the
    // R7-97 backward equation, which is only ±25 mK forward-consistent
    // in T.  Without the polish every in-bbox query inherits that floor
    // — visible as ~10-20 mK / 0.1-0.4 J/(kg·K) s residuals in the
    // SVDSBTL&IF97 fail-map even inside the patch box.  The polish
    // TOMS748-iterates on a tight bracket around T_seed so the returned
    // state is forward-consistent (h(T_polished, p) == h_input to
    // bracket eps).  Mirrors the polish baked into ph_subcritical's
    // IF97 sampling lambda — that's the foi.9.10 sampling-side fix;
    // this is its query-side counterpart.
    //
    // Polish is gated to IF97 sources only.  HEOS's HmassP_INPUTS is
    // already iterative + forward-consistent, so the polish should be
    // a no-op — but TOMS748 in [T_seed±0.5 K] leaves a sub-ULP T
    // residual that, for low-Tc fluids (Hydrogen Tc=33.14 K — the
    // bracket is ~1.5% of Tc), the critical-region stiffness amplifies
    // into ~1e-7 ρ drift inside the patch bbox.  Visible as non-zero
    // error in 82% of bbox cells in the SVDSBTLValidation heatmap even
    // though the patch source IS the reference HEOS.  Skipping the
    // polish for HEOS also drops one extra HEOS PT_INPUTS eval per
    // in-bbox query.  See the [hydrogen] regression test in
    // CoolProp-Tests-SVDSBTLCriticalPatch.cpp.
    // Gate on the ACTIVE patch backend, not source_backend_: when the
    // user overrides critical_patch.source (e.g. SVDSBTL&HEOS with
    // patch source="IF97" for Water), the polish requirement follows
    // the backend actually serving the in-patch query.
    const std::string& patch_backend = critical_patch_.source.empty() ? source_backend_ : critical_patch_.source;
    const bool needs_polish = (patch_backend == "IF97");
    auto patch_key = input_pair;
    if (input_pair == CoolProp::HmolarP_INPUTS) {
        patch_key = CoolProp::HmassP_INPUTS;
    } else if (input_pair == CoolProp::PSmolar_INPUTS) {
        patch_key = CoolProp::PSmass_INPUTS;
    }
    if (critical_patch_.contains(patch_key, a, b)) {
        try {
            if (input_pair == CoolProp::HmolarP_INPUTS) {
                patch_source_ref_()->update(CoolProp::HmassP_INPUTS, *pt.h_mass, *pt.p);
                // Same dome-aware polish gating as the HmassP branch
                // below — multi-valued h(T, p) inside the dome breaks
                // the single-phase forward-h polish bracket.
                if (needs_polish && patch_source_->phase() != CoolProp::iphase_twophase) {
                    polish_patch_state_(*patch_source_, *pt.p, *pt.h_mass);
                }
            } else if (input_pair == CoolProp::HmassP_INPUTS) {
                patch_source_ref_()->update(input_pair, value1, value2);
                // Skip the forward-h polish on two-phase points.
                // polish_patch_state_ assumes a single-phase solution
                // exists at h(T, p) = h_target on a tight T bracket
                // around T_seed.  Inside the saturation dome h(T, p)
                // is multi-valued (the function jumps from h_L to h_V
                // across T = T_sat), so the bracket [T_seed-0.5,
                // T_seed+0.5] straddles the dome and resid changes
                // sign without any single-phase root in the range.
                // TOMS748 silently converges to a nonsense T and the
                // returned state classifies as supercritical_liquid
                // with rho / Q = ±inf.  Two-phase points coming out
                // of the patch already have correct (T_sat, Q, rho)
                // from the source's PQ-blend; no polish needed.
                if (needs_polish && patch_source_->phase() != CoolProp::iphase_twophase) {
                    polish_patch_state_(*patch_source_, *pt.p, *pt.h_mass);
                }
            } else if (input_pair == CoolProp::PSmolar_INPUTS) {
                // Entropy twin of the HmolarP branch: PSmass_INPUTS takes
                // (p, s) — pressure first.
                patch_source_ref_()->update(CoolProp::PSmass_INPUTS, *pt.p, *pt.s_mass);
                if (needs_polish && patch_source_->phase() != CoolProp::iphase_twophase) {
                    polish_patch_state_s_(*patch_source_, *pt.p, *pt.s_mass);
                }
            } else if (input_pair == CoolProp::PSmass_INPUTS) {
                // Entropy twin of the HmassP branch.  Same dome-aware
                // polish gating: skip the forward-s polish on two-phase
                // points where s(T, p) is multi-valued.
                patch_source_ref_()->update(input_pair, value1, value2);
                if (needs_polish && patch_source_->phase() != CoolProp::iphase_twophase) {
                    polish_patch_state_s_(*patch_source_, *pt.p, *pt.s_mass);
                }
            } else {
                // PT_INPUTS — source backend's PT path is already
                // forward-consistent; no polish needed.
                patch_source_ref_()->update(input_pair, value1, value2);
            }
            pt.kind = PointEvaluation::Kind::Patched;
            pt.status = CoolProp::fast_evaluate_ok;
            if (!pt.T) pt.T = patch_source_->T();
            if (!pt.p) pt.p = patch_source_->p();
            return pt;
        } catch (const std::exception&) {
            pt.kind = PointEvaluation::Kind::OutOfRange;
            pt.status = CoolProp::fast_evaluate_out_of_range;
            return pt;
        }
    }

    // --- DT dome PRE-CHECK (must run BEFORE the atlas resolve).  For
    // DmassT / DmolarT a point with T < T_critical and rho between the
    // saturation densities (rho_sat,V(T) < D < rho_sat,L(T)) is two-phase.
    // The dome-bounded LIQUID/VAPOR/NC regions stop at the sat boundary,
    // but the isobar-bounded NC_SUPER region (CoolProp-4z79) dips below Tc
    // and its AABB SPANS the dome, so without this pre-check a dome point
    // would atlas-resolve to NC_SUPER and be read as single-phase off an
    // interpolated-across-the-dome surface value instead of P_sat(T).
    // P is well-defined (= P_sat(T)); Q comes from the lever rule on
    // specific volume (NOT density — v is the additive quantity).  Routes
    // through the same DomeBlend machinery the HmassP path uses;
    // evaluate_property_ reads p / Q / blended caloric props off the
    // endpoints. ---
    if (input_pair == CoolProp::DmassT_INPUTS || input_pair == CoolProp::DmolarT_INPUTS) {
        const double T_query = *pt.T;
        const double M = calc_molar_mass();
        const double rho_mol_query = *pt.rho_mass / M;
        try {
            auto src = source_reference_();
            if (T_query < src->T_critical()) {
                // rho_sat endpoints at T.  sat_eval_('D', ...) returns
                // MOLAR density (mol/m^3) — same basis as the HmassP
                // dome path's rhoL_mol / rhoV_mol.  Mirror that path's
                // source-QT fallback: when the SA/surrogate sat provider
                // can't supply an endpoint, take it from the source QT
                // flash so DT two-phase queries still resolve on sources
                // without a usable saturation provider.
                double rhoL_mol = sat_eval_(T_query, 'D', 0);
                double rhoV_mol = sat_eval_(T_query, 'D', 1);
                if (!std::isfinite(rhoL_mol) || !std::isfinite(rhoV_mol)) {
                    src->update(CoolProp::QT_INPUTS, 0.0, T_query);
                    rhoL_mol = src->rhomolar();
                    src->update(CoolProp::QT_INPUTS, 1.0, T_query);
                    rhoV_mol = src->rhomolar();
                }
                if (std::isfinite(rhoL_mol) && std::isfinite(rhoV_mol) && rhoV_mol < rho_mol_query && rho_mol_query < rhoL_mol) {
                    // Two-phase.  P_sat(T) from the source QT flash.
                    src->update(CoolProp::QT_INPUTS, 0.0, T_query);
                    const double p_sat = src->p();
                    pt.kind = PointEvaluation::Kind::DomeBlend;
                    pt.status = CoolProp::fast_evaluate_ok;
                    pt.p = p_sat;
                    pt.T = T_query;
                    pt.T_sat = T_query;
                    // Lever rule on specific volume (the additive
                    // quantity): v = (1-Q)*vL + Q*vV.  Q is basis-
                    // independent, so molar volumes give the same Q.
                    const double v = 1.0 / rho_mol_query;
                    const double vL = 1.0 / rhoL_mol;
                    const double vV = 1.0 / rhoV_mol;
                    pt.Q = (v - vL) / (vV - vL);
                    pt.rhoL_mol = rhoL_mol;
                    pt.rhoV_mol = rhoV_mol;
                    // Enthalpy endpoints (hL/hV) and h_mass are NOT computed
                    // here (CoolProp-qp0n): a (T, D) -> p / Q query never
                    // needs them.  The DomeBlend iHmass/iHmolar/iUmass arms
                    // fill them lazily via ensure_dome_h_endpoints_() if an
                    // h / u query actually arrives, mirroring the lazy rho /
                    // s endpoints.  pt.h_mass is left unset, so the top-level
                    // h short-circuit correctly does NOT fire for this point
                    // and the lazy arms are reached.
                    return pt;
                }
            }
        } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
            // Sat endpoints / source unavailable — fall through to the
            // atlas resolve (best available; a true dome point is rare).
        }
    }

    // Atlas resolve.  region_idx < 0 means the point landed inside
    // the saturation dome (for HmassP) or outside every region's bbox
    // (for PT or genuinely OOB HmassP).
    pt.resolved = surface->resolve(a, b);
    if (pt.resolved.region_idx >= 0) {
        // Near-dome guard (issue #3190).  The atlas single-phase regions'
        // dome-side boundary is an interpolated sat curve whose fit error
        // makes it overshoot the true bubble/dew line, so a caloric input
        // sitting exactly on the saturation boundary resolves single-phase
        // (Q = -1) instead of two-phase.  resolve() returns the secondary-
        // axis (h / s) normalised coordinate eta in svd_x; the misclassified
        // band hugs a region edge (eta -> 1 on the LIQUID dome side, eta ->
        // 0 on the VAPOR dome side), spanning only ~1e-6 in eta.  When eta
        // is within a thin band of either edge, re-test against the
        // authoritative sat provider (the same one the forward PQ flash
        // uses) so the round-trip is consistent.  kDomeEtaBand must comfortably
        // exceed the boundary-curve fit error in eta units; 1e-2 leaves a
        // ~1000x margin while still sparing >98% of single-phase queries
        // the sat lookup.  The check itself only reclassifies points that
        // are genuinely in the dome, so the wider band only costs the
        // occasional wasted (correct) sat eval at a non-dome region edge.
        constexpr double kDomeEtaBand = 1e-2;
        const double eta = pt.resolved.svd_x;
        const bool near_edge = std::isfinite(eta) && (eta < kDomeEtaBand || eta > 1.0 - kDomeEtaBand);
        if (near_edge) {
            if (input_pair == CoolProp::HmassP_INPUTS || input_pair == CoolProp::HmolarP_INPUTS) {
                if (try_fast_dome_reclassify_(pt, 'H', *pt.p, *pt.h_mass)) {
                    return pt;
                }
            } else if (input_pair == CoolProp::PSmass_INPUTS || input_pair == CoolProp::PSmolar_INPUTS) {
                if (try_fast_dome_reclassify_(pt, 'S', *pt.p, *pt.s_mass)) {
                    return pt;
                }
            }
        }
        pt.kind = PointEvaluation::Kind::SinglePhase;
        pt.status = CoolProp::fast_evaluate_ok;
        return pt;
    }

    // --- Atlas miss.  For HmassP / HmolarP try dome blend. ---
    if (input_pair == CoolProp::HmassP_INPUTS || input_pair == CoolProp::HmolarP_INPUTS) {
        const double p_val = *pt.p;
        const double h_mass = *pt.h_mass;
        const double M = calc_molar_mass();
        bool sat_resolved = false;
        double T_sat = 0.0, hL_mol = 0.0, hV_mol = 0.0;
        // Optional sat-line caloric endpoints we may also pick up from
        // the source PQ fallback (saves the redundant lookup later).
        std::optional<double> rhoL_mol_seed, rhoV_mol_seed, sL_mol_seed, sV_mol_seed;
        // Fast path: SA -> surrogate -> NaN.  Falls through to source
        // PQ only when neither provider is built.
        try {
            const double T_sat_fast = sat_T_from_p_(p_val);
            if (std::isfinite(T_sat_fast)) {
                const double hL_fast = sat_eval_(T_sat_fast, 'H', 0);
                const double hV_fast = sat_eval_(T_sat_fast, 'H', 1);
                if (std::isfinite(hL_fast) && std::isfinite(hV_fast)) {
                    T_sat = T_sat_fast;
                    hL_mol = hL_fast;
                    hV_mol = hV_fast;
                    sat_resolved = true;
                }
            }
        } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
        }
        if (!sat_resolved) {
            try {
                auto src = source_reference_();
                src->update(CoolProp::PQ_INPUTS, p_val, 0.0);
                T_sat = src->T();
                hL_mol = src->hmolar();
                rhoL_mol_seed = src->rhomolar();
                sL_mol_seed = src->smolar();
                src->update(CoolProp::PQ_INPUTS, p_val, 1.0);
                hV_mol = src->hmolar();
                rhoV_mol_seed = src->rhomolar();
                sV_mol_seed = src->smolar();
                sat_resolved = true;
            } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
            }
        }
        if (sat_resolved && hV_mol > hL_mol) {
            const double h_mol = h_mass * M;
            const double Qd = (h_mol - hL_mol) / (hV_mol - hL_mol);
            // Tolerance + clamp (issue #3190): a Q=0/1 round-trip can land a
            // ULP outside [hL, hV] -- the forward h_mass = hV/M then back
            // h_mol = h_mass*M re-scaling is not bit-exact -- which a strict
            // containment check would drop to OutOfRange (reported Q=-inf).
            // Accept within kDomeQTol of the dome and clamp Q onto [0, 1].
            // Mirrors try_fast_dome_reclassify_ on the atlas-hit path.
            if (Qd >= -kDomeQTol && Qd <= 1.0 + kDomeQTol) {
                pt.kind = PointEvaluation::Kind::DomeBlend;
                pt.status = CoolProp::fast_evaluate_ok;
                pt.T = T_sat;
                pt.T_sat = T_sat;
                pt.Q = std::min(1.0, std::max(0.0, Qd));
                pt.hL_mol = hL_mol;
                pt.hV_mol = hV_mol;
                pt.rhoL_mol = rhoL_mol_seed;
                pt.rhoV_mol = rhoV_mol_seed;
                pt.sL_mol = sL_mol_seed;
                pt.sV_mol = sV_mol_seed;
                return pt;
            }
        }
    }

    // --- Atlas miss.  For PSmass / PSmolar try dome blend (entropy twin
    // of the HmassP block above; Q comes from the entropy lever rule). ---
    if (input_pair == CoolProp::PSmass_INPUTS || input_pair == CoolProp::PSmolar_INPUTS) {
        const double p_val = *pt.p;
        const double s_mass = *pt.s_mass;
        const double M = calc_molar_mass();
        bool sat_resolved = false;
        double T_sat = 0.0, sL_mol = 0.0, sV_mol = 0.0;
        // Optional sat-line endpoints we may also pick up from the source
        // PQ fallback (saves the redundant lookup later).
        std::optional<double> rhoL_mol_seed, rhoV_mol_seed, hL_mol_seed, hV_mol_seed;
        try {
            const double T_sat_fast = sat_T_from_p_(p_val);
            if (std::isfinite(T_sat_fast)) {
                const double sL_fast = sat_eval_(T_sat_fast, 'S', 0);
                const double sV_fast = sat_eval_(T_sat_fast, 'S', 1);
                if (std::isfinite(sL_fast) && std::isfinite(sV_fast)) {
                    T_sat = T_sat_fast;
                    sL_mol = sL_fast;
                    sV_mol = sV_fast;
                    sat_resolved = true;
                }
            }
        } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
        }
        if (!sat_resolved) {
            try {
                auto src = source_reference_();
                src->update(CoolProp::PQ_INPUTS, p_val, 0.0);
                T_sat = src->T();
                sL_mol = src->smolar();
                rhoL_mol_seed = src->rhomolar();
                hL_mol_seed = src->hmolar();
                src->update(CoolProp::PQ_INPUTS, p_val, 1.0);
                sV_mol = src->smolar();
                rhoV_mol_seed = src->rhomolar();
                hV_mol_seed = src->hmolar();
                sat_resolved = true;
            } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
            }
        }
        if (sat_resolved && sV_mol > sL_mol) {
            const double s_mol = s_mass * M;
            const double Qd = (s_mol - sL_mol) / (sV_mol - sL_mol);
            // Tolerance + clamp (issue #3190): entropy twin of the HmassP
            // atlas-miss block above -- a Q=0/1 round-trip can land a ULP
            // outside [sL, sV] and a strict check would drop it to
            // OutOfRange (reported Q=-inf).  Accept within kDomeQTol, clamp [0,1].
            if (Qd >= -kDomeQTol && Qd <= 1.0 + kDomeQTol) {
                pt.kind = PointEvaluation::Kind::DomeBlend;
                pt.status = CoolProp::fast_evaluate_ok;
                pt.T = T_sat;
                pt.T_sat = T_sat;
                pt.Q = std::min(1.0, std::max(0.0, Qd));
                pt.sL_mol = sL_mol;
                pt.sV_mol = sV_mol;
                pt.rhoL_mol = rhoL_mol_seed;
                pt.rhoV_mol = rhoV_mol_seed;
                pt.hL_mol = hL_mol_seed;
                pt.hV_mol = hV_mol_seed;
                return pt;
            }
        }
    }

    // --- PT-on-sat detection vs genuine OOB. ---
    if (input_pair == CoolProp::PT_INPUTS) {
        try {
            // SA-or-surrogate fast path; only fall through to source
            // PQ if neither provider returns a finite T_sat.
            double T_sat_probe = sat_T_from_p_(a);
            if (!std::isfinite(T_sat_probe)) {
                auto src = source_reference_();
                src->update(CoolProp::PQ_INPUTS, a, 0.0);
                T_sat_probe = src->T();
            }
            constexpr double kSatEps = 3.3e-5;  // matches IF97Backend::set_phase
            if (std::isfinite(T_sat_probe) && std::abs(b - T_sat_probe) <= kSatEps * T_sat_probe) {
                pt.kind = PointEvaluation::Kind::TwoPhaseDisallowed;
                pt.status = CoolProp::fast_evaluate_two_phase_disallowed;
                return pt;
            }
        } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
            // No sat probe available — fall through to OOB.
        }
    }

    pt.kind = PointEvaluation::Kind::OutOfRange;
    pt.status = CoolProp::fast_evaluate_out_of_range;
    return pt;
}

void SVDSBTLBackend::ensure_dome_rho_endpoints_(PointEvaluation& pt) {
    if (pt.rhoL_mol && pt.rhoV_mol) return;
    const double rhoL_fast = sat_eval_(*pt.T_sat, 'D', 0);
    const double rhoV_fast = sat_eval_(*pt.T_sat, 'D', 1);
    if (std::isfinite(rhoL_fast) && std::isfinite(rhoV_fast)) {
        pt.rhoL_mol = rhoL_fast;
        pt.rhoV_mol = rhoV_fast;
        return;
    }
    auto src = source_reference_();
    src->update(CoolProp::QT_INPUTS, 0.0, *pt.T_sat);
    pt.rhoL_mol = src->rhomolar();
    src->update(CoolProp::QT_INPUTS, 1.0, *pt.T_sat);
    pt.rhoV_mol = src->rhomolar();
}

void SVDSBTLBackend::ensure_dome_s_endpoints_(PointEvaluation& pt) {
    if (pt.sL_mol && pt.sV_mol) return;
    const double sL_fast = sat_eval_(*pt.T_sat, 'S', 0);
    const double sV_fast = sat_eval_(*pt.T_sat, 'S', 1);
    if (std::isfinite(sL_fast) && std::isfinite(sV_fast)) {
        pt.sL_mol = sL_fast;
        pt.sV_mol = sV_fast;
        return;
    }
    auto src = source_reference_();
    src->update(CoolProp::QT_INPUTS, 0.0, *pt.T_sat);
    pt.sL_mol = src->smolar();
    src->update(CoolProp::QT_INPUTS, 1.0, *pt.T_sat);
    pt.sV_mol = src->smolar();
}

void SVDSBTLBackend::ensure_dome_h_endpoints_(PointEvaluation& pt) {
    if (pt.hL_mol && pt.hV_mol) return;
    const double hL_fast = sat_eval_(*pt.T_sat, 'H', 0);
    const double hV_fast = sat_eval_(*pt.T_sat, 'H', 1);
    if (std::isfinite(hL_fast) && std::isfinite(hV_fast)) {
        pt.hL_mol = hL_fast;
        pt.hV_mol = hV_fast;
        return;
    }
    auto src = source_reference_();
    src->update(CoolProp::QT_INPUTS, 0.0, *pt.T_sat);
    pt.hL_mol = src->hmolar();
    src->update(CoolProp::QT_INPUTS, 1.0, *pt.T_sat);
    pt.hV_mol = src->hmolar();
}

// evaluate_property_: the per-output kernel.  Pure dispatch over the
// PointEvaluation kind — no business logic beyond input-pair
// shortcuts, surface eval routing, dome Q-blend, and patch deref.
//
// Throws NotImplementedError for properties that are mathematically
// undefined in the two-phase region (speed_sound, cp, cv, viscosity,
// conductivity, Prandtl); fast_evaluate translates those into in-band
// NaN values, while calc_*() lets them propagate to the caller.
double SVDSBTLBackend::evaluate_property_(PointEvaluation& pt, CoolProp::parameters prop) {
    const double M = calc_molar_mass();

    // Always-available shortcuts directly from the resolved point.
    // The conditional checks matter — pt.T isn't filled for HmassP /
    // HmolarP single-phase points until we read it off the surface, so
    // we only short-circuit when the value was either supplied by the
    // input pair (PT case), set by the dome blend (T = T_sat), or
    // pulled from patch_source_->T() / ->p() in resolve_point_.
    //
    // iQ is *not* short-circuited at top level — Patched probes
    // delegate to patch_source_'s Q (which may itself be two-phase
    // near the bbox edge), and OOB / TwoPhaseDisallowed / Invalid
    // kinds return NaN through the kind switch.  Only SinglePhase
    // and DomeBlend use the pt.Q default / blend value.
    if (prop == CoolProp::iP && pt.p) {
        return *pt.p;
    }
    if (prop == CoolProp::iT && pt.T) {
        return *pt.T;
    }
    if (prop == CoolProp::iHmass && pt.h_mass) {
        return *pt.h_mass;
    }
    if (prop == CoolProp::iHmolar && pt.h_mass) {
        // pt.h_mass is populated at resolve time ONLY for HmassP/HmolarP,
        // where it IS the input (free).  Every dome resolve — DmassT/DmolarT
        // and PQ/QT alike — leaves it UNSET (CoolProp-qp0n): computing the
        // saturation enthalpy endpoints there is wasted work for a
        // p/Q/rho-only query, so this short-circuit does not fire for dome
        // points and they are served lazily by the DomeBlend iHmass/iHmolar
        // arm instead.
        return *pt.h_mass * M;
    }
    // PSmass / PSmolar input shortcut — entropy IS the input (free), so
    // return it directly.  Same single-source-of-truth pattern as h_mass:
    // pt.s_mass is populated at resolve time ONLY for PSmass/PSmolar —
    // including their two-phase DOME points, where s is still the input
    // and this shortcut correctly returns it (the DomeBlend iSmass arm
    // would reconstruct the identical value from the lever rule, since Q
    // was derived from s).  Every OTHER resolve (PT / DmassT / PQ / QT)
    // leaves s_mass unset, so for those an iSmass query falls through to
    // the surface eval or the DomeBlend iSmass arm instead.
    if (prop == CoolProp::iSmass && pt.s_mass) {
        return *pt.s_mass;
    }
    if (prop == CoolProp::iSmolar && pt.s_mass) {
        return *pt.s_mass * M;
    }
    // DmassT / DmolarT input shortcut — density is the input, not a
    // surface-tabulated property, so return it directly.  Same
    // single-source-of-truth pattern as h_mass above.
    if (prop == CoolProp::iDmass && pt.rho_mass) {
        return *pt.rho_mass;
    }
    if (prop == CoolProp::iDmolar && pt.rho_mass) {
        return *pt.rho_mass / M;
    }

    switch (pt.kind) {
        case PointEvaluation::Kind::SinglePhase: {
            // Single-phase by construction (atlas resolved to a
            // region, which excludes the dome).  Mirror the -1
            // sentinel update()'s legacy contract uses for iQ.
            if (prop == CoolProp::iQ) {
                return -1.0;
            }
            // Map molar variants to the mass-basis property the surface
            // tabulates, then scale.
            CoolProp::parameters surface_prop = prop;
            bool need_div_M = false, need_mul_M = false;
            switch (prop) {
                case CoolProp::iDmolar:
                    surface_prop = CoolProp::iDmass;
                    need_div_M = true;
                    break;
                case CoolProp::iSmolar:
                    surface_prop = CoolProp::iSmass;
                    need_mul_M = true;
                    break;
                case CoolProp::iUmolar:
                    surface_prop = CoolProp::iUmass;
                    need_mul_M = true;
                    break;
                case CoolProp::iHmolar:
                    surface_prop = CoolProp::iHmass;
                    need_mul_M = true;
                    break;
                default:
                    break;
            }
            if (!pt.surface->contains_property(surface_prop)) {
                throw ValueError(std::string("SVDSBTL backend: active surface does not expose property '")
                                 + CoolProp::get_parameter_information(surface_prop, "short") + "'");
            }
            const double v = pt.surface->eval_with_region(surface_prop, pt.resolved.region_idx, pt.resolved.svd_x, pt.resolved.svd_y);
            if (need_div_M) return v / M;
            if (need_mul_M) return v * M;
            return v;
        }
        case PointEvaluation::Kind::DomeBlend: {
            const double Q = pt.Q;
            switch (prop) {
                case CoolProp::iQ:
                    return Q;
                case CoolProp::iDmass:
                case CoolProp::iDmolar: {
                    ensure_dome_rho_endpoints_(pt);
                    const double vL = 1.0 / *pt.rhoL_mol;
                    const double vV = 1.0 / *pt.rhoV_mol;
                    const double rho_molar = 1.0 / ((1.0 - Q) * vL + Q * vV);
                    return (prop == CoolProp::iDmass) ? rho_molar * M : rho_molar;
                }
                case CoolProp::iSmass:
                case CoolProp::iSmolar: {
                    ensure_dome_s_endpoints_(pt);
                    const double s_molar = (1.0 - Q) * *pt.sL_mol + Q * *pt.sV_mol;
                    return (prop == CoolProp::iSmass) ? s_molar / M : s_molar;
                }
                case CoolProp::iHmass:
                case CoolProp::iHmolar: {
                    // Reached for DmassT/DmolarT and PQ/QT dome points, whose
                    // resolves leave the enthalpy endpoints lazy
                    // (CoolProp-qp0n).  Only HmassP/HmolarP dome points
                    // populate pt.h_mass (it is the input) and are served by
                    // the top-level h short-circuit before this switch.
                    ensure_dome_h_endpoints_(pt);
                    const double h_molar = (1.0 - Q) * *pt.hL_mol + Q * *pt.hV_mol;
                    return (prop == CoolProp::iHmass) ? h_molar / M : h_molar;
                }
                case CoolProp::iUmass:
                case CoolProp::iUmolar: {
                    ensure_dome_rho_endpoints_(pt);
                    ensure_dome_h_endpoints_(pt);
                    // u = h - p/rho per the thermodynamic identity.
                    const double uL_mol = *pt.hL_mol - *pt.p / *pt.rhoL_mol;
                    const double uV_mol = *pt.hV_mol - *pt.p / *pt.rhoV_mol;
                    const double u_molar = (1.0 - Q) * uL_mol + Q * uV_mol;
                    return (prop == CoolProp::iUmass) ? u_molar / M : u_molar;
                }
                case CoolProp::ispeed_sound:
                    throw NotImplementedError("SVDSBTL backend: speed_sound is not defined in the two-phase region");
                case CoolProp::iviscosity:
                    throw NotImplementedError("SVDSBTL backend: viscosity is not defined in the two-phase region");
                case CoolProp::iconductivity:
                    throw NotImplementedError("SVDSBTL backend: conductivity is not defined in the two-phase region");
                default:
                    throw ValueError(std::string("SVDSBTL backend: two-phase blend not implemented for property '")
                                     + CoolProp::get_parameter_information(prop, "short") + "'");
            }
        }
        case PointEvaluation::Kind::Patched: {
            // Inside the critical-patch bbox the source backend owns
            // every answer — delegate without trying to second-guess
            // it via mass-basis round-trips.  iQ in particular can be
            // genuinely two-phase near the bbox edge if the patch was
            // sized to include sat-curve excursions.
            return patch_source_->keyed_output(prop);
        }
        case PointEvaluation::Kind::OutOfRange:
        case PointEvaluation::Kind::TwoPhaseDisallowed:
        case PointEvaluation::Kind::Invalid:
        case PointEvaluation::Kind::InternalError:
            return std::nan("");
    }
    return std::nan("");
}

void SVDSBTLBackend::update(CoolProp::input_pairs input_pair, double value1, double value2) {
    // Lazily build the DmassT surface on first density-input query (it is
    // deliberately kept out of the constructor's eager loop — see there).
    // ensure_surface_ is idempotent, so this is a cheap no-op afterwards.
    if (input_pair == CoolProp::DmassT_INPUTS || input_pair == CoolProp::DmolarT_INPUTS) {
        ensure_surface_(CoolProp::DmassT_INPUTS);
    } else if (input_pair == CoolProp::PSmass_INPUTS || input_pair == CoolProp::PSmolar_INPUTS) {
        ensure_surface_(CoolProp::PSmass_INPUTS);
    }
    clear();
    _phase = iphase_not_imposed;
    active_eval_ = resolve_point_(input_pair, value1, value2);

    // Copy the resolved (T, p, Q) into AbstractState's standard slots
    // so legacy callers reading _T / _p / _Q / _phase from the base
    // class still see consistent values.
    if (active_eval_.T) _T = *active_eval_.T;
    if (active_eval_.p) _p = *active_eval_.p;
    // AbstractState::p() returns the cached _p directly (skipping
    // calc_pressure / calc_p), so for input pairs where p is computed
    // by the surface rather than supplied as input (currently:
    // DmassT / DmolarT), we must populate _p here.  Single-phase
    // only — Dome / Patched / OOB paths intentionally leave _p alone
    // since they have their own ->p() routing.
    if (!active_eval_.p && active_eval_.kind == PointEvaluation::Kind::SinglePhase
        && (input_pair == CoolProp::DmassT_INPUTS || input_pair == CoolProp::DmolarT_INPUTS)) {
        try {
            const double p_surface = evaluate_property_(active_eval_, CoolProp::iP);
            if (std::isfinite(p_surface) && p_surface > 0.0) {
                _p = p_surface;
                active_eval_.p = p_surface;  // also cache on the eval for AbstractState::T() and friends
            }
        } catch (...) {  // NOLINT(bugprone-empty-catch)
            // Surface eval failed; leave _p at its default (caller will see NaN/-inf which signals an OOB cell).
        }
    }
    // _Q is populated for every kind that has a well-defined Q so
    // legacy callers reading state->Q() see a value consistent with
    // what fast_evaluate(iQ) would return.  SinglePhase gets the -1
    // sentinel (matches IF97Backend::update()); DomeBlend gets the
    // lever-rule fraction; Patched delegates to the source backend
    // (which can be two-phase if the bbox extends across the sat
    // curve); OOB / TwoPhaseDisallowed / Invalid leave _Q untouched
    // (clear() set it to -_HUGE) since there's no defined value.
    switch (active_eval_.kind) {
        case PointEvaluation::Kind::SinglePhase:
            _Q = -1.0;
            break;
        case PointEvaluation::Kind::DomeBlend:
            _Q = active_eval_.Q;
            _phase = iphase_twophase;
            break;
        case PointEvaluation::Kind::Patched:
            try {
                _Q = patch_source_->keyed_output(CoolProp::iQ);
            } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
                _Q = -1.0;
            }
            // Inherit the source's phase classification.  Without this
            // a two-phase patched state (which the skip-polish path now
            // correctly preserves) would surface as iphase_not_imposed
            // and state.phase() would disagree with the source.  Wrap
            // in try/catch because some sources may not report a phase
            // for every input pair (HEOS does; defensive against
            // REFPROP edge cases).
            try {
                _phase = patch_source_->phase();
            } catch (const std::exception&) {  // NOLINT(bugprone-empty-catch)
            }
            break;
        case PointEvaluation::Kind::OutOfRange:
            // Legacy back-compat: when an HmassP probe misses
            // everything (above critical pressure, etc.) we used to
            // tag iphase_twophase as a best-effort label.  Preserve
            // that to avoid surprising callers that check phase()
            // in this corner case.
            // PSmass/PSmolar are intentionally NOT included: this is a
            // legacy back-compat quirk for existing HmassP callers, and PS
            // is a new pair with no such callers.  A genuine OOB PS query
            // should report its real (unclassified) phase, not a spurious
            // two-phase label (resolve_point_ already routes in-dome PS
            // states to DomeBlend).
            if (input_pair == CoolProp::HmassP_INPUTS || input_pair == CoolProp::HmolarP_INPUTS) {
                _phase = iphase_twophase;
            }
            break;
        case PointEvaluation::Kind::TwoPhaseDisallowed:
        case PointEvaluation::Kind::Invalid:
        case PointEvaluation::Kind::InternalError:
            break;
    }
}

// Property accessors — all route through evaluate_property_ over the
// active_eval_ kernel.  The throw cases (speed_sound / viscosity /
// conductivity in the two-phase region) propagate to the caller.
CoolPropDbl SVDSBTLBackend::calc_rhomass() {
    return evaluate_property_(active_eval_, CoolProp::iDmass);
}
CoolPropDbl SVDSBTLBackend::calc_hmass() {
    return evaluate_property_(active_eval_, CoolProp::iHmass);
}
CoolPropDbl SVDSBTLBackend::calc_smass() {
    return evaluate_property_(active_eval_, CoolProp::iSmass);
}
CoolPropDbl SVDSBTLBackend::calc_umass() {
    return evaluate_property_(active_eval_, CoolProp::iUmass);
}
CoolPropDbl SVDSBTLBackend::calc_T() {
    return evaluate_property_(active_eval_, CoolProp::iT);
}
CoolPropDbl SVDSBTLBackend::calc_speed_sound() {
    return evaluate_property_(active_eval_, CoolProp::ispeed_sound);
}
CoolPropDbl SVDSBTLBackend::calc_viscosity() {
    return evaluate_property_(active_eval_, CoolProp::iviscosity);
}
CoolPropDbl SVDSBTLBackend::calc_conductivity() {
    return evaluate_property_(active_eval_, CoolProp::iconductivity);
}
CoolPropDbl SVDSBTLBackend::calc_pressure() {
    return evaluate_property_(active_eval_, CoolProp::iP);
}

// Molar variants — defer to the mass version and scale by molar_mass.
CoolPropDbl SVDSBTLBackend::calc_rhomolar() {
    return calc_rhomass() / calc_molar_mass();
}
CoolPropDbl SVDSBTLBackend::calc_hmolar() {
    return calc_hmass() * calc_molar_mass();
}
CoolPropDbl SVDSBTLBackend::calc_smolar() {
    return calc_smass() * calc_molar_mass();
}
CoolPropDbl SVDSBTLBackend::calc_umolar() {
    return calc_umass() * calc_molar_mass();
}

// Constants — delegate to a lazily-allocated HEOS reference.
CoolPropDbl SVDSBTLBackend::calc_molar_mass() {
    if (molar_mass_cached_ < 0.0) {
        molar_mass_cached_ = source_reference_()->molar_mass();
    }
    return molar_mass_cached_;
}
CoolPropDbl SVDSBTLBackend::calc_gas_constant() {
    return source_reference_()->gas_constant();
}
CoolPropDbl SVDSBTLBackend::calc_T_critical() {
    return source_reference_()->T_critical();
}
CoolPropDbl SVDSBTLBackend::calc_p_critical() {
    return source_reference_()->p_critical();
}
CoolPropDbl SVDSBTLBackend::calc_rhomass_critical() {
    return source_reference_()->rhomass_critical();
}
CoolPropDbl SVDSBTLBackend::calc_rhomolar_critical() {
    return source_reference_()->rhomolar_critical();
}
CoolPropDbl SVDSBTLBackend::calc_Ttriple() {
    return source_reference_()->Ttriple();
}
CoolPropDbl SVDSBTLBackend::calc_p_triple() {
    return source_reference_()->p_triple();
}
CoolPropDbl SVDSBTLBackend::calc_Tmax() {
    return source_reference_()->Tmax();
}
CoolPropDbl SVDSBTLBackend::calc_Tmin() {
    return source_reference_()->Tmin();
}
CoolPropDbl SVDSBTLBackend::calc_pmax() {
    return source_reference_()->pmax();
}

// fast_evaluate: vectorized cache-bypassing batch path.  Mirrors
// update()'s routing per point but writes directly to out_buffer
// without touching any per-instance cache slot (_T, _p, _phase,
// active_*).  All allocations live outside the loop.
//
// Supported pairs:
//   HmassP_INPUTS  : val1 = h, val2 = p
//   HmolarP_INPUTS : val1 = h_molar, val2 = p  (converted to h_mass)
//   PT_INPUTS      : val1 = p,   val2 = T
//
// Per-point outcome:
//   - in-domain single-phase  → resolve + N_outputs evaluations + ok
//   - inside critical-patch   → patch_source_->update() + property reads
//   - HmassP / HmolarP in dome → Q-weighted lever-rule blend through
//                                 resolve_point_ + evaluate_property_
//   - PT exactly on sat curve  → NaN row + fast_evaluate_two_phase_disallowed
//   - out of every region      → NaN row + fast_evaluate_out_of_range
//
// In-patch points get the same patch_source_->update() routing as
// update() does — omitting the critical-patch handoff would silently
// degrade accuracy at the states the build was explicitly configured
// to cover.
void SVDSBTLBackend::fast_evaluate(CoolProp::input_pairs input_pair, const double* val1, const double* val2, std::size_t N_inputs,
                                   const CoolProp::parameters* outputs, std::size_t N_outputs, double* out_buffer, std::size_t out_buffer_size,
                                   int* status_flags, std::size_t status_flags_size, CoolProp::phases /*imposed_phase*/) {
    // Bounds + null checks first (matches IF97Backend::fast_evaluate).
    if (N_outputs != 0 && N_inputs > std::numeric_limits<std::size_t>::max() / N_outputs) {
        throw ValueError(format("fast_evaluate: N_inputs * N_outputs would overflow size_t (N_inputs=%zu, N_outputs=%zu)", N_inputs, N_outputs));
    }
    const std::size_t required_out = N_inputs * N_outputs;
    if (out_buffer_size < required_out) {
        throw ValueError(format("fast_evaluate: out_buffer_size=%zu < required %zu (N_inputs * N_outputs)", out_buffer_size, required_out));
    }
    if (status_flags_size < N_inputs) {
        throw ValueError(format("fast_evaluate: status_flags_size=%zu < required %zu (N_inputs)", status_flags_size, N_inputs));
    }
    if (N_inputs == 0) return;
    if (val1 == nullptr || val2 == nullptr || outputs == nullptr || out_buffer == nullptr || status_flags == nullptr) {
        throw ValueError("fast_evaluate: null pointer argument");
    }
    // Lazily build the DmassT / PS surfaces (kept out of the constructor's
    // eager loop — see there).  fast_evaluate is an independent entry point,
    // so it needs the same lazy ensure as update().  Idempotent.
    if (input_pair == CoolProp::DmassT_INPUTS || input_pair == CoolProp::DmolarT_INPUTS) {
        ensure_surface_(CoolProp::DmassT_INPUTS);
    } else if (input_pair == CoolProp::PSmass_INPUTS || input_pair == CoolProp::PSmolar_INPUTS) {
        ensure_surface_(CoolProp::PSmass_INPUTS);
    }
    if (N_outputs == 0) {
        for (std::size_t k = 0; k < N_inputs; ++k)
            status_flags[k] = CoolProp::fast_evaluate_ok;
        return;
    }
    if (input_pair != CoolProp::HmassP_INPUTS && input_pair != CoolProp::HmolarP_INPUTS && input_pair != CoolProp::PT_INPUTS
        && input_pair != CoolProp::DmassT_INPUTS && input_pair != CoolProp::DmolarT_INPUTS && input_pair != CoolProp::PSmass_INPUTS
        && input_pair != CoolProp::PSmolar_INPUTS) {
        throw ValueError(format("fast_evaluate (SVDSBTL): input_pair %s not supported "
                                "(use HmassP_INPUTS, HmolarP_INPUTS, PT_INPUTS, DmassT_INPUTS, DmolarT_INPUTS, PSmass_INPUTS, or PSmolar_INPUTS)",
                                get_input_pair_short_desc(input_pair).c_str()));
    }
    // Validate the surface exists for this input pair before the per-
    // point loop so a malformed request fails fast (resolve_point_
    // would otherwise throw on the first call).  Molar input pairs
    // share a surface with their mass-basis sibling.
    auto surface_key = input_pair;
    if (input_pair == CoolProp::HmolarP_INPUTS) {
        surface_key = CoolProp::HmassP_INPUTS;
    } else if (input_pair == CoolProp::DmolarT_INPUTS) {
        surface_key = CoolProp::DmassT_INPUTS;
    } else if (input_pair == CoolProp::PSmolar_INPUTS) {
        surface_key = CoolProp::PSmass_INPUTS;
    }
    const auto sit = surfaces_.find(static_cast<int>(surface_key));
    if (sit == surfaces_.end() || !sit->second) {
        throw ValueError(std::string("fast_evaluate (SVDSBTL): no surface registered for ") + CoolProp::get_input_pair_short_desc(input_pair));
    }

    const double NaN = std::numeric_limits<double>::quiet_NaN();
    auto fill_nan_row = [&](std::size_t k) {
        for (std::size_t o = 0; o < N_outputs; ++o) {
            out_buffer[k * N_outputs + o] = NaN;
        }
    };

    // Build an output plan ONCE outside the per-point loop.
    //
    // SVDSurface::eval_with_region_multi can evaluate N properties at
    // the same (region, svd_x, svd_y) for the price of one locate() +
    // Hermite-basis-setup pair, amortizing those ~25 ns across the
    // batch.  To use it we need to know up-front which of the user's
    // outputs map to surface evals, what mass-basis surface key each
    // corresponds to (iDmolar → iDmass × M, iHmolar → iHmass × M, etc.),
    // and how to scale on output (multiply / divide by M).
    //
    // Per-output role:
    //   * Surface:        consumed from the batched surface_vals array
    //   * Shortcut:       served by evaluate_property_ (input-pair
    //                     shortcuts + iQ + kind-dependent paths)
    // We dedup the surface-prop list so requesting both iDmass and
    // iDmolar costs one eval, not two.
    //
    // Shortcut eligibility depends on which input pair is active —
    // e.g., iT is a shortcut only for PT_INPUTS (pt.T is the input);
    // for HmassP / HmolarP it has to come off the surface, in which
    // case routing it through the batch saves an extra locate().
    // Likewise iHmass / iHmolar are shortcuts only when h is supplied
    // by the input pair.
    const bool input_is_PT = (input_pair == CoolProp::PT_INPUTS);
    const bool input_has_h = (input_pair == CoolProp::HmassP_INPUTS || input_pair == CoolProp::HmolarP_INPUTS);
    const bool input_has_D = (input_pair == CoolProp::DmassT_INPUTS || input_pair == CoolProp::DmolarT_INPUTS);
    const bool input_has_s = (input_pair == CoolProp::PSmass_INPUTS || input_pair == CoolProp::PSmolar_INPUTS);

    // N_outputs is bounded by the caller's output schema (typically <
    // 10 for thermo-property batches), so a single heap allocation
    // per fast_evaluate call is negligible against an N_inputs-deep
    // per-point loop and avoids a hard-coded compile-time ceiling.
    std::vector<unsigned char> output_is_surface(N_outputs, 0);
    std::vector<std::size_t> output_surface_idx(N_outputs, 0);
    std::vector<double> output_M_scale(N_outputs, 1.0);
    std::vector<CoolProp::parameters> surface_props;
    surface_props.reserve(N_outputs);
    const double M = calc_molar_mass();
    for (std::size_t o = 0; o < N_outputs; ++o) {
        CoolProp::parameters mass_prop = outputs[o];
        double scale = 1.0;
        switch (outputs[o]) {
            case CoolProp::iP:
            case CoolProp::iQ:
                // Resolved inside evaluate_property_, not via the
                // batched surface multi-eval: iP is the input for
                // PT/HmassP (and a per-point surface eval for DmassT,
                // handled there); iQ resolves trivially (-1 for
                // SinglePhase, Q for DomeBlend).  Either way these
                // don't join the surface_props batch.
                output_is_surface[o] = 0;
                continue;
            case CoolProp::iT:
                if (input_is_PT || input_has_D) {
                    // T is supplied directly by PT and DmassT/DmolarT.
                    output_is_surface[o] = 0;
                    continue;
                }
                // Falls through to surface eval (mass_prop = iT, scale = 1).
                break;
            case CoolProp::iDmass:
                if (input_has_D) {
                    // Density is the input, not a tabulated property —
                    // evaluate_property_'s pt.rho_mass short-circuit
                    // returns it.  (For non-D inputs, falls through to
                    // surface eval via default below.)
                    output_is_surface[o] = 0;
                    continue;
                }
                break;
            case CoolProp::iHmass:
                if (input_has_h) {
                    // pt.h_mass is populated directly from the input.
                    output_is_surface[o] = 0;
                    continue;
                }
                // PT_INPUTS: needs a surface lookup.  mass_prop = iHmass.
                break;
            case CoolProp::iHmolar:
                if (input_has_h) {
                    // evaluate_property_ shortcut: *pt.h_mass * M.
                    output_is_surface[o] = 0;
                    continue;
                }
                // PT_INPUTS: surface returns iHmass, scale by M.
                mass_prop = CoolProp::iHmass;
                scale = M;
                break;
            case CoolProp::iDmolar:
                if (input_has_D) {
                    // evaluate_property_ shortcut: *pt.rho_mass / M.
                    output_is_surface[o] = 0;
                    continue;
                }
                mass_prop = CoolProp::iDmass;
                scale = 1.0 / M;
                break;
            case CoolProp::iSmass:
                if (input_has_s) {
                    // pt.s_mass is populated directly from the input — and
                    // the PS surface does NOT tabulate iSmass (it stores
                    // iHmass), so this MUST short-circuit rather than hit
                    // the surface.  For non-S inputs, falls through to
                    // surface eval (mass_prop = iSmass).
                    output_is_surface[o] = 0;
                    continue;
                }
                break;
            case CoolProp::iSmolar:
                if (input_has_s) {
                    // evaluate_property_ shortcut: *pt.s_mass * M.
                    output_is_surface[o] = 0;
                    continue;
                }
                mass_prop = CoolProp::iSmass;
                scale = M;
                break;
            case CoolProp::iUmolar:
                mass_prop = CoolProp::iUmass;
                scale = M;
                break;
            default:
                break;
        }
        // Surface-served output.  Dedup against already-listed props
        // (cheap linear scan; N_outputs is small).
        std::size_t idx = surface_props.size();
        for (std::size_t s = 0; s < surface_props.size(); ++s) {
            if (surface_props[s] == mass_prop) {
                idx = s;
                break;
            }
        }
        if (idx == surface_props.size()) {
            surface_props.push_back(mass_prop);
        }
        output_is_surface[o] = 1;
        output_surface_idx[o] = idx;
        output_M_scale[o] = scale;
    }
    const std::size_t n_surface_props = surface_props.size();

    // Per-point loop.  resolve_point_ does all the routing; for
    // SinglePhase kinds we batch the surface evals via the multi-eval
    // path; everything else (DomeBlend, Patched, shortcuts) falls
    // through evaluate_property_ per output.
    std::vector<double> surface_vals(n_surface_props, 0.0);
    for (std::size_t k = 0; k < N_inputs; ++k) {
        PointEvaluation pt;
        try {
            pt = resolve_point_(input_pair, val1[k], val2[k]);
        } catch (const std::exception&) {
            status_flags[k] = CoolProp::fast_evaluate_internal_error;
            fill_nan_row(k);
            continue;
        }
        if (pt.kind == PointEvaluation::Kind::OutOfRange || pt.kind == PointEvaluation::Kind::TwoPhaseDisallowed
            || pt.kind == PointEvaluation::Kind::Invalid || pt.kind == PointEvaluation::Kind::InternalError) {
            status_flags[k] = pt.status;
            fill_nan_row(k);
            continue;
        }

        // SinglePhase: one batched surface multi-eval covers every
        // surface-served output; shortcuts still go through
        // evaluate_property_.
        const bool can_batch = (pt.kind == PointEvaluation::Kind::SinglePhase) && n_surface_props > 0;
        if (can_batch) {
            try {
                pt.surface->eval_with_region_multi(pt.resolved.region_idx, pt.resolved.svd_x, pt.resolved.svd_y, surface_props.data(),
                                                   n_surface_props, surface_vals.data());
            } catch (const std::exception&) {
                status_flags[k] = CoolProp::fast_evaluate_internal_error;
                fill_nan_row(k);
                continue;
            }
        }

        bool row_failed = false;
        for (std::size_t o = 0; o < N_outputs; ++o) {
            double v = NaN;
            if (can_batch && output_is_surface[o] != 0) {
                v = surface_vals[output_surface_idx[o]] * output_M_scale[o];
            } else {
                try {
                    v = evaluate_property_(pt, outputs[o]);
                } catch (const NotImplementedError&) {
                    // Two-phase undefined property (speed_sound, viscosity,
                    // conductivity, cp, cv, Prandtl).  In-band NaN signals
                    // "no equilibrium value here"; status stays ok so the
                    // caller can still read the meaningful T / D / S / U
                    // / Q outputs from the same row.
                    v = NaN;
                } catch (const std::exception&) {
                    v = NaN;
                    row_failed = true;
                }
            }
            out_buffer[k * N_outputs + o] = v;
        }
        if (row_failed) {
            status_flags[k] = CoolProp::fast_evaluate_internal_error;
            fill_nan_row(k);
        } else {
            status_flags[k] = pt.status;
        }
    }
}

}  // namespace CoolProp

// NOLINTEND(bugprone-unchecked-optional-access)
